import Call from "../../../../src/services/call/call_api.js";

(function CallUnitTest(AvayaClientServices) {
    let callService = {};
    let avayaMediaInstance = {};

    describe('Call', () => {
        beforeEach(() => {
        });

        describe('constructor', () => {
            it('new Call', () => {
                let call = new Call(avayaMediaInstance, 'myTopic', callService);
                expect(call.topic).toEqual('myTopic');
            });
        });
    });
}(AvayaClientServices));