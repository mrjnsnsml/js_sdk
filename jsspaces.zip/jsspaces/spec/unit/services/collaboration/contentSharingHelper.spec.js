/*
 * Avaya Inc. Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to company instructions.
 * Copyright 2021 Avaya Inc. All Rights Reserved.
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual or
 * intended publication of such source code.
 */
import ContentSharingHelper from '../../../../src/services/collaboration/contentSharingHelper.js';

(function ContentSharingHelperUnitTest(AvayaClientServices){
    const emptyFunc = ()=>{};
    
    describe('ContentSharing Helper', () => {
        const contentSharing = {
            shareFullScreenCapability: true,
            shareApplicationWindowCapability: true,
            startScreenSharingCapability: true,
            isSharingFullScreen: false,
            isSharingApplicationWindow: false,
            isActive: false,
            isPaused: false,
            isPresenting: false,
            bitrate: 0,
            outgoingScreenSharingStream: undefined,
            contentSharingForRenderer: emptyFunc,
            startScreenSharing: emptyFunc,
            startScreenSharingFullScreen: emptyFunc,
            startScreenSharingApplicationWindow: emptyFunc,
            resume: emptyFunc,
            pause: emptyFunc,
            end: emptyFunc,
            addOnStartedCallback: emptyFunc,
            addOnEndedCallback: emptyFunc,
            addOnPausedCallback: emptyFunc,
            addOnResumedCallback: emptyFunc,
            addOnCursorReceivedCallback: emptyFunc,
            addOnFrameReceivedCallback: emptyFunc,
            addOnFrameChangedCallback: emptyFunc,
            addOnFrameReportReceivedCallback: emptyFunc,
        };
        
        let contentSharingHelper;
        beforeEach(()=>{
            contentSharingHelper = new ContentSharingHelper();
        });

        describe('startScreenSharing', ()=>{
            it('should trigger contentSharing.startScreenSharing', () => {

                spyOn(contentSharing, 'startScreenSharing');
                contentSharingHelper.contentSharing = contentSharing;
                contentSharingHelper.startScreenSharing();
                expect(contentSharing.startScreenSharing).toHaveBeenCalled();
            });
        });

        describe('startScreenSharingFullScreen', ()=>{
            it('should trigger contentSharing.startScreenSharingFullScreen', () => {

                spyOn(contentSharing, 'startScreenSharingFullScreen');
                contentSharingHelper.contentSharing = contentSharing;
                contentSharingHelper.startScreenSharingFullScreen();
                expect(contentSharing.startScreenSharingFullScreen).toHaveBeenCalled();
            });
        });

        describe('startScreenSharingApplicationWindow', ()=>{
            it('should trigger contentSharing.startScreenSharingApplicationWindow', () => {

                spyOn(contentSharing, 'startScreenSharingApplicationWindow');
                contentSharingHelper.contentSharing = contentSharing;
                contentSharingHelper.startScreenSharingApplicationWindow();
                expect(contentSharing.startScreenSharingApplicationWindow).toHaveBeenCalled();
            });
        });

        describe('resume', ()=>{
            it('should trigger contentSharing.resume', () => {

                spyOn(contentSharing, 'resume');
                contentSharingHelper.contentSharing = contentSharing;
                contentSharingHelper.resume();
                expect(contentSharing.resume).toHaveBeenCalled();
            });
        });

        describe('pause', ()=>{
            it('should trigger contentSharing.pause', () => {

                spyOn(contentSharing, 'pause');
                contentSharingHelper.contentSharing = contentSharing;
                contentSharingHelper.pause();
                expect(contentSharing.pause).toHaveBeenCalled();
            });
        });

        describe('end', ()=>{
            it('should trigger contentSharing.end', () => {

                spyOn(contentSharing, 'end');
                contentSharingHelper.contentSharing = contentSharing;
                contentSharingHelper.end();
                expect(contentSharing.end).toHaveBeenCalled();
            });
        });

        describe('contentSharingForRenderer', ()=>{
            it('should trigger contentSharing.contentSharingForRenderer', () => {

                spyOn(contentSharing, 'contentSharingForRenderer');
                contentSharingHelper.contentSharing = contentSharing;
                contentSharingHelper.contentSharingForRenderer();
                expect(contentSharing.contentSharingForRenderer).toHaveBeenCalled();
            });
        });

        describe('bitrate', ()=>{
            it('should trigger contentSharing.bitrate', () => {

                contentSharingHelper.contentSharing = contentSharing;
                let bitrate = contentSharingHelper.bitrate;
                expect(bitrate).toBe(0);
            });
        });

        describe('isPresenting', ()=>{
            it('should trigger contentSharing.isPresenting', () => {

                contentSharingHelper.contentSharing = contentSharing;
                let isPresenting = contentSharingHelper.isPresenting;
                expect(isPresenting).toBe(false);
            });
        });

        describe('isPaused', ()=>{
            it('should trigger contentSharing.isPaused', () => {

                contentSharingHelper.contentSharing = contentSharing;
                let isPaused = contentSharingHelper.isPaused;
                expect(isPaused).toBe(false);
            });
        });

        describe('isActive', ()=>{
            it('should trigger contentSharing.isActive', () => {

                contentSharingHelper.contentSharing = contentSharing;
                let isActive = contentSharingHelper.isActive;
                expect(isActive).toBe(false);
            });
        });

        describe('outgoingScreenSharingStream', ()=>{
            it('should trigger contentSharing.outgoingScreenSharingStream', () => {

                contentSharingHelper.contentSharing = contentSharing;
                let outgoingScreenSharingStream = contentSharingHelper.outgoingScreenSharingStream;
                expect(outgoingScreenSharingStream).toBeUndefined();
            });
        });

        describe('isSharingApplicationWindow', ()=>{
            it('should trigger contentSharing.isSharingApplicationWindow', () => {

                contentSharingHelper.contentSharing = contentSharing;
                let isSharingApplicationWindow = contentSharingHelper.isSharingApplicationWindow;
                expect(isSharingApplicationWindow).toBe(false);
            });
        });

        describe('isSharingFullScreen', ()=>{
            it('should trigger contentSharing.isSharingFullScreen', () => {

                contentSharingHelper.contentSharing = contentSharing;
                let isSharingFullScreen = contentSharingHelper.isSharingFullScreen;
                expect(isSharingFullScreen).toBe(false);
            });
        });

        describe('startScreenSharingCapability', ()=>{
            it('should trigger contentSharing.startScreenSharingCapability', () => {

                contentSharingHelper.contentSharing = contentSharing;
                let startScreenSharingCapability = contentSharingHelper.startScreenSharingCapability;
                expect(startScreenSharingCapability).toBe(true);
            });
        });

        describe('shareApplicationWindowCapability', ()=>{
            it('should trigger contentSharing.shareApplicationWindowCapability', () => {

                contentSharingHelper.contentSharing = contentSharing;
                let shareApplicationWindowCapability = contentSharingHelper.shareApplicationWindowCapability;
                expect(shareApplicationWindowCapability).toBe(true);
            });
        });

        describe('shareFullScreenCapability', ()=>{
            it('should trigger contentSharing.shareFullScreenCapability', () => {

                contentSharingHelper.contentSharing = contentSharing;
                let shareFullScreenCapability = contentSharingHelper.shareFullScreenCapability;
                expect(shareFullScreenCapability).toBe(true);
            });
        });
    });

 }(AvayaClientServices));