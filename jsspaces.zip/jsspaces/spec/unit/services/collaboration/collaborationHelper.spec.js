/*
 * Avaya Inc. Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to company instructions.
 * Copyright 2021 Avaya Inc. All Rights Reserved.
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual or
 * intended publication of such source code.
 */
import CollaborationHelper from '../../../../src/services/collaboration/collaborationHelper.js';

(function CollaborationHelperUnitTest(AvayaClientServices){
    const emptyFunc = ()=>{};
    
    describe('Collaboration Helper', () => {
        const collaboration = {
            isReceivingSharingPaused: true,
            participants: true,
            resume: emptyFunc,
            pause: emptyFunc,
            contentSharingCapability: true,
            retrieveParticipantListCapability: true,
            addOnAvailableCallback: emptyFunc,
            addOnUnavailableCallback: emptyFunc,
            addOnEndedCallback: emptyFunc,
            addOnNearEndByEjectCallback: emptyFunc,
        };
        
        let collaborationHelper;
        beforeEach(()=>{
            collaborationHelper = new CollaborationHelper();
        });

        describe('pause', ()=>{
            it('should trigger collaboration.pause', () => {

                spyOn(collaboration, 'pause');
                collaborationHelper.collaboration = collaboration;
                collaborationHelper.pause();
                expect(collaboration.pause).toHaveBeenCalled();
            });
        });

        describe('resume', ()=>{
            it('should trigger collaboration.resume', () => {

                spyOn(collaboration, 'resume');
                collaborationHelper.collaboration = collaboration;
                collaborationHelper.resume();
                expect(collaboration.resume).toHaveBeenCalled();
            });
        });

        describe('get retrieveParticipantListCapability', ()=>{
            it('should trigger collaboration.retrieveParticipantListCapability', () => {

                collaborationHelper.collaboration = collaboration;
                expect(collaborationHelper.retrieveParticipantListCapability).toBeTrue();
            });
        });

        describe('get contentSharingCapability', ()=>{
            it('should trigger collaboration.contentSharingCapability', () => {

                collaborationHelper.collaboration = collaboration;
                expect(collaborationHelper.contentSharingCapability).toBeTrue();
            });
        });

        describe('get participants', ()=>{
            it('should trigger collaboration.participants', () => {

                collaborationHelper.collaboration = collaboration;
                expect(collaborationHelper.participants).toBeTrue();
            });
        });

        describe('isReceivingSharingPaused', () => {
            it('should trigger collaboration.isReceivingSharingPaused', () => {

                collaborationHelper.collaboration = collaboration;
                expect(collaborationHelper.isReceivingSharingPaused).toBeTrue();
            });
        });
    });


 }(AvayaClientServices));