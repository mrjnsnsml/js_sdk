import TopicHelper from "../../../../src/services/topic/topicHelper.js";

import { fetch as fetchPolyfill } from 'whatwg-fetch';
import CredentialProvider from '../../../../src/config/credentialProvider_api.js';
import NetworkProviders from '../../../../src/base/network/networkProviders.js';

const getMessagesResponse = {"data":[{"_id":"6080448abfbef6a6fec56b00","sender":{"_id":"5f85ab66a532f29b479784e2","type":"user","username":"nunallar@avaya.com","displayname":"Noah Unallar","picture_url":"https://storage.googleapis.com/onesna/pictures/pfpic_nunallar_58955e16-34a3-4512-8676-b59859c6c5fb"},"content":{"endTime":null,"mediaMode":"audio","virtualEndTime":null,"meetingStatus":"active","isSpaceCall":false,"bodyText":"Hello world","description":"","assignees":[],"attendees":[],"startTime":"2021-04-21T15:28:10.196Z","recordings":[],"data":[]},"chatCount":0,"likeCount":0,"status":0,"category":"chat","topicId":"5fad6aac5bd04ffb08440fd2","created":"2021-04-21T15:28:10.188Z","modified":"2021-04-21T15:28:10.188Z","__v":0},{"_id":"607f3589f5b190503f00bc5f","sender":{"_id":"5f85ab66a532f29b479784e2","type":"user","username":"nunallar@avaya.com","displayname":"Noah Unallar","picture_url":"https://storage.googleapis.com/onesna/pictures/pfpic_nunallar_58955e16-34a3-4512-8676-b59859c6c5fb"},"content":{"endTime":null,"mediaMode":"audio","virtualEndTime":null,"meetingStatus":"active","isSpaceCall":false,"bodyText":"Hello world","description":"","assignees":[],"attendees":[],"startTime":"2021-04-20T20:11:53.951Z","recordings":[],"data":[]},"chatCount":0,"likeCount":0,"status":0,"category":"chat","topicId":"5fad6aac5bd04ffb08440fd2","created":"2021-04-20T20:11:53.944Z","modified":"2021-04-20T20:11:53.944Z","__v":0},{"_id":"5fad85de9eed562ff8b65cca","sender":{"_id":"5fad6aac5bd04ffb08440fd2","type":"spaceserver"},"content":{"endTime":"2020-11-12T19:23:15.076Z","mediaMode":"video","virtualEndTime":"2020-11-12T19:23:15.076Z","meetingStatus":"inactive","bodyText":"","attendees":[{"_id":"5f85ab66a532f29b479784e2","type":"user","username":"nunallar@avaya.com","displayname":"Noah Unallar","picture_url":"https://accounts.zang.io/norevimages/noimage.jpg","joinTime":"2020-11-12T18:58:39.914Z","mdsrvSessions":[],"lastActiveMdSrvSession":"d453b9bfd579d277c6c3c3c3038f0d3050a234e6"},{"_id":"5a51855c51642092f05e3b9b","type":"user","username":"saundersm@avaya.com","displayname":"Marc Saunders","picture_url":"https://storage.googleapis.com/onesna/pictures/pfpic_saundersm_cc9594da-474a-4ab5-9502-0947c155ac81","joinTime":"2020-11-12T19:00:59.070Z","mdsrvSessions":[],"lastActiveMdSrvSession":"393ff22755026f38fec89abc55e11a62cd622d5c"},{"_id":"58ac95653b3132a1e27bd5ce","type":"user","username":"dacheung@avaya.com","displayname":"Darryl Cheung","picture_url":"https://storage.googleapis.com/onesna/pictures/pfpic_dacheung_270bf45e-b4a5-4f74-8d3a-b7c92ceedc0d","joinTime":"2020-11-12T19:01:46.401Z","mdsrvSessions":[],"lastActiveMdSrvSession":"e3b6c763b2de5cfe4f9262f3a1de3d809b94a034"},{"_id":"59e103aa1d7b472de674314f","type":"user","username":"jmidd@avaya.com","displayname":"Jeffrey Middleton","picture_url":"https://accounts.zang.io/norevimages/noimage.jpg","joinTime":"2020-11-12T19:02:50.028Z","mdsrvSessions":[],"lastActiveMdSrvSession":"948dfc4053c0972055fd8d986bcdb90bc2d86105"}],"startTime":"2020-11-12T18:58:38.252Z","meetingSettings":{"layout":"SHOWCASE","options":{}},"assignees":[],"recordings":[],"data":[]},"chatCount":0,"likeCount":0,"status":0,"topicId":"5fad6aac5bd04ffb08440fd2","category":"meeting","created":"2020-11-12T18:58:38.253Z","__v":0}],"nextPageUrl":"test","previousPageUrl":"/api/spaces/5fad6aac5bd04ffb08440fd2/messages/byref?refTime=&direction=after&size=30&prevRefObjId=6080448abfbef6a6fec56b00&status=0&pagebyref=0","total":3};
const getPostsResponse = {"data":[{"_id":"60884968b70af69e4a6d595f","sender":{"_id":"5f85ab66a532f29b479784e2","username":"nunallar@avaya.com","displayname":"Noah Unallar","picture_url":"https://storage.googleapis.com/onesna/pictures/pfpic_nunallar_58955e16-34a3-4512-8676-b59859c6c5fb","type":"user"},"content":{"endTime":null,"mediaMode":"audio","virtualEndTime":null,"meetingStatus":"active","isSpaceCall":false,"bodyText":"testpost","assignees":[],"description":"<p>this is a testpost</p>","data":[],"dueDate":"2021-04-27T17:27:04.066Z","status":"pending","attendees":[],"startTime":"2021-04-27T17:27:04.067Z","recordings":[]},"chatCount":0,"likeCount":0,"status":0,"category":"idea","topicId":"608848112cd101881801df75","created":"2021-04-27T17:27:04.061Z","modified":"2021-04-27T17:27:04.061Z","__v":0}],"nextPageUrl":"","previousPageUrl":"","total":1};
const getTasksResponse = {"data":[{"_id":"608849e2b70af626d76d5a1f","sender":{"_id":"5f85ab66a532f29b479784e2","username":"nunallar@avaya.com","displayname":"Noah Unallar","picture_url":"https://storage.googleapis.com/onesna/pictures/pfpic_nunallar_58955e16-34a3-4512-8676-b59859c6c5fb","type":"user"},"content":{"endTime":null,"mediaMode":"audio","virtualEndTime":null,"meetingStatus":"active","isSpaceCall":false,"bodyText":"testTask","assignees":[],"description":"<p>This is a testTask </p>","data":[],"dueDate":"2021-04-27T17:28:55.468Z","status":"pending","attendees":[],"startTime":"2021-04-27T17:29:06.879Z","recordings":[]},"chatCount":0,"likeCount":0,"status":0,"category":"task","topicId":"608848112cd101881801df75","created":"2021-04-27T17:29:06.873Z","modified":"2021-04-27T17:29:06.873Z","__v":0}],"nextPageUrl":"","previousPageUrl":"","total":1};
const deleteMessagesResponse = {"deletedMessages": ["60884a62b70af687486d5b40"]};
const createTaskResponse = {"data":[{"sender":{"_id":"5f85ab66a532f29b479784e2","type":"user","username":"nunallar@avaya.com","displayname":"Noah Unallar","picture_url":"https://storage.googleapis.com/onesna/pictures/pfpic_nunallar_58955e16-34a3-4512-8676-b59859c6c5fb"},"content":{"endTime":null,"mediaMode":"audio","virtualEndTime":null,"meetingStatus":"active","isSpaceCall":false,"bodyText":"task + file","description":"this is a task , enclosed a file","data":[{"metaData":{"paging":0,"prvwProvd":"gcs","stgeProvd":"gcs"},"keywords":[],"convertStatus":0,"convertStart":null,"nextSchedule":null,"pages":0,"recordingId":null,"type":null,"provider":"native","providerFileType":"","fileType":"document","name":"env2 (1)","fileId":"80b65d25-d960-4356-ab4d-8b09590efcd0","icon":"","thumbnail":"","description":"","previewFile":"","fileSize":3239,"thumbnailFile":"","path":"https://storage.googleapis.com/spaces2020/logan%2F80b65d25-d960-4356-ab4d-8b09590efcd0?GoogleAccessId=spaces2020@spaces-2018.iam.gserviceaccount.com&Expires=1619559054&Signature=v1s76RCXERPiH5sVxT5ZWw%2Bj%2F4g9ax2JJyqpciwcRPONLG6O6QTyD6ApQLWeortWUTIBMQX150jmrWXsomJh%2Fhh5J47zpvzvdxNg2Fy6VmDkBb08XqbyrRtbEqbSi2imVZtBrs5L%2Bz7N8eyaRJUr91Isz4XBkgzt158gSiuAmGxd4TrSMkb1XzS8oUv21yiybFjlJ8doUZQA733BkThn1tUyLxo84Pu3n%2BqrAK0H3VMW2Re9tSPOqWzWfzkKnOuTCu82S1XuM%2FF8d9SIvMH6jagAJ1stxj167RfuGITr5CXAZ03savHci2gmfJ3pL%2ByceWkMpRkmtzXA41mK02kuFw%3D%3D&response-content-disposition=attachment%3B%20filename%3D%22env2%20(1)%22"}],"assignees":[],"dueDate":"2021-04-27T19:30:54.136Z","status":"pending","startTime":"2021-04-27T19:30:54.139Z","recordings":[]},"chatCount":0,"likeCount":0,"status":0,"_id":"6088666edc7b2210403a21d9","category":"task","topicId":"608848112cd101881801df75","created":"2021-04-27T19:30:54.131Z","modified":"2021-04-27T19:30:54.131Z"}]};
const createPostResponse = {"data":[{"sender":{"_id":"5f85ab66a532f29b479784e2","type":"user","username":"nunallar@avaya.com","displayname":"Noah Unallar","picture_url":"https://storage.googleapis.com/onesna/pictures/pfpic_nunallar_58955e16-34a3-4512-8676-b59859c6c5fb"},"content":{"endTime":null,"mediaMode":"audio","virtualEndTime":null,"meetingStatus":"active","isSpaceCall":false,"bodyText":"idea with a file upload","description":"this is a idea with a file uploaded","data":[{"metaData":{"paging":0,"prvwProvd":"gcs","stgeProvd":"gcs"},"keywords":[],"convertStatus":0,"convertStart":null,"nextSchedule":null,"pages":0,"recordingId":null,"type":null,"provider":"native","providerFileType":"","fileType":"document","name":"env2 (1)","fileId":"ec6b2632-c3ae-404d-a6b4-c04bcc49b5ea","icon":"","thumbnail":"","description":"","previewFile":"","fileSize":3239,"thumbnailFile":"","path":"https://storage.googleapis.com/spaces2020/logan%2Fec6b2632-c3ae-404d-a6b4-c04bcc49b5ea?GoogleAccessId=spaces2020@spaces-2018.iam.gserviceaccount.com&Expires=1619562181&Signature=A4MJUmzJVf%2BPWdHd355d6RZZ7LsxsfW9c0HAJlW1Q6vbocPa6MePEBx3ElcimSD2KAMuJ7UqH8qeA96atMcDYEHJRbWw6jO66wY9Evzt9GTuIACmeKqh6UKGVUn55DNf%2FW4mxGlqTtFTJmnC22hd7datDOlF%2FZKylbpaybczR9EHpSDShGEkLyah9o7NdtJMaj3jDnRk7DIz69OoctFplHUtVqsxfKVNXoLcaTBtYZ7AZe1aNHjEaqRXN7ptWDixkm6d5rAbaDymAIytJbyqaYMpMnn5weKuuM%2F2l5p37oSmoaAlpF5P7QWJWYGXK2I%2F1AU6P9qGnlcbvVwHiQ3ckw%3D%3D&response-content-disposition=attachment%3B%20filename%3D%22env2%20(1)%22"}],"status":"pending","dueDate":"2021-04-27T20:23:01.164Z","startTime":"2021-04-27T20:23:01.167Z","recordings":[]},"chatCount":0,"likeCount":0,"status":0,"_id":"608872a56c5d6c75d132432f","category":"idea","topicId":"608848112cd101881801df75","created":"2021-04-27T20:23:01.159Z","modified":"2021-04-27T20:23:01.159Z"}]};
const sendMessageResponse = {"data":[{"sender":{"_id":"5f85ab66a532f29b479784e2","type":"user","username":"nunallar@avaya.com","displayname":"Noah Unallar","picture_url":"https://storage.googleapis.com/onesna/pictures/pfpic_nunallar_58955e16-34a3-4512-8676-b59859c6c5fb"},"content":{"endTime":null,"mediaMode":"audio","virtualEndTime":null,"meetingStatus":"active","isSpaceCall":false,"bodyText":"Hello world","data":[{"metaData":{"paging":0,"prvwProvd":"gcs","stgeProvd":"gcs"},"keywords":[],"convertStatus":0,"convertStart":null,"nextSchedule":null,"pages":0,"recordingId":null,"type":null,"provider":"native","providerFileType":"","fileType":"document","name":"env2 (1)","fileId":"80b65d25-d960-4356-ab4d-8b09590efcd0","icon":"","thumbnail":"","description":"","previewFile":"","fileSize":3239,"thumbnailFile":"","path":"https://storage.googleapis.com/spaces2020/logan%2F80b65d25-d960-4356-ab4d-8b09590efcd0?GoogleAccessId=spaces2020@spaces-2018.iam.gserviceaccount.com&Expires=1619563379&Signature=wxxtajCDKTmuRSNakcTTKOGnpiLjKoBp0r0U8BvUY%2Fb%2BhkgVvO7FZMf439g8NhabwcUkCUKxWSEkHHn943JSeRtI6hMyuu5HgiFanq52O54UMMqfG9L2qjZ6F21D%2BMFT10tV33tT4T%2FWaGRuFX4jQ8SL19%2B3T7%2F03hXsgHBlwnx63U6Qju3zxGLLfNjZYKdiX2zT9IxW6GvpZ4EcSNVgMxwrMBWiHbzHwa5ve4e8XgJtD4PdNMRB9gOXDk3cKwdKjRnuHcg0KBdQJElPPVcATts2s2CLXn3946K8hvQPszwOB4bm1iSDCMu0q3G9L%2FnhEZC25kq%2F%2BZY22qn97TfsuQ%3D%3D&response-content-disposition=attachment%3B%20filename%3D%22env2%20(1)%22"}],"description":"","startTime":"2021-04-27T20:42:58.960Z","recordings":[]},"chatCount":0,"likeCount":0,"status":0,"_id":"608877527e65b08114bb68e7","category":"chat","topicId":"608848112cd101881801df75","created":"2021-04-27T20:42:58.952Z","modified":"2021-04-27T20:42:58.952Z"}]};
(function TopicHelperUnitTest(AvayaClientServices) {
    let originalFetch, credentialProvider, topicHelper, networkProviders;

    describe('TopicHelper', () => {
        beforeEach(() => {
            originalFetch = window.fetch;
            window.fetch = fetchPolyfill;
            jasmine.Ajax.install();
            credentialProvider = new CredentialProvider('jwt', 'token');
            networkProviders = new NetworkProviders();
            networkProviders.createRestProvider(credentialProvider);
            networkProviders.createSocketIoProvider('ws://localhost:8080');
            topicHelper = new TopicHelper();
            topicHelper.networkProviders = networkProviders;
        });

        describe('getMessages',() => {
            it('should return number of messages specified', async() => {
                topicHelper.id = '6080448abfbef6a6fec56b00';
                jasmine.Ajax.stubRequest(/.*\/api\/spaces\/6080448abfbef6a6fec56b00\/messages/).andReturn({
                    status: 200,
                    statusText: 'HTTP/1.1 200 OK',
                    contentType: 'application/json',
                    responseText: JSON.stringify(getMessagesResponse)
                });
                
                const response = await topicHelper.getMessages(5);
                expect (response.nextPageUrl).toBe('test');
                expect (response.hasNextPage).toBe(true);
            });

            it('should reject if number of messages isn\'t a number', async() => {
                topicHelper.id = '6080448abfbef6a6fec56b00';
                jasmine.Ajax.stubRequest(/.*\/api\/spaces\/6080448abfbef6a6fec56b00\/messages/).andReturn({
                    status: 200,
                    statusText: 'HTTP/1.1 200 OK',
                    contentType: 'application/json',
                    responseText: JSON.stringify(getMessagesResponse)
                });
                
                try {
                    await topicHelper.getMessages('test');
                } catch (err) {
                    return;
                }
            });
        });

        describe('getPosts', () => {
            it('should return number of posts specified', async() => {
                topicHelper.id = '6080448abfbef6a6fec56b00';
                jasmine.Ajax.stubRequest(/.*\/api\/spaces\/6080448abfbef6a6fec56b00\/ideas/).andReturn({
                    status: 200,
                    statusText: 'HTTP/1.1 200 OK',
                    contentType: 'application/json',
                    responseText: JSON.stringify(getPostsResponse)
                });
                
                const response = await topicHelper.getPosts(5);
                expect (response.nextPageUrl).toBe('');
                expect (response.hasNextPage).toBe(false);
            });

            it('should reject if number of posts isn\'t a number', async() => {
                topicHelper.id = '6080448abfbef6a6fec56b00';
                jasmine.Ajax.stubRequest(/.*\/api\/spaces\/6080448abfbef6a6fec56b00\/ideas/).andReturn({
                    status: 200,
                    statusText: 'HTTP/1.1 200 OK',
                    contentType: 'application/json',
                    responseText: JSON.stringify(getPostsResponse)
                });
                
                try {
                    await topicHelper.getPosts('test');
                } catch (err) {
                    return;
                }
            });
        });

        describe('getTasks', () => {
            it('should return number of tasks specified', async() => {
                topicHelper.id = '6080448abfbef6a6fec56b00';
                jasmine.Ajax.stubRequest(/.*\/api\/spaces\/6080448abfbef6a6fec56b00\/tasks/).andReturn({
                    status: 200,
                    statusText: 'HTTP/1.1 200 OK',
                    contentType: 'application/json',
                    responseText: JSON.stringify(getTasksResponse)
                });
                
                const response = await topicHelper.getTasks(5);
                expect (response.nextPageUrl).toBe('');
                expect (response.hasNextPage).toBe(false);
            });

            it('should reject if number of posts isn\'t a number', async() => {
                topicHelper.id = '6080448abfbef6a6fec56b00';
                jasmine.Ajax.stubRequest(/.*\/api\/spaces\/6080448abfbef6a6fec56b00\/tasks/).andReturn({
                    status: 200,
                    statusText: 'HTTP/1.1 200 OK',
                    contentType: 'application/json',
                    responseText: JSON.stringify(getTasksResponse)
                });
                
                try {
                    await topicHelper.getTasks('test');
                } catch (err) {
                    return;
                }
            });
        });

        describe('deleteMessages', () => {
            it('should delete messages with message ids specified', async() => {
                topicHelper.id = '6080448abfbef6a6fec56b00';
                jasmine.Ajax.stubRequest(/.*\/api\/messages\/deletemessages/).andReturn({
                    status: 200,
                    statusText: 'HTTP/1.1 200 OK',
                    contentType: 'application/json',
                    responseText: JSON.stringify(deleteMessagesResponse)
                });
                
                const response = await topicHelper.deleteMessages(["60884a62b70af687486d5b40"]);
            });

            it('should reject if messageIds is not an array', async() => {
                topicHelper.id = '6080448abfbef6a6fec56b00';
                jasmine.Ajax.stubRequest(/.*\/api\/messages\/deletemessages/).andReturn({
                    status: 200,
                    statusText: 'HTTP/1.1 200 OK',
                    contentType: 'application/json',
                    responseText: JSON.stringify(deleteMessagesResponse)
                });
                
                try {
                    await topicHelper.deleteMessages('test');
                } catch (err) {
                    return;
                }
            });
        });

        describe('sendMessage', () => {
            it('should send the content using restProvider if not joined', async () => {
                topicHelper.id = '6080448abfbef6a6fec56b00';
                jasmine.Ajax.stubRequest(/.*\/api\/spaces\/6080448abfbef6a6fec56b00\/chats/).andReturn({
                    status: 200,
                    statusText: 'HTTP/1.1 200 OK',
                    contentType: 'application/json',
                    responseText: JSON.stringify(sendMessageResponse)
                });

                const message = {"bodyText":"Hello world","data":[{"fileId":"80b65d25-d960-4356-ab4d-8b09590efcd0","fileSize":3239,"fileType":"document","icon":"","name":"env2 (1)","provider":"native","providerFileType":""}]};
                await topicHelper.sendMessage(message);
            });

            it('should reject if not joined and content isn\'t an object', async () => {
                topicHelper.id = '6080448abfbef6a6fec56b00';
                jasmine.Ajax.stubRequest(/.*\/api\/spaces\/6080448abfbef6a6fec56b00\/chats/).andReturn({
                    status: 200,
                    statusText: 'HTTP/1.1 200 OK',
                    contentType: 'application/json',
                    responseText: JSON.stringify(sendMessageResponse)
                });

                const message = 1233213124124;
                try {
                    await topicHelper.sendMessage(message);
                } catch (err) {
                    return;
                }
            });

            it('should send the message using socketioProvider if joined', async() => {
                topicHelper.id = '6080448abfbef6a6fec56b00';
                topicHelper.isJoined = true;
                const message = {"bodyText": "<p>Random text</p>","data": [],"description": ""};
                // await topicHelper.sendMessage(message);
            });
        });

        describe('createPost', () => {
            it('should create a post if content is an object', async () => {
                topicHelper.id = '6080448abfbef6a6fec56b00';
                jasmine.Ajax.stubRequest(/.*\/api\/spaces\/6080448abfbef6a6fec56b00\/ideas/).andReturn({
                    status: 200,
                    statusText: 'HTTP/1.1 200 OK',
                    contentType: 'application/json',
                    responseText: JSON.stringify(createPostResponse)
                });

                let content = {"bodyText":"idea with a file upload","description":"this is a idea with a file uploaded","data":[{"fileId":"ec6b2632-c3ae-404d-a6b4-c04bcc49b5ea","fileSize":3239,"fileType":"document","icon":"","name":"env2 (1)","provider":"native","providerFileType":""}]};
                await topicHelper.createPost(content);
            });

            it('should reject if the content is not an object', async () => {
                topicHelper.id = '6080448abfbef6a6fec56b00';
                jasmine.Ajax.stubRequest(/.*\/api\/spaces\/6080448abfbef6a6fec56b00\/ideas/).andReturn({
                    status: 200,
                    statusText: 'HTTP/1.1 200 OK',
                    contentType: 'application/json',
                    responseText: JSON.stringify(createPostResponse)
                });

                let content = 12332133231;

                try {
                    await topicHelper.createPost(content);
                } catch (err) {
                    return;
                }
            });
        });

        describe('createTask', () => {
            it('should create task if params are correct', async () => {
                topicHelper.id = '6080448abfbef6a6fec56b00';
                jasmine.Ajax.stubRequest(/.*\/api\/spaces\/6080448abfbef6a6fec56b00\/tasks/).andReturn({
                    status: 200,
                    statusText: 'HTTP/1.1 200 OK',
                    contentType: 'application/json',
                    responseText: JSON.stringify(createTaskResponse)
                });

                let status = 0;
                let content = {"bodyText":"task + file","description":"this is a task , enclosed a file","data":[{"fileId":"80b65d25-d960-4356-ab4d-8b09590efcd0","fileSize":3239,"fileType":"document","icon":"","name":"env2 (1)","provider":"native","providerFileType":""}],"status":"pending"};
                let dueDate = '';
                let assignees = [];

                await topicHelper.createTask(content, assignees, dueDate, status);
            });

            it('should reject if params are incorrect', async () => {
                topicHelper.id = '6080448abfbef6a6fec56b00';
                jasmine.Ajax.stubRequest(/.*\/api\/spaces\/6080448abfbef6a6fec56b00\/tasks/).andReturn({
                    status: 200,
                    statusText: 'HTTP/1.1 200 OK',
                    contentType: 'application/json',
                    responseText: JSON.stringify(createTaskResponse)
                });

                let status = 0;
                let content = {"bodyText":"task + file","description":"this is a task , enclosed a file","data":[{"fileId":"80b65d25-d960-4356-ab4d-8b09590efcd0","fileSize":3239,"fileType":"document","icon":"","name":"env2 (1)","provider":"native","providerFileType":""}],"status":"pending"};
                let dueDate = 1231232132;
                let assignees = [];

                try {
                    await topicHelper.createTask(content, assignees, dueDate, status);
                } catch (err) {
                    return;
                }
            });
        });

        describe('join', () => {
            it('should join the user\'s topic', () => {
            });
        });

        describe('unjoin', () => {
            it('should unjoin the user from his topic', () => {
            });
        });
        afterEach(() => {
            jasmine.Ajax.uninstall();
            window.fetch = originalFetch;
        });

    });
}(AvayaClientServices));