
import { SocketIO, Server } from '../../../../node_modules/mock-socket/dist/mock-socket.es.js';
import SocketIOProvider from "../../../../src/base/network/socketIoProvider.js";
import CredentialProvider from '../../../../src/config/credentialProvider_api.js';


(function SocketIOProviderUnitTest() {
    let mockServer, originalIO, ioProvider, credentialProvider;
    const url = 'ws://localhost:8080';    
    const namespace = '/chat';

    describe('SocketIOProvider', () => {
        beforeEach(() => {
            jasmine.clock().install();
            originalIO = window.io;
            window.io = SocketIO;  
            mockServer = new Server(url + namespace);
            mockServer.on('connection', socket => {     
                socket.on('SUBSCRIBE_CHANNEL', (payload) => {
                    console.log ('>>> Received subscribe channel');
                    socket.emit('CHANNEL_SUBSCRIBED', {
                        "channel": {
                            "_id": "594140a11d108619100a7363",
                            "type": "topic"
                        },
                        "dtsid": "1234",
                        "sessionId": "8b59782f-07af-4a7f-e61b-69df5e803d2f"
                    });
                });   
                
                socket.on('FAKE_CONNECTION_ERROR', () => {
                    socket.emit('connect_error', 'fake');
                });

                socket.on('FAKE_ERROR', () => {
                    socket.emit('error', 'fake');
                });
            });

            credentialProvider = new CredentialProvider('jwt', 'token');
            ioProvider = new SocketIOProvider(url, credentialProvider, namespace, SocketIO);
        });


        describe('start', () => {
            it('success', async () => {  
                spyOn(ioProvider, 'onOpen');
                const promise = ioProvider.start();
                jasmine.clock().tick(500);

                await promise;
                expect (ioProvider.onOpen).toHaveBeenCalled();       
            });

            it('forced close', async() => {              
                spyOn(ioProvider, 'onConnectionUnavailable');
                const promise = ioProvider.start();
                jasmine.clock().tick(500);

                await promise;
                mockServer.close();

                expect (ioProvider.onConnectionUnavailable).toHaveBeenCalled();   
            });

            it('forced connection_error', async() => {              
                spyOn(ioProvider, 'onConnectionError');
                const promise = ioProvider.start();
                jasmine.clock().tick(500);

                await promise;
                ioProvider.send('FAKE_CONNECTION_ERROR');

                expect (ioProvider.onConnectionError).toHaveBeenCalled();   
            });

            it('forced error', async() => {              
                spyOn(ioProvider, 'onError');
                const promise = ioProvider.start();
                jasmine.clock().tick(500);

                await promise;
                ioProvider.send('FAKE_ERROR');

                expect (ioProvider.onError).toHaveBeenCalled();   
            });
        });

        describe('subscribe', () => {
            it('onMessage', async () => {  
                const messageHandler = {
                    callback: function()  {}
                };
                spyOn(ioProvider, 'onOpen');
                spyOn(messageHandler, 'callback');

                const promise = ioProvider.start();
                jasmine.clock().tick(500);
                await promise;

                ioProvider.onMessage('CHANNEL_SUBSCRIBED', messageHandler.callback);
                ioProvider.send('SUBSCRIBE_CHANNEL', {
                    "channel": {
                        "type": "topic",
                        "_id": "594140a11d108619100a7363"
                    }
                });
                expect (ioProvider.onOpen).toHaveBeenCalled();       
                expect (messageHandler.callback).toHaveBeenCalled();     
            });

            it('addEventsListener', async () => {  
                const messageHandler = {
                    callback: function()  {}
                };
                spyOn(ioProvider, 'onOpen');
                spyOn(messageHandler, 'callback');

                const promise = ioProvider.start();
                jasmine.clock().tick(500);
                await promise;

                ioProvider.addEventsListener(['CHANNEL_SUBSCRIBED'], messageHandler.callback);
                ioProvider.send('SUBSCRIBE_CHANNEL', {
                    "channel": {
                        "type": "topic",
                        "_id": "594140a11d108619100a7363"
                    }
                });
                expect (ioProvider.onOpen).toHaveBeenCalled();       
                expect (messageHandler.callback).toHaveBeenCalled();     
            });
        });

        afterEach(() => {     
            jasmine.clock().uninstall();     
            mockServer.stop();  
            window.io = originalIO;
        });
    });
}());