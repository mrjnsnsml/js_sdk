
import { fetch as fetchPolyfill } from 'whatwg-fetch';
import 'jasmine-ajax';
import RESTProvider from "../../../../src/base/network/restProvider.js";
import CredentialProvider from '../../../../src/config/credentialProvider_api.js';
import NetworkException from '../../../../src/base/network/networkException_api.js';

(function RestProviderUnitTest() {
    let originalFetch, restProvider, credentialProvider;

    describe('RestProvider', () => {
        beforeEach(() => {
            originalFetch = window.fetch;
            window.fetch = fetchPolyfill;
            jasmine.Ajax.install();
            credentialProvider = new CredentialProvider('jwt', 'token');
            restProvider = new RESTProvider(credentialProvider);
        });

        describe('get', () => {
            it('success', async () => {
                jasmine.Ajax.stubRequest(/.*\/api\/service-configurations/).andReturn({
                    status: 200,
                    statusText: 'HTTP/1.1 200 OK',
                    contentType: 'application/json',
                    responseText: '{"spaces": {"socketio_server_url": "wss://spacesapis-socket.zang.io/"} }'
                });

                const response = await restProvider.get('https://spacesapis.zang.io/api/service-configurations');
                expect (response.spaces.socketio_server_url).toBe('wss://spacesapis-socket.zang.io/');
            });

            it('no content', async () => {
                jasmine.Ajax.stubRequest(/.*\/api\/service-configurations/).andReturn({
                    status: 204,
                    statusText: 'HTTP/1.1 204 No Content'
                });

                spyOn(credentialProvider, '_triggerInvalidCredential');

                const response = await restProvider.get('https://spacesapis.zang.io/api/service-configurations');
                expect(response).toBe(undefined);                
            });

            it('auth failure', async () => {
                jasmine.Ajax.stubRequest(/.*\/api\/service-configurations/).andReturn({
                    status: 401,
                    statusText: 'HTTP/1.1 401 Unauthorized'
                });

                spyOn(credentialProvider, '_triggerInvalidCredential');

                try {
                    await restProvider.get('https://spacesapis.zang.io/api/service-configurations');
                } catch(error) {
                    expect(error).toEqual(jasmine.any(NetworkException));
                }

                expect(credentialProvider._triggerInvalidCredential).toHaveBeenCalled();                
            });
        });

        describe('post', () => {
            it('success', async () => {
                jasmine.Ajax.stubRequest(/.*\/messages\/deletemessages/).andReturn({
                    status: 200,
                    statusText: 'HTTP/1.1 200 OK',
                    contentType: 'application/json',
                    responseText: '{"deletedMessages":["6070a04f954cf0a0d6ca6068"]}'
                });

                const response = await restProvider.post('https://spacesapis.zang.io/api/messages/deletemessages', '["6070a04f954cf0a0d6ca6068"]');
                expect (response.deletedMessages[0]).toBe('6070a04f954cf0a0d6ca6068');
            });

            it('auth failure', async () => {
                jasmine.Ajax.stubRequest(/.*\/messages\/deletemessages/).andReturn({
                    status: 401,
                    statusText: 'HTTP/1.1 403 Forbidden'
                });

                spyOn(credentialProvider, '_triggerInvalidCredential');

                try {
                    await restProvider.post('https://spacesapis.zang.io/api/messages/deletemessages', '["6070a04f954cf0a0d6ca6068"]');
                } catch(error) {
                    expect(error).toEqual(jasmine.any(NetworkException));
                }

                expect(credentialProvider._triggerInvalidCredential).toHaveBeenCalled();                
            });
        });


        describe('delete', () => {
            it('success', async () => {
                jasmine.Ajax.stubRequest(/.*\/messages\/.*/).andReturn({
                    status: 204,
                    statusText: 'HTTP/1.1 204 No Content'
                });
                
                const response = await restProvider.delete('https://spacesapis.zang.io/messages/6070a04f954cf0a0d6ca6068');
                expect (response).toBe(undefined);
            });

            it('auth failure', async () => {
                jasmine.Ajax.stubRequest(/.*\/messages\/.*/).andReturn({
                    status: 401,
                    statusText: 'HTTP/1.1 401 Unauthorized'
                });

                spyOn(credentialProvider, '_triggerInvalidCredential');

                try {
                    await restProvider.delete('https://spacesapis.zang.io/messages/6070a04f954cf0a0d6ca6068');
                } catch(error) {
                    expect(error).toEqual(jasmine.any(NetworkException));
                }

                expect(credentialProvider._triggerInvalidCredential).toHaveBeenCalled();                
            });
        });

        afterEach(() => {
            jasmine.Ajax.uninstall();
            window.fetch = originalFetch;
        });
    });
}());