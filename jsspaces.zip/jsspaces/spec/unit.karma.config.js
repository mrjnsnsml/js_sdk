module.exports = (config) => {
    config.set({
        basePath: '../',
        
        browsers: ['CustomChromeHeadless'],

        client: {
            jasmine: {
              random: false // Default to running tests in random order 
            }
        },

        customLaunchers: {
            CustomChromeHeadless: {
                base: 'ChromeHeadless',
                flags: [
                        '--headless',
                        '--no-sandbox',
                        '--progress=false',
                        '--source-map=false',
                        '--disable-dev-shm-usage',
                        '--disable-gpu',
                        '--window-size=1920, 1080',
                        '--remote-debugging-port=9222',
                        '--use-fake-ui-for-media-stream',
                        '--enable-usermedia-screen-capturing',
                        '--auto-select-desktop-capture-source=Screen 1', 
                        '--use-fake-device-for-media-stream',
                    ]
            }
        },

        sourceDir: "src",

        files: [
            'node_modules/jquery/dist/jquery.min.js',
            'node_modules/xmltojson/lib/xmlToJSON.min.js',
            'node_modules/socket.io-client/dist/socket.io.js',
            {type: 'module', pattern: 'src/*.js'},
            {type: 'module', pattern: 'src/**/*.js'},
            {type: 'module', pattern: 'spec/unit/**/*.spec.js'}
        ],

        plugins: [
            require.resolve('@open-wc/karma-esm'),
            'karma-*',
        ],

        frameworks: ['esm', 'jasmine'],

        esm: {
            nodeResolve: true,
            babel: true
        },

        preprocessors: {
            'src/*.js': ['coverage'],
            'src/**/*.js': ['coverage']
        },

        reporters: ['progress', 'coverage', 'junit'],

        coverageReporter: {
            // specify a common output directory
            dir: 'coverage/unit',
            reporters: [
                // reporters not supporting the `file` property
                { type: 'html', subdir: 'html' },
                // reporters supporting the `file` property
                { type: 'lcovonly', subdir: '.'}
            ]
        },
        junitReporter: {
            outputDir: 'coverage/unit/test_reports/', // results will be saved as $outputDir/$browserName.xml
            outputFile: undefined, // if included, results will be saved as $outputDir/$browserName/$outputFile
            suite: 'spaces' // suite will become the package name attribute in xml testsuite element
        },
        
        //logLevel: config.LOG_DEBUG,
        //,customLaunchers: {
        //    Chrome_without_security: {
        //        base: 'Chrome',
        //        flags: ['--disable-web-security']
        //    }
        //}
    });
};