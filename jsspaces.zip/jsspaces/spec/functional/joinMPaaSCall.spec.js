/*
 * Avaya Inc. Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to company instructions.
 * Copyright 2006-2020 Avaya Inc. All Rights Reserved.
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual or
 * intended publication of such source code.
 */

import { AvayaMedia, SessionException, SessionCreationOptions } from 'avayamedia';
import './mocks/connection.mock.js';
import './mocks/helper.mock.js';

(function(window, $) {
    let avayaMediaInstance;

    describe('Function Test - join MPaaS ', () => {
        const connection = window.mocks.connection,
            helper = window.mocks.helper,
            mpaasSessionToken = connection.sessionInfo.sessionToken;
        const audioCallOptions = new SessionCreationOptions(true);
        const videoCallOptions = new SessionCreationOptions(true, true);
        
        let websocket, getUserMediaSpy, createPeerConnectionSpy; 


        // AvayaMedia.registerLogger(window.console);

        beforeEach(() => {
            avayaMediaInstance = new AvayaMedia();

            spyOn(window.navigator.mediaDevices, 'enumerateDevices').and.callFake(helper.enumerateDevicesMock);

            websocket = helper.createWebSocketMock(false)();
         
            spyOn($, 'ajax').and.callFake((options) => {
                const callsHref = connection.resourcesResponse.resources[1].serviceReference.href;

                if (options.url === callsHref && options.type === 'POST') {
                    websocket.dispatchEvent(new CustomEvent('getNotificationMediaRequestSend'));
                }

                return helper.ajaxRequestMock(options);
            });

            spyOn(window, 'WebSocket').and.callFake(() => {
                setTimeout(websocket._onopen);
                return websocket;
            });

        });

        it('After a successful call service start, executing call.start for an audio/video call.', function(done) {  
            getUserMediaSpy = spyOn(window.navigator.mediaDevices, 'getUserMedia').and.callFake(helper.getUserMediaMock());
            createPeerConnectionSpy = spyOn(AvayaClientServices.Base.AbstractRTCConnectionProvider.prototype, 'createPeerConnection')
                .and.callFake(helper.createPeerConnection({video: true}));

            avayaMediaInstance.start().then(() => {
                let session = avayaMediaInstance.sessionService.createSession(mpaasSessionToken, videoCallOptions);

                session.addOnSessionFailedCallback(function (session, evt) {
                    console.log(evt);
                    done(evt);
                });
                
                session.start()
                    .then(() => {
                       expect(createPeerConnectionSpy).toHaveBeenCalled();
                       expect(getUserMediaSpy).toHaveBeenCalled();

                       expect(session.videoChannel.isReceiveVideoNegotiated).toBe(true, "The call should be established with sendrecv video");
                       expect(session.videoChannel.isSendVideoNegotiated).toBe(true, "The call should be established with sendrecv video");

                       avayaMediaInstance.stop()
                            .finally(done);   
                  })
                  .catch((ex) => {
                      done(ex);
                  });
            });
        });

    });
}(window, jQuery));
