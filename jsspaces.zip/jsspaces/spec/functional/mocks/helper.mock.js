/* eslint-disable no-invalid-this */
/* eslint-disable func-names */
/* eslint-disable func-style */
/* eslint-disable handle-callback-err */
/* eslint-disable no-param-reassign */
/* eslint-disable max-len */
/* eslint-disable consistent-return */
/* eslint-disable no-unused-vars */
/* eslint-disable no-undefined */
/* eslint-disable init-declarations */
/*
 * Avaya Inc. Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to company instructions.
 * Copyright 2006-2014 Avaya Inc. All Rights Reserved.
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual or
 * intended publication of such source code.
 */
(function HelperMock(window) {
    window.mocks = window.mocks || {};
    const connection = window.mocks.connection,

        getUser = (isMediaServiceContextProvided = true, isMediaEngineEnabled = true) => {
            let config = {}, client;

            return new Promise((resolve) => {
                let sessionInfo = connection.sessionInfo,
                    defaultConfig = {
                        wcsConfiguration: {
                            enabled: true
                        },
                        mediaServiceContext: isMediaServiceContextProvided ? sessionInfo.sessionToken : undefined,
                        collaborationConfiguration: {
                            contentSharingWorkerPath: 'base/libs/jscsdk/AvayaClientServicesWorker.min.js'
                        }
                    },

                    mediaConfiguration = isMediaEngineEnabled ? {} : { mediaConfiguration: { mediaEngineEnabled : false } },

                    callUserConfiguration = new AvayaClientServices.Config.CallUserConfiguration();
                callUserConfiguration.videoEnabled = true;

                config.userConfiguration = Object.assign(
                    new AvayaClientServices.Config.UserConfiguration(),
                    defaultConfig,
                    { callUserConfiguration: callUserConfiguration },
                    mediaConfiguration
                );

                client = new AvayaClientServices();
                // client.registerLogger(console);
                resolve({
                    client: client,
                    user: client.createUser(config.userConfiguration),
                    config: config.userConfiguration
                });
            });
        },

        // this fetching token is used only for development proposes
        getUserFetchingToken = () => {
            let config = {}, sessionInfoPromise, client;
            return new Promise((resolve, reject) => {
                let token;
                sessionInfoPromise = fetch(connection.MPaaSTokenHref, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/vnd.avaya.mpaas.authorizationrequest+json'
                    },
                    body: JSON.stringify({ accountId: connection.accountId, accountSecret: connection.accountSecret })
                })
                    .then((response) => {
                        if (response && response.status === 200) {
                            return response.json();
                        }
                        reject(new Error('error, fetching the token'));
                    })
                    .then((result) => {
                        token = result.accessToken;
                        return new Promise((resolveSession, rejectSession) => {
                            let request = new XMLHttpRequest();
                            request.open('POST', connection.MPaaSSessionHref, true);
                            request.setRequestHeader(
                                'Accept',
                                'application/vnd.avaya.mpaas.error+json, application/vnd.avaya.mpaas.sessionInfo+json'
                            );
                            request.setRequestHeader('Authorization', `Bearer ${ token}`);
                            request.setRequestHeader('Content-Type', 'application/vnd.avaya.mpaas.sessionPreferences+json');
                            request.onreadystatechange = () => {
                                if (this.readyState === 4) {
                                    resolveSession(this.responseText);
                                }
                            };
                            request.onerror = (err) => {
                                console.log('error, getting the session: ', err);
                            };
                            request.send(JSON.stringify({
                                displayName: 'JSCSDK Test App',
                                sessionType: 'CSDK'
                            }));
                        });
                    }).then((sessionInfo) => {
                        let sessionInfoParsed = sessionInfo && sessionInfo.length > 0 ? JSON.parse(sessionInfo) : undefined;
                        return Promise.resolve(sessionInfoParsed);
                    }).then((sessionInfo) => {
                        let defaultConfig = {
                                wcsConfiguration: {
                                    enabled: true
                                },
                                mediaServiceContext: sessionInfo.sessionToken
                            },

                            mediaConfiguration = {},

                            callUserConfiguration = new AvayaClientServices.Config.CallUserConfiguration();
                        callUserConfiguration.videoEnabled = true;

                        config.userConfiguration = Object.assign(
                            new AvayaClientServices.Config.UserConfiguration(),
                            defaultConfig,
                            { callUserConfiguration: callUserConfiguration },
                            mediaConfiguration
                        );

                        client = new AvayaClientServices();
                        // client.registerLogger(console);

                        return resolve({
                            client: client,
                            user: client.createUser(config.userConfiguration),
                            config: config.userConfiguration
                        });
                    }).catch((err) => {
                    // console.log(err);
                        reject(err);
                    });
            });
        },

        startCallService = (isMediaServiceContextProvided = true, isMediaEngineEnabled = true, isFetchingToken = false) => {
            return new Promise((resolve, reject) => {
                getUser(isMediaServiceContextProvided, isMediaEngineEnabled, isFetchingToken).then((userObj) => {
                    if (userObj && userObj.user) {
                        return userObj.user.start()
                            .then(() => {
                                resolve(userObj.user);
                            }, () => {
                                reject(new Error('error, user.start was rejected'));
                            });
                    }
                    reject(new Error('created user is empty, or undefined'));
                }, () => {
                    reject(new Error('cannot get user'));
                });
            });
        },

        urlContains = (url, string) => {
            return url.indexOf(string) !== -1;
        },

        ajaxRequestMock = (options, errorCode) => {
            const callsHref = connection.resourcesResponse.resources[1].serviceReference.href,
                servicesHref = connection.resourcesResponse.resources[2].serviceReference.href,
                sseSubsribeRequest = connection.SSEResourceDiscoveryResponse.data.discovery.commandURL,
                requestData = options.hasOwnProperty('data') &&
                typeof options.data === 'string' ?
                    options.data.includes('live_session') ?
                        'live_session' :
                        JSON.parse(options.data) : {},
                isCollaborationCall = requestData.hasOwnProperty('conferenceData') &&
                requestData.conferenceData.hasOwnProperty('webCollaboration') &&
                requestData.conferenceData.webCollaboration === true,
                isError = Boolean(errorCode);


            return {
                then: (success, error) => {
                    if (isError === true) {
                        return error({
                            status: errorCode,
                            getResponseHeader: (name) => {
                                if (name === 'Retry-After') {
                                    return 1;
                                }
                            }
                        });
                    } else if (options.type === 'GET' && options.url === connection.resourcesRequest) {
                        success(connection.resourcesResponse, 'success');
                    } else if (options.type === 'GET' && options.url === callsHref) {
                        success({ calls: [] }, 'success');
                    } else if (options.type === 'POST' && options.url === callsHref) {
                        let callEstablishedResponse = Object.assign({}, connection.callEstablishResponse);
                        if (isCollaborationCall) {
                            callEstablishedResponse.conferenceData.webCollaboration = requestData.conferenceData.webCollaboration;
                            callEstablishedResponse.conferenceData.video = requestData.conferenceData.video;
                        }
                        callEstablishedResponse.audioChannel = options.data.audioChannel;
                        callEstablishedResponse.videoChannels = options.data.videoChannels;
                        success(callEstablishedResponse);
                    } else if (options.url === `${connection.url }/csa/0bd582bc-c4b9-43f0-9af8-d9b99d1cccbb/resources/tenants/default`) {
                        success(connection.responseForSSEConnection, 'success');
                    } else if (options.type === 'POST' && options.url === servicesHref) {
                        success(connection.servicesResponse, 'success');
                    } else if (options.url === sseSubsribeRequest) {
                        success(connection.responseForSSESubsribed, 'success');
                    } else if (urlContains(options.url, 'live_viewer')) {
                        success(connection.liveViewerXMLResponse);
                    } else if (urlContains(options.url, 'StartLiveSession')) {
                        const requestId = options.data.split('request_id=')[1];
                        success(connection.ajaxCometStartLiveSessionResponse(requestId));
                    } else {
                        success('', 'success');
                    }
                    return;
                }
            };
        },

        getNotifyMessageType = (parsedMessage) => {
            return parsedMessage.notify.notifications[0].contents.messageType;
        },

        createMessageEvent = (data) => {
            return new MessageEvent('message', { data: JSON.stringify(data) });
        },

        createWebSocketMock = (isInitializing = true, isCollaborationCall) => {
            return () => {
                let mockedSocket = new EventTarget();

                mockedSocket.url = undefined;
                mockedSocket.binaryType = 'arraybuffer';
                mockedSocket.readyState = WebSocket.CONNECTING;
                mockedSocket._errors = [];
                mockedSocket._receivedMessages = [];

                mockedSocket.send = (data) => {
                    const parsedMessage = JSON.parse(data);

                    if (parsedMessage.hasOwnProperty('subscribe')) {
                        let subscribedResponse = Object.assign({}, connection.WSSubscribedMessage);
                        subscribedResponse.subscribed.requestId = parsedMessage.subscribe.requestId;
                        // subscribedResponse.subscribed.version = parseInt(parsedMessage.subscribe.requestId[parsedMessage.subscribe.requestId.length - 1]) + 1;
                        subscribedResponse = createMessageEvent(subscribedResponse);
                        mockedSocket._onmessage(subscribedResponse);
                    } else if (parsedMessage.hasOwnProperty('unsubscribe')) {
                        connection.WSUnsubscribedMessage.unsubscribed.requestId = parsedMessage.unsubscribe.requestId;
                        const unsubscribedResponse = createMessageEvent(connection.WSUnsubscribedMessage);
                        mockedSocket._onmessage(unsubscribedResponse);
                    } else if (parsedMessage.hasOwnProperty('ping')) {
                        connection.WSPongMessage.pong.requestId = parsedMessage.ping.requestId;
                        const pingResponse = createMessageEvent(connection.WSPongMessage);
                        mockedSocket._onmessage(pingResponse);
                    } else if (parsedMessage.hasOwnProperty('notify')) {
                        switch (getNotifyMessageType(parsedMessage)) {
                        case 'createMediaResponse': {
                            const mediaResponseData = JSON.parse(parsedMessage.notify.notifications[0].contents.messageData),
                                videoChannelData = mediaResponseData.actionDetails.videoChannels;

                            mockedSocket._onmessage(createMessageEvent(connection.WSNotifyCreateMediaResponseResponse));
                            if (videoChannelData && videoChannelData.length > 0 && videoChannelData[0].direction === 'RECEIVE_ONLY') {
                                mockedSocket._onmessage(createMessageEvent(connection.WSNotificationProcessMediaRequestRecvonly));
                            } else if (videoChannelData && videoChannelData.length > 0) {              
                                mockedSocket._onmessage(createMessageEvent(connection.WSNotificationProcessMediaRequestVideo));
                            } else {
                                mockedSocket._onmessage(createMessageEvent(connection.WSNotificationProcessMediaRequest));
                            }
                            break;
                        }
                        case 'processMediaResponse': {
                            mockedSocket._onmessage(createMessageEvent(connection.WSNotifyProcessMediaResponseResponse));
                            // callEstablished
                            mockedSocket._onmessage(createMessageEvent(isCollaborationCall ? connection.WSVideoCollaborationCallEstablished : connection.WSNotificationCallEstablished));
                            break;
                        }
                        case 'updatecallproperties': {
                            mockedSocket._onmessage(createMessageEvent(connection.WSNotifiedVideoMuted));
                            break;
                        }
                        case 'processMediaRequest': {
                            const mediaResponseData = JSON.parse(parsedMessage.notify.notifications[0].contents.messageData),
                                videoChannelData = mediaResponseData.actionDetails.videoChannels;
                            let processMediaNotification, callEstablishedNotification, processMediaResponse;
                            if (videoChannelData && videoChannelData.length > 0) {
                                processMediaNotification = connection.WSNotifyProcessMediaResponseResponseVideo;
                                callEstablishedNotification = connection.WSNotificationCallEstablishedVideo;
                            }  else {
                                processMediaNotification = connection.WSNotifyProcessMediaResponseResponse;
                                callEstablishedNotification = connection.WSNotificationCallEstablished;
                            } 
                            processMediaResponse = Object.assign({}, processMediaNotification);
                            processMediaResponse.notified.requestId = parsedMessage.notify.requestId;
                            mockedSocket._onmessage(createMessageEvent(processMediaResponse));
                            // callEstablished
                            mockedSocket._onmessage(createMessageEvent(callEstablishedNotification));
                            break;
                        }
                        default: {
                            return;
                        }
                        }
                    }
                };

                mockedSocket.close = () => {
                    mockedSocket.readyState = WebSocket.CLOSING;
                    mockedSocket._onclose();
                };

                mockedSocket._onopen = () => {
                    mockedSocket.readyState = WebSocket.OPEN;
                    mockedSocket.onopen();

                    let discoveryServerMessage = createMessageEvent(connection.WSdiscoveryMessage);
                    mockedSocket._onmessage(discoveryServerMessage);
                };

                mockedSocket._onmessage = (message) => {
                    mockedSocket._receivedMessages.push(message);
                    mockedSocket.onmessage(message);
                };

                mockedSocket._onerror = (e) => {
                    mockedSocket._errors.push(e);
                    mockedSocket.onerror(e);
                };

                mockedSocket._onclose = () => {
                    mockedSocket.readyState = WebSocket.CLOSED;

                    if (mockedSocket.onclose) {
                        mockedSocket.onclose({
                            code: AvayaClientServices.Base.NetworkErrorCodes.WEBSOCKET_CLOSE_NORMAL
                        });
                    }
                };

                if (isInitializing === true) {
                    setTimeout(mockedSocket._onopen);
                }

                mockedSocket.addEventListener('getNotificationMediaRequestSend', (eventData) => {
                    const detail = eventData.detail;
                    let createMediaRequestMessage = createMessageEvent(connection.WSNotificationCreateMediaRequest),
                        notificationCreateMediaRequest = Object.assign({}, connection.WSNotificationCreateMediaRequest);
                    if (detail) {
                        const forceTurn = eventData.detail.forceTurn;
                        if (typeof forceTurn !== 'undefined') {
                            let originalMessageData = JSON.parse(connection.WSNotificationCreateMediaRequest.notification.contents.messageData);
                            originalMessageData.actionDetails.turnData.forceTurn = forceTurn;

                            const messageDataForceTurn = JSON.stringify(originalMessageData);

                            notificationCreateMediaRequest.notification.contents.messageData = messageDataForceTurn;

                            createMediaRequestMessage = new MessageEvent('message', {
                                data: JSON.stringify(notificationCreateMediaRequest)
                            });
                        }
                    }

                    mockedSocket._onmessage(createMediaRequestMessage);
                });

                mockedSocket.addEventListener('callEstablished', (eventData) => {
                    const detail = eventData.detail;

                    mockedSocket._onmessage(createMessageEvent(connection.WSCollaborationOnlyCallEstablished));
                });

                return mockedSocket;
            };
        },

        base64ToArrayBuffer = (base64string) => {
            let binaryString = window.atob(base64string),
                len = binaryString.length,
                bytes = new Uint8Array(len);
            for (let i = 0; i < len; i++) {
                bytes[i] = binaryString.charCodeAt(i);
            }
            return bytes.buffer;
        },

        // const arrayBufferToBase64String = (arrayBuffer) => btoa(String.fromCharCode.apply(null, new Uint8Array(arrayBuffer)));
        arrayBufferToBase64String = (arrayBuffer) => {
            return AvayaClientServices.Services.Collaboration.Bitmap.prototype._toBase64(arrayBuffer);
        },

        createWCSWebSocket = (isInitializing = true) => {
            let mockedSocket = {};

            mockedSocket.url = undefined;
            mockedSocket.binaryType = 'arraybuffer';
            mockedSocket.readyState = WebSocket.CONNECTING;
            mockedSocket._errors = [];
            mockedSocket._receivedMessages = [];

            mockedSocket.send = (data) => {
                const messageType = typeof data === 'string' ? data.split('?')[0] : null;
                let requestId;

                switch (messageType) {
                case 'live_session': {
                    requestId = data.split('request_id=')[1];
                    mockedSocket._onmessage(new MessageEvent('message', { data: connection.liveSessionRequestMessage(requestId) }));
                    mockedSocket._onmessage(new MessageEvent('message', { data: connection.liveMeetingStartMessage }));
                    break;
                }
                case 'live_event': {
                    requestId = data.split('request_id=')[1];
                    mockedSocket._onmessage(new MessageEvent('message', { data: connection.startScreenSharingResponse(requestId) }));
                    mockedSocket._onmessage(new MessageEvent('message', { data: connection.startScreenSharingResponseMessage }));
                    break;
                }
                default: {
                    return;
                }
                }
            };

            mockedSocket.close = () => {
                mockedSocket.readyState = WebSocket.CLOSING;
                mockedSocket._onclose();
            };

            mockedSocket._onopen = () => {
                mockedSocket.readyState = WebSocket.OPEN;
                mockedSocket.onopen();
            };

            mockedSocket._onmessage = (message) => {
                mockedSocket._receivedMessages.push(message);
                mockedSocket.onmessage(message);
            };

            mockedSocket._onerror = (e) => {
                mockedSocket._errors.push(e);
                mockedSocket.onerror(e);
            };

            mockedSocket._onclose = () => {
                mockedSocket.readyState = WebSocket.CLOSED;

                if (mockedSocket.onclose) {
                    mockedSocket.onclose({
                        code: AvayaClientServices.Base.NetworkErrorCodes.WEBSOCKET_CLOSE_NORMAL
                    });
                }
            };

            if (isInitializing === true) {
                setTimeout(mockedSocket._onopen);
            }

            return mockedSocket;
        },

        eventSourceMock = (isInitializing = true) => {
            let callbacks = {},
                stream = {
                    readyState: EventSource.CONNECTING,
                    addEventListener: (type, cb) => {
                        callbacks[type] = cb;
                    },
                    close: () => {
                        this.readyState = EventSource.CLOSED;
                    }
                };
            stream._open = () => {
                let discoveryResponse = { ...connection.SSEResourceDiscoveryResponse };

                discoveryResponse.data = JSON.stringify(connection.SSEResourceDiscoveryResponse.data);
                this.readyState = EventSource.OPEN;
                callbacks[AvayaClientServices.Providers.AMM.AMM3EventTypes.CAS_NOTIFICATION](discoveryResponse);
                stream.onopen();
            // stream.onerror({readyState: EventSource.CLOSED});
            };
            if (isInitializing) {
                setTimeout(() => {
                    return stream._open();
                });
            }
            return stream;
        },

        enumerateDevicesMock = (enumerateDevices) => {
            return {
                then: (success) => {
                    success(enumerateDevices ? enumerateDevices : connection.enumerateDevices);
                }
            };
        },

        getUserMediaMock = (audioTrack, videoTrack, throwError = false) => {
            audioTrack = audioTrack ? audioTrack : {
                active: true,
                id: '1',
                kind: 'audio',
                readyState: 'live',
                stop: () => {},
                applyConstraints: () => { return Promise.resolve(); },
                getConstraints: () => { return {}; }
            };

            videoTrack = videoTrack ? videoTrack : {
                active: true,
                id: '2',
                kind: 'video',
                readyState: 'live',
                stop: () => {},
                applyConstraints: () => {
                    return Promise.resolve({});
                },
                getConstraints: () => { return {}; }
            };

            return (audioVideo) => {
                const { audio, video } = audioVideo;
                let mockedPromise = {
                    then: (onSuccess, onError) => {
                        let mockedMediaStream = {
                            id: '1234567890',
                            getTracks: () => {
                                return video && audio ? [].concat(audioTrack, videoTrack) : audio ? [ audioTrack ] : [];
                            },
                            getAudioTracks: () => {
                                return audio ? [ audioTrack ] : [];
                            },
                            getVideoTracks: () => {
                                return video ? [ videoTrack ] : [];
                            },
                            removeTrack: () => {
                                return;
                            },
                            addTrack: () => {
                                return;
                            }
                        };
                        onSuccess(mockedMediaStream);
                        return mockedPromise;
                    },
                    catch: (err) => {
                    }
                };

                return mockedPromise;
            };
        },

        getDisplayMediaFake = () => {
            let mediaStream = new MediaStream();

            mediaStream.clone = () => {
                return Object.assign({}, mediaStream);
            };
            mediaStream.getVideoTracks = () => {
                return [ {
                    active: true,
                    id: '2',
                    kind: 'video',
                    readyState: 'live',
                    stop: () => {}
                } ];
            };
            return new Promise((resolve, reject) => {
                return resolve(mediaStream);
            });
        },

        emptyObjFunc = () => {},

        emptyArrFunc = () => {
            return [];
        },

        RTCPeerConnection = function(config, isInitializing = true, options={}) {
            if (config && config.hasOwnProperty('iceServers')) {
                const { iceServers } = config;
            }
            const _pc = {
                    started: false,
                    _tracks: [],
                    _streams: [],
                    _senders: [],
                    signalingState: 'stable',
                    localDescription: {},
                    remoteDescription: {},
                    iceConnectionState: AvayaClientServices.Base.AbstractRTCConnectionProvider.Constants.ICE_CONNECTION_STATE_NEW,
                    iceGatheringState: AvayaClientServices.Base.AbstractRTCConnectionProvider.Constants.ICE_GATHERING_STATE_GATHERING,
                    start: () => {
                        _pc.started = true;
                    },
                    close: () => {
                        _pc.started = false;
                    },
                    getTracks: () => {
                        return _pc._tracks;
                    },
                    getSenders: () => {
                        return _pc._senders;
                    },
                    addTrack: (track, stream) => {
                        setTimeout(() => {
                            _pc._tracks.push(track);

                            if (_pc._onAddTrack) {
                                _pc._onAddTrack(track);
                            }

                            if (_pc.ontrack) {
                                _pc.ontrack({ track: track, streams: [] });
                            }
                        });

                        const rtpSender = {
                            dtmf: _pc.createDTMFSender(stream),
                            getParameters: () => { return {}; }
                        };

                        _pc._senders.push({ 
                            track: track, 
                            getStats: () => {
                                return Promise.resolve([]);
                            }, 
                            getParameters: () => {
                                return {};
                            },
                            setParameters: (parameters) => {
                                return Promise.resolve(parameters);
                            }
                        });

                        return rtpSender;
                    },
                    getStats: (fn) => {
                        setTimeout(fn);
                    },
                    addStream: (stream) => {
                        _pc.streams.push(stream);

                        if (_pc.onaddstream) {
                            _pc.onaddstream({ stream: stream });
                        }
                    },
                    // removeTrack: (track) => {

                    //     /* console.log('remove track');*/
                    // },
                    createAnswer: () => {
                        return Promise.resolve({
                            type: '',
                            sdp: emptyObjFunc,
                        });
                    },
                    createDTMFSender: (stream) => {
                        return {
                            insertDTMF: emptyObjFunc,
                            stream: stream
                        };
                    },
                    createOffer: (offerParam) => {
                        if (options.video) {
                            return Promise.resolve({
                                type: 'offer',
                                sdp: 'v=0\r\no=- 5406627625534386199 2 IN IP4 127.0.0.1\r\ns=-\r\nt=0 0\r\na=group:BUNDLE audio video\r\na=msid-semantic: WMS 0b5d7555-978c-468c-8462-07a5e28465cf\r\nm=audio 51256 UDP/TLS/RTP/SAVPF 111 103 104 9 0 8 106 105 13 110 112 113 126\r\nc=IN IP4 135.105.195.68\r\na=rtcp:9 IN IP4 0.0.0.0\r\na=candidate:3263605622 1 udp 2122260223 135.105.195.68 51256 typ host generation 0 network-id 1\r\na=ice-ufrag:f+wK\r\na=ice-pwd:M+3r+++b9v8PWODclBIaqHwV\r\na=ice-options:trickle\r\na=fingerprint:sha-256 08:C5:11:C2:84:23:B4:DE:7D:45:1F:9F:DE:E8:FE:C7:A8:29:DE:24:23:10:FE:95:8B:D8:31:75:68:D4:4C:13\r\na=setup:actpass\r\na=mid:audio\r\na=extmap:1 urn:ietf:params:rtp-hdrext:ssrc-audio-level\r\na=extmap:2 http://www.webrtc.org/experiments/rtp-hdrext/abs-send-time\r\na=extmap:3 http://www.ietf.org/id/draft-holmer-rmcat-transport-wide-cc-extensions-01\r\na=sendrecv\r\na=rtcp-mux\r\na=rtpmap:111 opus/48000/2\r\na=rtcp-fb:111 transport-cc\r\na=fmtp:111 minptime=10;useinbandfec=1\r\na=rtpmap:103 ISAC/16000\r\na=rtpmap:104 ISAC/32000\r\na=rtpmap:9 G722/8000\r\na=rtpmap:0 PCMU/8000\r\na=rtpmap:8 PCMA/8000\r\na=rtpmap:106 CN/32000\r\na=rtpmap:105 CN/16000\r\na=rtpmap:13 CN/8000\r\na=rtpmap:110 telephone-event/48000\r\na=rtpmap:112 telephone-event/32000\r\na=rtpmap:113 telephone-event/16000\r\na=rtpmap:126 telephone-event/8000\r\na=ssrc:2888347454 cname:XWpsZgummfeVGFNU\r\na=ssrc:2888347454 msid:0b5d7555-978c-468c-8462-07a5e28465cf 906c66e1-6360-4bc9-9116-536dab0567ac\r\na=ssrc:2888347454 mslabel:0b5d7555-978c-468c-8462-07a5e28465cf\r\na=ssrc:2888347454 label:906c66e1-6360-4bc9-9116-536dab0567ac\r\nm=video 51261 UDP/TLS/RTP/SAVPF 96 97 98 99 100 101 102 121 127 120 125 107 108 109 124 119 123 118 114 115 116\r\nc=IN IP4 135.105.195.68\r\na=rtcp:9 IN IP4 0.0.0.0\r\na=candidate:3263605622 1 udp 2122260223 135.105.195.68 51261 typ host generation 0 network-id 1\r\na=ice-ufrag:f+wK\r\na=ice-pwd:M+3r+++b9v8PWODclBIaqHwV\r\na=ice-options:trickle\r\na=fingerprint:sha-256 08:C5:11:C2:84:23:B4:DE:7D:45:1F:9F:DE:E8:FE:C7:A8:29:DE:24:23:10:FE:95:8B:D8:31:75:68:D4:4C:13\r\na=setup:actpass\r\na=mid:video\r\na=extmap:14 urn:ietf:params:rtp-hdrext:toffset\r\na=extmap:2 http://www.webrtc.org/experiments/rtp-hdrext/abs-send-time\r\na=extmap:13 urn:3gpp:video-orientation\r\na=extmap:3 http://www.ietf.org/id/draft-holmer-rmcat-transport-wide-cc-extensions-01\r\na=extmap:5 http://www.webrtc.org/experiments/rtp-hdrext/playout-delay\r\na=extmap:6 http://www.webrtc.org/experiments/rtp-hdrext/video-content-type\r\na=extmap:7 http://www.webrtc.org/experiments/rtp-hdrext/video-timing\r\na=extmap:8 http://www.webrtc.org/experiments/rtp-hdrext/color-space\r\na=sendrecv\r\na=rtcp-mux\r\na=rtcp-rsize\r\na=rtpmap:96 VP8/90000\r\na=rtcp-fb:96 goog-remb\r\na=rtcp-fb:96 transport-cc\r\na=rtcp-fb:96 ccm fir\r\na=rtcp-fb:96 nack\r\na=rtcp-fb:96 nack pli\r\na=rtpmap:97 rtx/90000\r\na=fmtp:97 apt=96\r\na=rtpmap:98 VP9/90000\r\na=rtcp-fb:98 goog-remb\r\na=rtcp-fb:98 transport-cc\r\na=rtcp-fb:98 ccm fir\r\na=rtcp-fb:98 nack\r\na=rtcp-fb:98 nack pli\r\na=fmtp:98 profile-id=0\r\na=rtpmap:99 rtx/90000\r\na=fmtp:99 apt=98\r\na=rtpmap:100 VP9/90000\r\na=rtcp-fb:100 goog-remb\r\na=rtcp-fb:100 transport-cc\r\na=rtcp-fb:100 ccm fir\r\na=rtcp-fb:100 nack\r\na=rtcp-fb:100 nack pli\r\na=fmtp:100 profile-id=2\r\na=rtpmap:101 rtx/90000\r\na=fmtp:101 apt=100\r\na=rtpmap:102 H264/90000\r\na=rtcp-fb:102 goog-remb\r\na=rtcp-fb:102 transport-cc\r\na=rtcp-fb:102 ccm fir\r\na=rtcp-fb:102 nack\r\na=rtcp-fb:102 nack pli\r\na=fmtp:102 level-asymmetry-allowed=1;packetization-mode=1;profile-level-id=42001f\r\na=rtpmap:121 rtx/90000\r\na=fmtp:121 apt=102\r\na=rtpmap:127 H264/90000\r\na=rtcp-fb:127 goog-remb\r\na=rtcp-fb:127 transport-cc\r\na=rtcp-fb:127 ccm fir\r\na=rtcp-fb:127 nack\r\na=rtcp-fb:127 nack pli\r\na=fmtp:127 level-asymmetry-allowed=1;packetization-mode=0;profile-level-id=42001f\r\na=rtpmap:120 rtx/90000\r\na=fmtp:120 apt=127\r\na=rtpmap:125 H264/90000\r\na=rtcp-fb:125 goog-remb\r\na=rtcp-fb:125 transport-cc\r\na=rtcp-fb:125 ccm fir\r\na=rtcp-fb:125 nack\r\na=rtcp-fb:125 nack pli\r\na=fmtp:125 level-asymmetry-allowed=1;packetization-mode=1;profile-level-id=42e01f\r\na=rtpmap:107 rtx/90000\r\na=fmtp:107 apt=125\r\na=rtpmap:108 H264/90000\r\na=rtcp-fb:108 goog-remb\r\na=rtcp-fb:108 transport-cc\r\na=rtcp-fb:108 ccm fir\r\na=rtcp-fb:108 nack\r\na=rtcp-fb:108 nack pli\r\na=fmtp:108 level-asymmetry-allowed=1;packetization-mode=0;profile-level-id=42e01f\r\na=rtpmap:109 rtx/90000\r\na=fmtp:109 apt=108\r\na=rtpmap:124 H264/90000\r\na=rtcp-fb:124 goog-remb\r\na=rtcp-fb:124 transport-cc\r\na=rtcp-fb:124 ccm fir\r\na=rtcp-fb:124 nack\r\na=rtcp-fb:124 nack pli\r\na=fmtp:124 level-asymmetry-allowed=1;packetization-mode=1;profile-level-id=4d001f\r\na=rtpmap:119 rtx/90000\r\na=fmtp:119 apt=124\r\na=rtpmap:123 H264/90000\r\na=rtcp-fb:123 goog-remb\r\na=rtcp-fb:123 transport-cc\r\na=rtcp-fb:123 ccm fir\r\na=rtcp-fb:123 nack\r\na=rtcp-fb:123 nack pli\r\na=fmtp:123 level-asymmetry-allowed=1;packetization-mode=1;profile-level-id=64001f\r\na=rtpmap:118 rtx/90000\r\na=fmtp:118 apt=123\r\na=rtpmap:114 red/90000\r\na=rtpmap:115 rtx/90000\r\na=fmtp:115 apt=114\r\na=rtpmap:116 ulpfec/90000\r\na=ssrc-group:FID 3318182168 924307823\r\na=ssrc:3318182168 cname:XWpsZgummfeVGFNU\r\na=ssrc:3318182168 msid:0b5d7555-978c-468c-8462-07a5e28465cf 488e7c3e-06c6-4e56-9c82-6479eb7e5400\r\na=ssrc:3318182168 mslabel:0b5d7555-978c-468c-8462-07a5e28465cf\r\na=ssrc:3318182168 label:488e7c3e-06c6-4e56-9c82-6479eb7e5400\r\na=ssrc:924307823 cname:XWpsZgummfeVGFNU\r\na=ssrc:924307823 msid:0b5d7555-978c-468c-8462-07a5e28465cf 488e7c3e-06c6-4e56-9c82-6479eb7e5400\r\na=ssrc:924307823 mslabel:0b5d7555-978c-468c-8462-07a5e28465cf\r\na=ssrc:924307823 label:488e7c3e-06c6-4e56-9c82-6479eb7e5400\r\n'
                            });
                        } else {
                            return Promise.resolve({
                                type: 'offer',
                                sdp: 'v=0\r\no=- 3118929050079934534 2 IN IP4 127.0.0.1\r\ns=-\r\nt=0 0\r\na=group:BUNDLE audio\r\na=msid-semantic: WMS 4d64d972-a3bf-4240-80ea-bb19ae13f774\r\nm=audio 9 UDP/TLS/RTP/SAVPF 111 103 104 9 0 8 106 105 13 110 112 113 126\r\nc=IN IP4 0.0.0.0\r\na=rtcp:9 IN IP4 0.0.0.0\r\na=ice-ufrag:40NI\r\na=ice-pwd:075V46nyL16DzcLL79+S3mJB\r\na=ice-options:trickle\r\na=fingerprint:sha-256 5A:EB:86:34:7A:17:36:1E:BE:F1:D5:EB:BA:28:44:72:AA:06:92:36:E3:5A:D1:15:D1:E6:70:B3:90:74:6E:58\r\na=setup:actpass\r\na=mid:audio\r\na=extmap:1 urn:ietf:params:rtp-hdrext:ssrc-audio-level\r\na=extmap:2 http://www.webrtc.org/experiments/rtp-hdrext/abs-send-time\r\na=extmap:3 http://www.ietf.org/id/draft-holmer-rmcat-transport-wide-cc-extensions-01\r\na=sendrecv\r\na=rtcp-mux\r\na=rtpmap:111 opus/48000/2\r\na=rtcp-fb:111 transport-cc\r\na=fmtp:111 minptime=10;useinbandfec=1\r\na=rtpmap:103 ISAC/16000\r\na=rtpmap:104 ISAC/32000\r\na=rtpmap:9 G722/8000\r\na=rtpmap:0 PCMU/8000\r\na=rtpmap:8 PCMA/8000\r\na=rtpmap:106 CN/32000\r\na=rtpmap:105 CN/16000\r\na=rtpmap:13 CN/8000\r\na=rtpmap:110 telephone-event/48000\r\na=rtpmap:112 telephone-event/32000\r\na=rtpmap:113 telephone-event/16000\r\na=rtpmap:126 telephone-event/8000\r\na=ssrc:3657252950 cname:IYsxh6QNpab4zizi\r\na=ssrc:3657252950 msid:4d64d972-a3bf-4240-80ea-bb19ae13f774 a3736ca5-3cd4-4829-9067-4730ff2c3879\r\na=ssrc:3657252950 mslabel:4d64d972-a3bf-4240-80ea-bb19ae13f774\r\na=ssrc:3657252950 label:a3736ca5-3cd4-4829-9067-4730ff2c3879\r\n'
                            });
                        }
                    },
                    setLocalDescription: (desc) => {
                        _pc.localDescription = desc;
                        return Promise.resolve(desc);
                    },
                    setRemoteDescription: (desc) => {
                        _pc.remoteDescription = desc;
                        return Promise.resolve(desc);
                    },
                    addIceCandidate: (candidate) => {
                        if (candidate) {
                            _pc.onicecandidate(candidate);
                        } else {
                            _pc.onicecandidate({
                                candidate: null,
                                isTrusted: true,
                                type: 'icecandidate'
                            });
                        }
                    },
                    getReceivers: emptyArrFunc,
                    getTransceivers: emptyArrFunc,
                    getLocalStreams: emptyArrFunc,
                    getRemoteStreams: emptyArrFunc,
                    ontrack: emptyObjFunc,
                    onremovestream: emptyObjFunc,
                    _onAddTrack: emptyObjFunc,
                    removeTrack: emptyObjFunc,
                    removeStream: emptyObjFunc,
                    onicegatheringstatechange: emptyObjFunc,
                    oniceconnectionstatechange: emptyObjFunc,
                    onicecandidate: emptyObjFunc,
                },

                onIceGatheringStateChange = () => {
                    if (_pc.onicegatheringstatechange) {
                        _pc.onicegatheringstatechange();
                    }
                    return new Promise((resolve) => {
                        return setTimeout(() => {
                            return resolve();
                        });
                    });
                },
                onIceConnectionStateChange = () => {
                    if (_pc.oniceconnectionstatechange) {
                        _pc.oniceconnectionstatechange();
                    }
                },
                onIceCandidateUdp = () => {
                    if (_pc.onicecandidate) {
                        _pc.onicecandidate({
                            candidate: {
                                address: '135.105.195.68',
                                candidate: 'candidate:3263605622 1 udp 2122260223 135.105.195.68 51256 typ host generation 0 network-id 1',
                                component: 'rtp',
                                foundation: '3263605622',
                                port: 51256,
                                priority: 2122260223,
                                protocol: 'udp',
                                relatedAddress: null,
                                relatedPort: null,
                                sdpMLineIndex: 0,
                                sdpMid: 'audio',
                                tcpType: '',
                                type: 'host',
                                usernameFragment: 'f+wK',
                            },
                            isTrusted: true,
                            type: 'icecandidate'
                        });

                        if (options.video) {
                            _pc.onicecandidate({
                                candidate: {
                                    address: '135.105.195.68',
                                    candidate: 'candidate:3263605622 1 udp 2122260223 135.105.195.68 51261 typ host generation 0 network-id 1',
                                    component: 'rtp',
                                    foundation: '3263605622',
                                    port: 51261,
                                    priority: 2122260223,
                                    protocol: 'udp',
                                    relatedAddress: null,
                                    relatedPort: null,
                                    sdpMLineIndex: 0,
                                    sdpMid: 'video',
                                    tcpType: '',
                                    type: 'host',
                                    usernameFragment: 'f+wK',
                                },
                                isTrusted: true,
                                type: 'icecandidate'
                            });
                        }
                    }
                },
                onIceCandidateNull = () => {
                    if (_pc.onicecandidate) {
                        _pc.onicecandidate({
                            candidate: null,
                            isTrusted: true,
                            type: 'icecandidate'
                        });
                    }
                };

            // eslint-disable-next-line func-names
            _pc.initialize = () => {
                onIceGatheringStateChange()
                    .then(onIceCandidateUdp)
                    .then(onIceCandidateNull);

            /*
                .then(() => {
                    _pc.iceGatheringState = AvayaClientServices.Base.AbstractRTCConnectionProvider.Constants.ICE_GATHERING_STATE_COMPLETE;
                    return onIceGatheringStateChange();
                })
                .then(() => {
                    _pc.iceConnectionState = AvayaClientServices.Base.AbstractRTCConnectionProvider.Constants.ICE_GATHERING_STATE_GATHERING;
                    //AvayaClientServices.Base.AbstractRTCConnectionProvider.Constants.ICE_CONNECTION_STATE_COMPLETED;
                    return onIceConnectionStateChange();
                })
                .then(onIceGatheringStateChange);*/
            };

            if (isInitializing) {
                _pc.initialize();
            }

            return _pc;
        },

        createPeerConnection = function(options) {
            return function(config) {
                this.close();

                if (!AvayaClientServices.Base.Utils.isDefined(config) || Object.keys(config).length === 0 && config.constructor === Object) {
                    config = null;
                }
                this._pc = new RTCPeerConnection(config, true, options);
            };
        };

    window.mocks.helper = {
        getUser,
        getUserFetchingToken,
        startCallService,
        ajaxRequestMock,
        eventSourceMock,
        getNotifyMessageType,
        createWebSocketMock,
        createWCSWebSocket,
        enumerateDevicesMock,
        RTCPeerConnection,
        createPeerConnection,
        getUserMediaMock,
        getDisplayMediaFake,
        urlContains,
        arrayBufferToBase64String,
        base64ToArrayBuffer
    };
}(window));
