# CloudConnect example

# Before running example, please copy the following dependencies to libs

## jquery.min.js        // from node_modules/jquery/dist
## xmlToJSON.min.js     // from node_modules/xmltojson/lib
## konva.min.js // from node_modules/konva
## CloudCommunication.min.js  // from build
## CloudCommunicationRenderer.min.js  // from build
# Misc

## Update the topicId with your Spaces meeting room id. 
GET https://spacesapis.avayacloud.com/api/users/meetingroom/<USERNAME>@avaya.com?

## Use JWT token from a guest or different user if you want to see roster updates.


