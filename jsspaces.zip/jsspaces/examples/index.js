
import CloudCommunication, {AudioMode, VideoMode, CredentialProvider, VideoResolutionFactory} from "./libs/CloudCommunication.min.js";
import CloudCommunicationRenderer from "./libs/CloudCommunicationRenderer.min.js";

var cloudConnect, call;

let startBT = document.querySelector('button[name="startBT"]');
let startAudioBT = document.querySelector('button[name="startAudioBT"]');
let startVideoBT = document.querySelector('button[name="startVideoBT"]');
let endCallBT = document.querySelector('button[name="endCallBT"]');
let leaveBT = document.querySelector('button[name="leaveBT"]');
let personalTopicBT = document.querySelector('button[name="personalTopicBT"]');
let topicIdContainer = document.getElementById('topicIdContainer');
let groupTopicsContainer = document.getElementById('groupTopicsContainer');
let groupTopicsBT = document.querySelector('button[name="groupTopicsBT"]');
let directTopicsContainer = document.getElementById('directTopicsContainer');
let directTopicsBT = document.querySelector('button[name="directTopicsBT"]');
let getTopicByIdContainer = document.getElementById('getTopicByIdContainer');
let getTopicByIdBT = document.querySelector('button[name="getTopicByIdBT"]');
let joinTopicByIdContainer = document.getElementById('joinTopicByIdContainer');
let joinTopicByIdBT = document.querySelector('button[name="joinTopicByIdBT"]');
let listContainer = document.getElementById('listContainer');
let getMessagesBT = document.querySelector('button[name="getMessagesBT"]');
let getPostsBT = document.querySelector('button[name="getPostsBT"]');
let getTasksBT = document.querySelector('button[name="getTasksBT"]');
let joinPersonalTopicBT = document.querySelector('button[name="joinPersonalTopicBT"]');
let createTaskBT = document.querySelector('button[name="createTaskBT"]');
let createPostBT = document.querySelector('button[name="createPostBT"]');
let sendMessageBT = document.querySelector('button[name="sendMessageBT"]');
let deleteMessageBT = document.querySelector('button[name="deleteMessageBT"]');
let joinSpaceBT = document.querySelector('button[name="joinSpaceBT"]');
let unjoinSpaceBT = document.querySelector('button[name="unjoinSpaceBT"]');
let collaborationDropBox = document.getElementById("collaboration");
let isActive = document.getElementById('isActive');
let isPresenting = document.getElementById('isPresenting');
let isPaused = document.getElementById('isPaused');
let startScreenSharingBT = document.querySelector('button[name="startScreenSharingBT"]');
let pauseScreenSharingBT = document.querySelector('button[name="pauseScreenSharingBT"]');
let resumeScreenSharingBT = document.querySelector('button[name="resumeScreenSharingBT"]');
let endScreenSharingBT = document.querySelector('button[name="endScreenSharingBT"]');
let pauseCollaborationBT = document.querySelector('button[name="pauseCollaborationBT"]');
let resumeCollaborationBT = document.querySelector('button[name="resumeCollaborationBT"]');
let videoPreview = document.getElementById('sharingPreview');


startAudioBT.disabled = true;
startVideoBT.disabled = true;
endCallBT.disabled = true;
leaveBT.disabled = true;

let topic;
let topicService;
const myTopic = {};

startBT.onclick = async function () {
	let jwt = document.getElementById('tokenInput').value;
	// For roster to show up, use the JWT token from a guest user that is loggged to your meeting room.
	let credentialProvider = new CredentialProvider('jwt', jwt);
	cloudConnect = new CloudCommunication();
	await cloudConnect.start(credentialProvider);
	topicService = cloudConnect.topicService;
	startBT.disabled = true;
	startAudioBT.disabled = false;
	startVideoBT.disabled = false;
	leaveBT.disabled = false;
	topic = await topicService.getPersonalTopic();
	myTopic.id = topic.id; 
}

personalTopicBT.onclick = async function () {
	let personalTopic = await topicService.getPersonalTopic();
	topicIdContainer.innerHTML = '<p>Your personal topic id:<b>' + personalTopic.id + '</b></p>';
}

groupTopicsBT.onclick = async function () {
	let groupTopics = await topicService.getMyGroupTopics();
	groupTopics = groupTopics.data;
	let html = '';
	groupTopics.forEach((element)=>{
		html += '<p> <b>Title:</b> '+ element.title + ', <b>Topic Id:</b> ' + element._id + '</p>';
	})
	groupTopicsContainer.innerHTML = html;
}

directTopicsBT.onclick = async function () {
	let directTopics = await topicService.getMyDirectTopics();
	directTopics = directTopics.data;
	let html = '';
	directTopics.forEach((element)=>{
		html += '<p> <b>Title:</b> '+ element.title + ', <b>Topic Id:</b> ' + element._id + '</p>';
	})
	directTopicsContainer.innerHTML = html;
}

joinPersonalTopicBT.onclick = async function () {
	await topicService.joinPersonalTopic();
}

getTopicByIdBT.onclick = async function () {
	let topicId = document.getElementById('topicIdInput').value;
	topic = await topicService.getTopicById(topicId);
	getTopicByIdContainer.innerHTML = '<p><b>Title:</b>'+ topic.title +'<br><b>Created:</b> '+ topic.created + '<br><b>Topic Id:</b> ' + topic.id + '<br><b>isMyPersonalTopic:</b> '+ topic.isMyPersonalTopic + '<br><b>Role:</b> '+ topic.role + '<br><b>lastAccess:</b> '+ topic.lastAccess + '<br><b>Type:</b> '+ topic.type + '</p>';
}

joinTopicByIdBT.onclick = async function () {
	let topicId = document.getElementById('joinTopicIdInput').value;
	topic = await topicService.joinTopicById(topicId);
	joinTopicByIdContainer.innerHTML = '<p><b>Title:</b>'+ topic.title +'<br><b>Created:</b> '+ topic.created + '<br><b>Topic Id:</b> ' + topic.id + '<br><b>isMyPersonalTopic:</b> '+ topic.isMyPersonalTopic + '<br><b>Role:</b> '+ topic.role + '<br><b>lastAccess:</b> '+ topic.lastAccess + '<br><b>Type:</b> '+ topic.type + '</p>';
}

getMessagesBT.onclick = async function () {
	let messages = await topic.getMessages(5);
	messages = messages.data;
	let html = '';
	messages.forEach((element)=>{
		html += '<p> <b>Id: </b> '+ element._id + ', <b>Message: </b> ' + element.content.bodyText + '</p>';
	})
	listContainer.innerHTML = html;
}

getPostsBT.onclick = async function () {
	let posts = await topic.getPosts(5);
	posts = posts.data;
	let html = '';
	posts.forEach((element)=>{
		html += '<p> <b>Id: </b> '+ element._id + ', <b>Post: </b> ' + element.content.bodyText + '</p>';
	})
	listContainer.innerHTML = html;
}

getTasksBT.onclick = async function () {
	let tasks = await topic.getTasks(10);
	tasks = tasks.data;
	let html = '';
	tasks.forEach((element)=>{
		html += '<p> <b>Id: </b> '+ element._id + ', <b>Task: </b> ' + element.content.bodyText + '</p>';
	})
	listContainer.innerHTML = html;
}

createTaskBT.onclick = async function () {
	let task = document.getElementById('taskInput').value;
	let content = {bodyText: task};
	await topic.createTask(content,[],'',0);
};

createPostBT.onclick = async function () {
	let post = document.getElementById('postInput').value;
	let content = {bodyText: post};
	await topic.createPost(content);
};

sendMessageBT.onclick = async function () {
	let message = document.getElementById('messageInput').value;
	let content = {bodyText: message};
	await topic.sendMessage(content);
};

deleteMessageBT.onclick = async function (){
	let messageId = document.getElementById('deleteMessageInput').value;
	await topic.deleteMessages([messageId]);
};

joinSpaceBT.onclick = async function () {
	await topic.join();
};

unjoinSpaceBT.onclick = async function () {
	await topic.unjoin();
};

startAudioBT.onclick = function() {
	let collaborationEnabled = collaborationDropBox.value === 'true';
	call = cloudConnect.callService.createCallForTopic(myTopic);
	call.setAudioMode(AudioMode.SEND_RECEIVE);
	call.setWebCollaboration(collaborationEnabled);
	
	call.addOnMediaConnectedCallback((c) => {
		console.log ("*** Media Connected");
	});
	
	call.addOnCallFailedCallback((c) => {
		console.log ("*** Call Failed");
	});
	
	call.addOnCallEndedCallback((c) => {
		console.log ("*** Call Ended");
	});
	
	call.start();
	startAudioBT.disabled = true;
	startVideoBT.disabled = true;
	endCallBT.disabled = false;

	call.collaboration.addOnAvailableCallback(()=>{
		console.log('Collaboration available');
	});
};

startVideoBT.onclick = function() {
	let collaborationEnabled = collaborationDropBox.value === 'true';
	call = cloudConnect.callService.createCallForTopic(myTopic);
	call.setAudioMode(AudioMode.SEND_RECEIVE);
	call.setVideoMode(VideoMode.SEND_RECEIVE);
	call.setWebCollaboration(collaborationEnabled);
	
	call.insertLocalVideo('local-video-div');
	call.insertRemoteVideo('remote-video-div');
	
	call.addOnCallFailedCallback((c) => {
		console.log ("*** Call Failed");
	});
	
	call.addOnCallEndedCallback((c) => {
		console.log ("*** Call Ended");
	});
	
	monitorcall();
    call.start().then(() => {
		document.getElementById('establishedTime').innerHTML = call.establishedTime;
	});
	
	startAudioBT.disabled = true;
	startVideoBT.disabled = true;
	endCallBT.disabled = false;

	call.collaboration.addOnAvailableCallback(()=>{
		console.log('Collaboration available');
	});
	call.collaboration.addOnEndedCallback(()=>{
		console.log('Collaboration ended');
	});
	call.collaboration.addOnUnavailableCallback(()=>{
		console.log('Collaboration unavailable');
	});
	call.collaboration.addOnNearEndByEjectCallback(()=>{
		console.log('Collaboration near end ejected');
	});

	call.collaboration.contentSharing.addOnStartedCallback(()=>{
		let renderer = new CloudCommunicationRenderer();
		renderer.insertRenderer(call.collaboration.contentSharing.contentSharingForRenderer,'konvaCanvas');
		console.log('Contentsharing started');
		updateScreenSharingStates();
	});

	call.collaboration.contentSharing.addOnPausedCallback(()=>{
		console.log('Contentsharing paused');
		updateScreenSharingStates();
	});

	call.collaboration.contentSharing.addOnEndedCallback(()=>{
		console.log('Contentsharing ended');
		updateScreenSharingStates();
	});

	call.collaboration.contentSharing.addOnResumedCallback(()=>{
		console.log('Contentsharing resumed');
		updateScreenSharingStates();
	});
};
	

endCallBT.onclick = function() {
	if (!!call) {
		call.end();
		startAudioBT.disabled = false;
		startVideoBT.disabled = false;
		endCallBT.disabled = true;
	}
};
	
leaveBT.onclick = function() {
	if (!!cloudConnect) {
		cloudConnect.stop();
		startAudioBT.disabled = true;
		startVideoBT.disabled = true;
		endCallBT.disabled = true;
		leaveBT.disabled = true;
		joinBT.disabled = false;
	}
};

pauseCollaborationBT.onclick = function () {
	call.collaboration.pause();
}

resumeCollaborationBT.onclick = async function () {
	call.collaboration.resume();
}

startScreenSharingBT.onclick = function () {
	call.collaboration.contentSharing.startScreenSharing();
};

pauseScreenSharingBT.onclick = function () {
	call.collaboration.contentSharing.pause();
};

resumeScreenSharingBT.onclick = function () {
	call.collaboration.contentSharing.resume();
};

endScreenSharingBT.onclick = function () {
	call.collaboration.contentSharing.end();
};

const updateScreenSharingStates = function () {
	isActive.innerHTML = call.collaboration.contentSharing.isActive;
	isPresenting.innerHTML = call.collaboration.contentSharing.isPresenting;
	isPaused.innerHTML = call.collaboration.contentSharing.isPaused;
	videoPreview.srcObject = call.collaboration.contentSharing.outgoingScreenSharingStream;
}

const updateMediaConnectedState = function() {
	document.getElementById('isMediaConnected').innerHTML = call.isMediaConnected;
};

const updateServiceAvailableState = function() {
	document.getElementById('isServiceAvailable').innerHTML = cloudConnect.isServiceAvailable;
};
	
const monitorcall = function() {		
	updateServiceAvailableState();
	updateMediaConnectedState();
	
	call.addOnMediaConnectedCallback(function(call) {
		updateMediaConnectedState(call);
		monitorVideo(call.videoChannel);
		call.videoChannel.addOnVideoChannelUpdatedCallback(function(videoChannel) {
			monitorVideo(videoChannel);
		});
	});
	
	call.addOnMediaDisconnectedCallback(function(call) {
		updateMediaConnectedState(call);
	});

	cloudConnect.addOnServiceAvailableCallback(function() {
		updateServiceAvailableState();
	});

	cloudConnect.addOnServiceUnavailableCallback(function() {
		updateServiceAvailableState();
	});
};

const monitorVideo = function(videoChannel) {
	document.getElementById('isCameraDenied').innerHTML = videoChannel.isCameraAccessDenied;
	document.getElementById('deniedReason').innerHTML = videoChannel.cameraDenialReason;
	document.getElementById('isVideoDisabled').innerHTML = videoChannel.isDisabled;
	document.getElementById('disabledReason').innerHTML = videoChannel.disabledReason;
	document.getElementById('isSendVideoNegotiated').innerHTML = videoChannel.isSendVideoNegotiated;
	document.getElementById('isReceiveVideoNegotiated').innerHTML = videoChannel.isReceiveVideoNegotiated;
}



let muteBT = document.querySelector('button[name="muteAudio"]');	
muteBT.onclick = function muteAudio() {
	call.audioChannel.addOnAudioStreamUpdatedCallback(function(audioChannel, mediaStream) {
		console.log("Received audio channel stream updates event:" + mediaStream.id);
	});

	if (!call.audioChannel.muted && call.audioChannel.muteCapability.isAllowed) {
		let localStream = call.audioChannel.localStream;
		let remoteStream = call.audioChannel.remoteStream;
		call.audioChannel.mute().then(function() {
			document.getElementById('isAudioMuted').innerHTML = call.audioChannel.muted;
		});
	}
};


let unmuteBT = document.querySelector('button[name="unmuteAudio"]');	
unmuteBT.onclick = function unmuteAudio() {
	if (call.audioChannel.muted && call.audioChannel.unmuteCapability.isAllowed) {
		call.audioChannel.unmute().then(function() {
			document.getElementById('isAudioMuted').innerHTML = call.audioChannel.muted;
		});
	}
};


let muteSpeakerBT = document.querySelector('button[name="muteSpeaker"]');	
muteSpeakerBT.onclick = function muteSpeaker() {
	if (!call.audioChannel.speakerMuted && call.audioChannel.muteSpeakerCapability.isAllowed) {
		call.audioChannel.muteSpeaker().then(function() {
			document.getElementById('isSpeakerMuted').innerHTML = call.audioChannel.speakerMuted;
		});
	}
};


let unmuteSpeakerBT = document.querySelector('button[name="unmuteSpeaker"]');	
unmuteSpeakerBT.onclick = function unmuteSpeaker() {
	if (call.audioChannel.speakerMuted && call.audioChannel.unmuteSpeakerCapability.isAllowed) {
		call.audioChannel.unmuteSpeaker().then(function() {
			document.getElementById('isSpeakerMuted').innerHTML = call.audioChannel.speakerMuted;
		});
	}
};

let blockCameraBT = document.querySelector('button[name="blockCamera"]');	
blockCameraBT.onclick = function blockCamera() {
	if (call.videoChannel.isSendVideoNegotiated && 
		call.videoChannel.isReceiveVideoNegotiated &&
		call.videoChannel.setVideoModeCapability.isAllowed) {
		call.setVideoMode(VideoMode.RECEIVE_ONLY);
	}
};

let unblockCameraBT = document.querySelector('button[name="unblockCamera"]');	
unblockCameraBT.onclick = function unblockCamera() {
	if (call.videoChannel.isReceiveVideoNegotiated && 
		!call.videoChannel.isSendVideoNegotiated &&
		call.videoChannel.setVideoModeCapability.isAllowed) {
		call.setVideoMode(VideoMode.SEND_RECEIVE);
	}
};

let removeVideoBT = document.querySelector('button[name="removeVideo"]');	
removeVideoBT.onclick = function removeVideo() {
	if (!call.videoChannel.isDisabled &&
		call.videoChannel.setVideoModeCapability.isAllowed) {
		call.setVideoMode(VideoMode.DISABLE);
	}
};

let muteVideoBT = document.querySelector('button[name="muteVideo"]');	
muteVideoBT.onclick = function muteVideo() {
	if (!call.videoChannel.muted) {
		call.videoChannel.mute().then(function() {
			document.getElementById('isVideoMuted').innerHTML = call.videoChannel.muted;
		});
	}
};

let unmuteVideoBT = document.querySelector('button[name="unmuteVideo"]');	
unmuteVideoBT.onclick = function unmuteVideo() {
	if (call.videoChannel.muted) {
		call.videoChannel.unmute().then(function() {
			document.getElementById('isVideoMuted').innerHTML = call.videoChannel.muted;
		});
	}
};

let to360pBT = document.querySelector('button[name="to360p"]');	
to360pBT.onclick = function to360p() {
	if (call.videoChannel && call.videoChannel.updatePreferredReceiveResolutionCapability.isAllowed) {
		call.videoChannel.setPreferredReceiveResolution(VideoResolutionFactory.resolution360p).then(function() {
			document.getElementById('preferredResolution').innerHTML = call.videoChannel.preferredReceiveResolution;
		});
	}
};
