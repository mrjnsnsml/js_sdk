/*
 * Avaya Inc. Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to company instructions.
 * Copyright 2021 Avaya Inc. All Rights Reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual or
 * intended publication of such source code.
 */
import { AvayaMedia, Callbacks, AudioMode, VideoMode, AudioChannel, VideoChannel, Collaboration, VideoResolutionFactory} from 'avayamedia';
import DeviceService from './services/device/deviceService.js';
import CallService from './services/call/callService_api.js';
import TopicServiceHelper from './services/topic/topicServiceHelper.js';
import TopicService from './services/topic/topicService_api.js';
import CredentialProvider from './config/credentialProvider_api.js';
import NetworkProviders, {SOCKET_IO_NAMESPACE} from './base/network/networkProviders.js';
import Utils from './base/utils.js';
import Logger from './base/logger.js';
import TokenType from './config/tokenType_api';
import EnvironmentType from './environmentType_api';

const CONFIGURATION_PRODUCTION_URL = 'https://spacesapis.avayacloud.com/api/service-configurations';
const CONFIGURATION_TESTING_URL = 'https://logantestingapis.esna.com/api/service-configurations';
const ME_URL_PATH = '/api/users/me';

/**
 * @hideconstructor  
 */
export default class CloudCommunication {
    #avayaMediaInstance = undefined;
    #networkProviders;
    #deviceService = undefined;
    #topicServiceHelper = undefined;
    #callService = undefined;
    #topicService = undefined;
    #isServiceAvailable = false;
    #onServiceAvailableCallback = new Callbacks();
    #onServiceUnavailableCallback = new Callbacks();

    constructor() {
        this.#networkProviders = new NetworkProviders();   
        this.#deviceService = new DeviceService();
        this.#topicServiceHelper = new TopicServiceHelper();
        this.#topicService = new TopicService(this.#topicServiceHelper);
    }

    /**
    * Initializes and start Cloud Communication.
    * @param {CredentialProvider} credentialProvider 
    * @returns {Promise<undefined|CommunicationException>}
    */
    async start( credentialProvider, envType = EnvironmentType.PRODUCTION ) {
        return new Promise((resolve, reject) => {        
            if(!!this.#avayaMediaInstance) {
                this.#avayaMediaInstance.stop()
                    .catch((err) => {
                        Logger.error('Failed to stop AvayaMedia. Reason: ', err.name);
                    });
            } else {
                this.#avayaMediaInstance = new AvayaMedia();
                this.#callService = new CallService(this.#avayaMediaInstance, this.#networkProviders);
            }            

            Logger.logger = AvayaClientServices.Base.Logger;

            this.#avayaMediaInstance.registerLogger(window.console);
            this.#avayaMediaInstance.start().then(() => {
                Logger.info('Starting CloudCommunication');
            });

            const url = envType === EnvironmentType.PRODUCTION ? CONFIGURATION_PRODUCTION_URL : CONFIGURATION_TESTING_URL;

            this.#networkProviders.createRestProvider(credentialProvider);        
            this.#networkProviders.restProvider.get(url).then((response) => {  
                const userinfoUrl = response.spaces.server_url + ME_URL_PATH;           
                this.#networkProviders.restProvider.get(userinfoUrl)
                .then((userResponse) => {
                    const userInfo = Utils.createUserInfo(userResponse);
                    this.#networkProviders.createSocketIoProvider(response.spaces.socketio_server_url);
                    this.#networkProviders.socketIoProvider.onMessage('PRESENCE_EVENT_RESPONSE', (payload) => {
                        console.log(payload);
                    })
                    this.#networkProviders.socketIoProvider.onOpen = () => {
                        this.#networkProviders.restProvider.serverUrl =  response.spaces.server_url;                           
                        this.#callService.userInfo = userInfo;
                        this.#topicServiceHelper.userInfo = userInfo;
                        this.#topicServiceHelper.networkProviders = this.#networkProviders;
                        this.#isServiceAvailable = true;
                        this.#onServiceAvailableCallback.fire();

                        // TODO: Remove if Topic Service implements this
                        this.#networkProviders.socketIoProvider.addEventsListener(['CHANNEL_SUBSCRIBED', 'MESSAGE_SENT'], (event, payload) => {
                            Logger.info('Received IO Socket event:', event, ' payload:', payload);
                        });
                        resolve();
                    };

                    this.#networkProviders.socketIoProvider.onConnectionError = (error) => {
                        Logger.error("Failed to connect to", response.spaces.socketio_server_url + SOCKET_IO_NAMESPACE);
                        this.#isServiceAvailable = false;
                        this.#onServiceUnavailableCallback.fire();
                        reject(error);
                    };

                    this.#networkProviders.socketIoProvider.onClose = () => {
                        this.#isServiceAvailable = false;
                        this.#onServiceUnavailableCallback.fire();
                    };

                    this.#networkProviders.socketIoProvider.start();
                }).catch((uerr)  => {
                    Logger.error("Error retrieving userinfo", uerr);
                    reject(uerr);
                });
            }).catch((err)  => {
                Logger.error("Error retrieving configurations", err);
                reject(err);
            });
        });
    }

    /**
    * Ends Cloud Communication.
    * @returns {Promise<undefined|CommunicationException>}
    */
    stop() {
        Logger.info('Stopping CloudCommunication');
        this.#avayaMediaInstance.stop()
            .catch((err) => {
                Logger.error("Failed to stop AvayaMedia. Reason:", err.name);
            })
            .finally(() => {
                // TODO: Remove if Topic Service implements this
                // this.#networkProviders.socketIoProvider.send('UNSUBSCRIBE_CHANNEL', payload);
                this.#networkProviders.socketIoProvider.close();
            });
    }

    /**
     * Registers a logger to be used by the SDK. By default, timestamps will be included in each log. console.log can be passed as the logger if desired or a custom logger can be provided.
     *
     * @param {object} logger 
     * @param {boolean} disableTimestamps - Set to true to disable 
     * timestamps in the logs.
     */
     static registerLogger(logger, disableTimestamps = false) {
        Logger.addLogger(logger, disableTimestamps);
    }

    /**
     * @returns {Promise<UserInfo|CommunicationException>}
     */
    get userInfo() {
        return Promise.reject("NOT implemented yet");
    }

    /**
     * True if service is available
     */
    get isServiceAvailable() {
        return this.#isServiceAvailable;
    }

    /**
     * Interface for the callback function to be invoked when the signaling path of the session is
     * available.
     *
     * @group Callbacks
     * @callback OnServiceAvailableCallback
     */

    /**
    * @param {OnServiceAvailableCallback} callback The function to be executed and added callback when the session's signaling connection is available.
    *
    */
    addOnServiceAvailableCallback(callback) {
        this.#onServiceAvailableCallback.add(callback);
    }

    /**
    * @param {OnServiceAvailableCallback} callback The function to be executed and removed callback when the session's signaling connection is available.
    */
    removeOnServiceAvailableCallback(callback) {
        this.#onServiceAvailableCallback.remove(callback);
    }


    /**
    * Interface for the callback function to be invoked when the signaling path of the session is
    * not available.
    *
    * @group Callbacks
    * @callback OnServiceUnavailableCallback
    */

    /**
    * @param {OnServiceUnavailableCallback} callback The function to be executed and added callback when the session's signaling connection is unavailable.
    *
    */
    addOnServiceUnavailableCallback(callback) {
        this.#onServiceUnavailableCallback.add(callback);
    }

    /**
    * @param {OnServiceUnavailableCallback} callback The function to be executed and removed callback when the session's signaling connection is unavailable.
    */
    removeOnServiceUnavailableCallback(callback) {
        this.#onServiceUnavailableCallback.remove(callback);
    }

    get callService() {
        return this.#callService;
    }

    get topicService(){
        return this.#topicService;
    }
}

export {CredentialProvider, AudioChannel, VideoChannel, AudioMode, VideoMode, Collaboration, VideoResolutionFactory, TokenType, EnvironmentType};
