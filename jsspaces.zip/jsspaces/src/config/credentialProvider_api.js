/*
 * Avaya Inc. Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to company instructions.
 * Copyright 2021 Avaya Inc. All Rights Reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual or
 * intended publication of such source code.
 */

import {Callbacks} from 'avayamedia';
import TokenType from './tokenType_api';

export default class CredentialProvider {
    #token;
    #tokenType;
    #onInvalidCredentialsCallback = new Callbacks();

    /**
     * 
     * @param {TokenType} tokenType 
     * @param {String} token 
     */
    constructor(tokenType, token) {
        this.#token = token;
        this.#tokenType = tokenType;
    }

    /**
     * Overrides credentials token
     * @param {TokenType} tokenType 
     * @param {String} token 
     */
    setToken (tokenType, token) {
        this.#token = token;
        this.#tokenType = tokenType; 
    }

    get token() {
        return this.#token;
    }

    get tokenType() {
        return this.#tokenType;
    }

    _triggerInvalidCredential(errorCode, errorReason) {
        this.#onInvalidCredentialsCallback.fire(errorCode, errorReason);
    }

    /**
     * Interface for the callback function to be invoked when the signaling path of the session is
     * available.
     *
     * @group Callbacks
     * @callback OnInvalidCredentialsCallback
     * @param CredentialProvider
     */

    /**
    * @param {OnInvalidCredentialsCallback} callback The function to be executed and added callback when the credentials are invalid.
    *
    */
     addOnInvalidCredentialsCallback(callback) {
        this.#onInvalidCredentialsCallback.add(callback);
    }

    /**
    * @param {OnInvalidCredentialsCallback} callback The function to be executed and removed callback when the credentials are invalid.
    */
    removeOnInvalidCredentialsCallback(callback) {
        this.#onInvalidCredentialsCallback.remove(callback);
    }

    toString() {
        return 'tokenType=' + this.#tokenType + '&token=' + this.#token;
    }
}