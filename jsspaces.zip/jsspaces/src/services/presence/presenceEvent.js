/*
 * Avaya Inc. Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to company instructions.
 * Copyright 2021 Avaya Inc. All Rights Reserved.
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual or
 * intended publication of such source code.
 */

import MediaSession from '../media/mediaSession.js';

export default class PresenceEvent {
    /**
     * @param {String} topicId 
     * @param {String} category 
     * @param {MediaSession} mediaSession
     * @param {MediaSessionSender} sender
     */
    constructor(topicId, category, offline, idle, sender, version='1.1', role='admin', receivers=[]) {
        /**
         * Unique identified for the space the media session is part of
         * @type {String} topicId
         */
        this.topicId = topicId;
        /**
         * The type of media session event
         * @type {String} category
         */
        this.category = category;
        /**
         * Current state of media session
         * @type {MediaSession} content
         */
        this.mediaSession = {};
    
        /**
         * Information about the sender
         * @type {MediaSessionSender} sender 
         */
        this.sender = sender;
    
        this.idle = idle;

        this.offline = offline;

        this.role = role;

        this.receivers = receivers;

        this.desktop = false;

        /**
         * Timestamp of when message item was created.
         * @type {String} createdTime
         */
        this.subscribeTime = new Date().toISOString();

        this.version = version;
    }

    json() {
        return {
            topicId: this.topicId,
            category:  this.category,
            sender: this.sender.json(),
            receivers: this.receivers,
            content: {
                desktop: this.desktop,
                mediaSession: this.mediaSession,
                role: this.role,
                idle: this.idle,
                offline: this.offline,
                subscribeTime: this.subscribeTime
            },
            version: this.version
        };
    }
}