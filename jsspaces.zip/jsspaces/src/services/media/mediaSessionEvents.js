/*
 * Avaya Inc. Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to company instructions.
 * Copyright 2021 Avaya Inc. All Rights Reserved.
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual or
 * intended publication of such source code.
 */

import MediaSession from './mediaSession.js';

export default class MediaSessionEvents {
    /**
     * @param {String} topicId 
     * @param {String} category 
     * @param {MediaSession} mediaSession
     * @param {MediaSessionSender} sender
     * @param {String} [remoteStreamId] 
     */
    constructor(topicId, category, mediaSession, sender, subscribedTime, remoteStreamId=undefined, data=[], version='1.1') {
        /**
         * Unique identified for the space the media session is part of
         * @type {String} topicId
         */
        this.topicId = topicId;
        /**
         * The type of media session event
         * @type {String} category
         */
        this.category = category;
        /**
         * Current state of media session
         * @type {MediaSession} content
         */
        this.mediaSession = mediaSession;
        /**
         * Information about the sender
         * @type {MediaSessionSender} sender 
         */
        this.sender = sender;
        /**
         * Remote stream id
         * @type {String}
         */
        this.remoteStreamId = remoteStreamId;
        /**
         * @type {boolean}
         */
        this.isCollabOnly = false; // TODO
        /**
         * Timestamp of when message item was created.
         * @type {String} createdTime
         */
        this.createdTime = new Date().toISOString();

        this.subscribeTime = subscribedTime;
        /**
         * Optional data
         * @type {[*]} data 
         */
        this.data = data;

        this.version = version;
    }

    json() {
        const result = {
            topicId: this.topicId,
            category:  this.category,
            sender: this.sender.json(),
            data: this.data,
            version: this.version,
            content: {
                subscribeTime: this.subscribeTime,
                isCollabOnly: this.isCollabOnly
            },
            created: this.createdTime
        };

        if (this.mediaSession) {
            result.content.mediaSession = this.mediaSession.json();

            if (this.remoteStreamId) {
                result.content.streamId = this.remoteStreamId;
            }
        }                    
        return result;
    }
}