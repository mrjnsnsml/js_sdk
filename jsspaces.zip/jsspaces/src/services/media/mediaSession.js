/*
 * Avaya Inc. Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to company instructions.
 * Copyright 2021 Avaya Inc. All Rights Reserved.
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual or
 * intended publication of such source code.
 */

export default class MediaSession {
    #collabOnly;

	constructor(audio=true, video=false, collabOnly=false) {
		/**
		 * Is sending audio enabled
		 * @type {boolean}
		 */
		this.audio = audio;
        /**
         * Is sending video enabled
         * @type {boolean}
         */
        this.video = video; 
        /**
		 * Is collaboration only enabled
		 * @type {boolean}
		 */
		this.isCollabOnly = collabOnly;
       /**
         * Is Is muted locally
         * @type {boolean}
         */
        this.selfMuted = false;
		/**
		 * Is the media session connected
		 * @type {boolean}
		 */
		this.connected = false;

        this.phone = false;
		/**
		 * Exact date when the user has joined the topic
		 * @type {String}
		 */
		this.joinTime = new Date().toISOString();

        /** 
         * Session Id 
         * @type {String}
         */
        this.mdsrvSessionId = '';
	}

    get isCollabOnly() {
        return this.#collabOnly;
    }

    set isCollabOnly(isCollabOnly) {
        if (isCollabOnly) {
            this.audio = false;
            this.video = false;
        }
        this.#collabOnly = isCollabOnly;
    }

    json() {
        return {
            video: this.video,
            audio: this.audio,
            connected: this.connected,
            screenshare: this.screenshare,
            selfMuted: this.selfMuted,
            phone: this.phone,
            joinTime: this.joinTime
        };
    }
}