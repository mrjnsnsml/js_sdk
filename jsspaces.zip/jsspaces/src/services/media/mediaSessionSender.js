
/*
 * Avaya Inc. Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to company instructions.
 * Copyright 2021 Avaya Inc. All Rights Reserved.
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual or
 * intended publication of such source code.
 */

export default class MediaSessionSender {
    /**
     * @param {*} userReponse 
     */
    constructor(userInfo) {
        this.id = userInfo.id;
        this.type = userInfo.type;
        this.username = userInfo.username;
        this.displayName = userInfo.displayName;
        this.pictureUrl = userInfo.pictureUrl;
    }

    json() {
        return {
            _id: this.id,
            type: this.type,
            username: this.username,
            displayname: this.displayName,
            picture_url: this.pictureUrl
        };
    }
}