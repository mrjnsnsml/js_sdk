/*
 * Avaya Inc. Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to company instructions.
 * Copyright 2021 Avaya Inc. All Rights Reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual or
 * intended publication of such source code.
 */

import Logger from '../../base/logger.js';

export default class PagingDataSetHelper {
    #data = [];
    #hasNextPage = false;
    #onDataChangedCallback = undefined;
    #nextPageUrl = '';
    #restProvider;

    /**
     * Returns the rest provider
     * @returns {RestProvider}
     */
    get restProvider(){
        return this.#restProvider;
    }

    /**
     * Sets the rest provider
     * @param {RestProvider}
     */
    set restProvider(restProvider){
        this.#restProvider = restProvider;
    }

    /**
     * Returns true if there is additional page; otherwise, false.
     * @returns {Boolean}
     */
    get hasNextPage() {
        return this.#hasNextPage;
    }

    /**
     * Sets true if there is additional page; otherwise, false.
     * @param {Boolean} hasNextPage
     */
    set hasNextPage(hasNextPage){
        this.#hasNextPage = hasNextPage;
    }

    /**
     * Sets next page url 
     * @param {String} nextPageUrl
     */
    set nextPageUrl(nextPageUrl){
        this.#nextPageUrl = nextPageUrl;
    }

    /**
     * Returns next page url
     * @returns {String}
     */
    get nextPageUrl(){
        return this.#nextPageUrl;
    }

    /**
     * Returns the next set of paging data.
     * @returns {Promise<PagingDataSet>}
     */
    async getNextPage() {
        return new Promise((resolve,reject)=>{
            if(this.#hasNextPage){
                this.#restProvider.get(this.#nextPageUrl).then((response)=>{
                    this.#data = [...this.#data, ...response.data];
                    if(response.nextPageUrl===''){
                        this.#hasNextPage = false;
                    } else{
                        this.#hasNextPage = true;
                        this.#nextPageUrl = response.nextPageUrl;
                    }
                    resolve(response.data);
                })
                .catch((error)=>{
                    Logger.error("Error getting group topics", error);
                    reject(error);
                });
            }else{
                reject('hasNextPage is false, there isn\'t any next page to fetch data');
            }
        })
    }

    /**
     * Returns the data.
     * @returns {Array}
     */
    get data(){
        return this.#data;
    }

    /**
     * Sets the data.
     * @param {Array}
     */
    set data(dataSet){
        this.#data = dataSet;
        this.#onDataChangedCallback.fire();
    }

    registerCallback(onDataChangedCallback){
        this.#onDataChangedCallback = onDataChangedCallback;
    }
}