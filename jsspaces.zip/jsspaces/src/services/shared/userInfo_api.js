/*
 * Avaya Inc. Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to company instructions.
 * Copyright 2021 Avaya Inc. All Rights Reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual or
 * intended publication of such source code.
 */

class PhoneNumber  {
    constructor(type, formattedType, value, canonicalForm) {
        this.value = value;
        this.canonicalForm = canonicalForm;
        this.type = type;
        this.formattedType = formattedType;
        this.identity = false;
        this.login = false;
        this.primary = false;
        this.private_num = false;
        this.unique = false;
        this.verified = false;
    }
}

class EmailAddress  {
    constructor(value, primary) {
        this.primary = primary;
        this.value = value;
        this.label = '';
        this.type = '';
        this.relationdef_id = '';
    }
}

export default class UserInfo {
    #id;
    #type;
    #username;
    #displayName;
    #familyName;
    #givenName;
    #middleName;
    #honorificPrefix = '';
    #honorificSuffix = '';
    #pronunciation = '';
    #pronunciationUrl = '';
    #pictureUrl = '';
    #timezone = '';
    #emailAddresses = [];
    #phoneNumbers = [];

    /**
     * @param {String} id
     * @param {String} type
     * @param {String} username 
     * @param {String} displayName 
     * @param {String} [familyName] 
     * @param {String} [givenName] 
     * @param {String} [middleName] 
     */
    constructor(id, type, username, displayName, familyName='', givenName='', middleName='') {
        this.#id = id;
        this.#type = type;
        this.#username = username;
        this.#displayName = displayName;
        this.#familyName = familyName;
        this.#givenName = givenName;
        this.#middleName = middleName;
    }
 
    get id() {
        return this.#id;
    }

    get type() {
        return this.#type;
    }

    set type(aType) {
        this.#type = aType;
    }

    get username() {
        return this.#username;
    }

    get displayName() {
        return this.#displayName;
    }

    get familyName() {
        return this.#familyName;
    }

    get givenName() {
        return this.#givenName;
    }

    get middleName() {
        return this.#middleName;
    }

    get honorificPrefix() {
        return this.#honorificPrefix;
    }

    set honorificPrefix(prefix) {
        this.#honorificPrefix = prefix;
    }

    get honorificSuffix() {
        return this.#honorificSuffix;
    }

    set honorificSuffix(suffix) {
        this.#honorificSuffix = suffix;
    }

    get pronunciation() {
        return this.#pronunciation;
    }

    set pronunciation(nunciation) {
        this.#pronunciation = nunciation;
    }

    get pronunciationUrl() {
        return this.#pronunciationUrl;
    }

    set pronunciationUrl(url) {
        this.#pronunciationUrl = url;
    }

    get pictureUrl() {
        return this.#pictureUrl;
    }

    set pictureUrl(url) {
        this.#pictureUrl = url;
    }

    get timezone() {
        return this.#timezone;
    }

    set timezone(tz) {
        this.#timezone = tz;
    }

    get emailAddresses() {
        return this.#emailAddresses;
    }

    set emailAddresses(emails) {
        this.#emailAddresses = emails;
    }

    get phoneNumbers() {
        return this.#phoneNumbers;
    }

    set phoneNumbers(numbers) {
        this.#phoneNumbers = numbers;
    }
}

export {PhoneNumber, EmailAddress};