/*
 * Avaya Inc. Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to company instructions.
 * Copyright 2021 Avaya Inc. All Rights Reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual or
 * intended publication of such source code.
 */

import {Callbacks} from 'avayamedia';

/**
 * This class represents the pagingDataset.
 * @hideconstructor
 */
export default class PagingDataSet {
    #dataSetHelper;
    #onDataChangedCallback = new Callbacks();

    constructor(dataSetHelper){
        this.#dataSetHelper = dataSetHelper;
        this.#dataSetHelper.registerCallback(this.#onDataChangedCallback);
    }

    /**
     * Returns true if there is additional page; otherwise, false.
     * @returns {Boolean}
     */
    get hasNextPage() {
        return this.#dataSetHelper.hasNextPage;
    }

    /**
     * Returns next page url
     * @returns {String}
     */
    get nextPageUrl(){
        return this.#dataSetHelper.nextPageUrl;
    }

    /**
     * Returns the next set of paging data.
     * @returns {Promise<PagingDataSet>}
     */
    async getNextPage() {
        return this.#dataSetHelper.nextPage();
    }

    /**
     * Returns the data.
     * @returns {Array}
     */
    get data(){
        return this.#dataSetHelper.data;
    }

    /**
     * Interface for the callback function to be invoked when there is a paging data changed.
     *
     * @group Callbacks
     * @callback OnDataChangedCallback
     */

    /**
    * @param {OnDataChangedCallback} callback The function to be executed and added callback when paging data set has changed.
    *
    */
     addOnDataChangedCallback(callback) {
        this.#onDataChangedCallback.add(callback);
    }

    /**
    * @param {OnDataChangedCallback} callback The function to be executed and removed callback when paging data set has changed.
    */
    removeOnDataChangedCallback(callback) {
        this.#onDataChangedCallback.remove(callback);
    }

}