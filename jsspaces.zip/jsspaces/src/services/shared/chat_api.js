/*
 * Avaya Inc. Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to company instructions.
 * Copyright 2021 Avaya Inc. All Rights Reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual or
 * intended publication of such source code.
 */

import Message from '../message/message_api.js';

/**
 * This class represents the chat.
 * @hideconstructor
 */
export default class Chat extends Message {
    #modified;
    #sender;
    #body;

    constructor(created, modified, sender, body){
        super(created);
        /**
         * @type {Date}
         */
        this.#modified = modified;
        /**
         * @type {Sender}
         */
        this.#sender = sender;
        /**
         * @type {object}
         */
        this.#body = body;
    }


    /**
     * 
     * @returns {Promise<Object[]>}
     */
    update(body){
        return Promise.reject("NOT implemented yet");
    }

    /**
     * 
     * @returns {Promise<Object[]>}
     */
    delete(){
        return Promise.reject("NOT implemented yet");
    }
}