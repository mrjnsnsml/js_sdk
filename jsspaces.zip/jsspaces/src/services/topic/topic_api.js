/*
 * Avaya Inc. Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to company instructions.
 * Copyright 2021 Avaya Inc. All Rights Reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual or
 * intended publication of such source code.
 */

import TopicHelper from "./topicHelper.js";


const TopicType = {
    PERSONAL: 'personal',
    GROUP: 'group'
};

const Role = {
    ADMIN: 'admin',
    MEMBER: 'member'
};

const Status = {
    NORMAL: 0,
    ARCHIVED: 1
};

/**
 * This class represents the topic.
 * @hideconstructor
 */
export default class Topic {
    #topicHelper;

    /**
     * @param {TopicHelper} topicHelper 
     */
    constructor(topicHelper)  {
        this.#topicHelper = topicHelper;
    }

    /**
     * Returns topic type
     * @return {TopicType}
     */
    get type() {
        return this.#topicHelper.type;        
    }

    /**
     * Returs the topic id
     * @return {String}
     */    
    get id() {
        return this.#topicHelper.id;
    }

    /**
     * Returns the topic title
     * @return {String}
     */
    get title() {
        return this.#topicHelper.title;
    }

    /**
     * Returns the topic description
     * @return {String}
     */
    get description() {
        return this.#topicHelper.description;
    }

    /**
     * Returns the topic created date
     * @return {Date}
     */
    get created() {
        return this.#topicHelper.created;
    }

    /**
     * Returns the topic lastAccess date 
     * @return {Date}
     */
    get lastAccess() {
        return this.#topicHelper.lastAccess;
    }

    /**
     * Returns the role for the topic
     * @return {Role}
     */
    get role() {
        return this.#topicHelper.role;
    }

    /**
     * Returns the status for the topic
     * @return {Status}
     */
    get status() {
        return this.#topicHelper.status;
    }

    /**
     * Returns true if this is my personal topic
     * @return {Boolean}
     */
    get isMyPersonalTopic() {
        return this.#topicHelper.isMyPersonalTopic;
    }

    /**
     * Joins the topic
     * @return {Promise<undefined>}
     */
    async join() {
        return this.#topicHelper.join();
    }

    /**
     * Unjoins the topic
     * @return {Promise<undefined>}
     */
    async unjoin() {
        return this.#topicHelper.unjoin();
    }

    /** 
     * Returns num of messages for given topic  
     * @param {Number} numberOfMessages
     * @return {Promise<PagingDataSet>}
     */
    async getMessages(numberOfMessages) {
        return this.#topicHelper.getMessages(numberOfMessages);
    }

    /**
     * Returns num of posts for given topic
     * @param {Number} numberOfPosts
     * @return {Promise<PagingDataSet>}
     */
    async getPosts(numberOfPosts) {
        return this.#topicHelper.getPosts(numberOfPosts);
    }

    /**
     * Returns num of tasks for given topic
     * @param {Number} numberOfTasks
     * @return {Promise<PagingDataSet>}
     */    
    async getTasks(numberOfTasks) {
        return this.#topicHelper.getTasks(numberOfTasks);
    }

    /**
     * Joins topic
     * @param {Array} messageIds
     * @return {Promise<undefined>}
     */
    async deleteMessages(messageIds) {
        return this.#topicHelper.deleteMessages(messageIds);
    }

    /**
     * Sends message to the topic
     * @param {Object} content
     * @return {Promise<undefined>}
     */
    async sendMessage(content) {
        return this.#topicHelper.sendMessage(content);
    }

    /**
     * Creates a post
     * @param {Object} content
     * @return {Promise<undefined>}
     */
    async createPost(content) {
        return this.#topicHelper.createPost(content);
    }

    /**
     * Creates a task
     * @param {Object} content
     * @param {Array} assignees
     * @param {Date} dueDate
     * @param {Number} status
     * @return {Promise<undefined>}
     */
    async createTask(content, assignees, dueDate, status) {
        return this.#topicHelper.createTask(content, assignees, dueDate, status);
    }
}

export {TopicType, Status, Role};