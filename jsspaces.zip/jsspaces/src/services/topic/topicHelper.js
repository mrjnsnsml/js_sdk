/*
 * Avaya Inc. Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to company instructions.
 * Copyright 2021 Avaya Inc. All Rights Reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual or
 * intended publication of such source code.
 */
import NetworkProviders, {IO_MESSAGES} from '../../base/network/networkProviders.js';
import Utils from '../../base/utils.js';
import Logger from '../../base/logger.js';

const SPACES_URL = '/api/spaces/';
const DELETE_MESSAGES_URL = '/api/messages/deletemessages';

export default class TopicHelper {
    #type; 
    #id;
    #title;
    #description;
    #created;
    #lastAccess;
    #role;
    #status;
    #isMyPersonalTopic;
    #networkProviders;
    #isJoined;

    /**
     * Returns topic type
     * @returns {TopicType}
     */
    get type() {
        return this.#type;        
    }

    /**
     * Returs the topic id
     * @returns {String}
     */    
    get id() {
        return this.#id;
    }

    /**
     * Returns the topic title
     * @returns {String}
     */
    get title() {
        return this.#title;
    }

    /**
     * Returns the topic description
     * @returns {String}
     */
    get description() {
        return this.#description;
    }

    /**
     * Returns the topic created date
     * @returns {Date}
     */
    get created() {
        return this.#created;
    }

    /**
     * Returns the topic lastAccess date 
     * @returns {Date}
     */
    get lastAccess() {
        return this.#lastAccess;
    }

    /**
     * Returns the role for the topic
     * @returns {Role}
     */
    get role() {
        return this.#role;
    }

    /**
     * Returns the status for the topic
     * @returns {Status}
     */
    get status() {
        return this.#status;
    }

    /**
     * Returns true if this is my personal topic
     * @return {Boolean}
     */
    get isMyPersonalTopic() {
        return this.#isMyPersonalTopic;
    }

    /**
     * Returns network providers
     * @returns {NetworkProviders}
     */
     get networkProviders(){
        return this.#networkProviders;
    }

    /**
     * Returns isJoined
     * @returns {Boolean}
     */
    get isJoined(){
        return this.#isJoined;
    }

    /**
     * Sets topic type
     * @param {TopicType} topicType
     */
    set type(topicType) {
       this.#type = topicType;     
    }

    /**
     * Sets the topic id
     * @param {String} topicId
     */    
    set id(topicId) {
        this.#id = topicId;
    }

    /**
     * Sets the topic title
     * @param {String} title
     */
    set title(title) {
        this.#title = title;
    }

    /**
     * Updates description
     * @param {String} description
     */
    set description(description) {
        this.#description = description;
    }

    /**
     * Updates creation date
     * @param {Date} creationDate
     */
    set created(creationDate) {
        this.#created = creationDate;
    }

    /**
     * Updates last accessed date.
     * @param {Date} accessedDate
     */
    set lastAccess(accessedDate) {
        this.#lastAccess = accessedDate;
    }

    /**
     * Updates role
     * @param {Role} role
     */
    set role(newRole) {
        this.#role = newRole;
    }

    /**
     * Updates status 
     * @param {Status} status
     */
    set status(status) {
        this.#status = status;
    }

    /**
     * Updates isMyPersonalTopic 
     * @param {Boolean} isMyPersonalTopic
     */
    set isMyPersonalTopic(isMyPersonalTopic) {
        this.#isMyPersonalTopic = isMyPersonalTopic;
    }

    /**
     * Sets network providers
     * @param {NetworkProviders} networkProviders
     */
     set networkProviders(networkProviders){
        this.#networkProviders = networkProviders;
    }

    /**
     * Sets isJoined
     * @param {Boolean} isJoined
     */
    set isJoined(isJoined){
        this.#isJoined = isJoined;
    }

    /**
     * Joins the topic
     * @returns {Promise<undefined>}
     */
    async join() {
        return new Promise((resolve,reject)=>{
            this.#networkProviders.socketIoProvider.onMessage(IO_MESSAGES.SUBSCRIBE_CHANNEL_FAILED, (payload)=>{
                reject(payload.error);
            });
            this.#networkProviders.socketIoProvider.onMessage(IO_MESSAGES.CHANNEL_SUBSCRIBED, (payload)=>{
                this.#isJoined = true;
                resolve();
            });
            this.#networkProviders.socketIoProvider.send(IO_MESSAGES.SUBSCRIBE_CHANNEL, {channel: {type: 'topic', _id: this.#id}});
        })
    }

    /**
     * Unjoins the topic
     * @returns {Promise<undefined>}
     */
    async unjoin() {
        return new Promise((resolve,reject)=>{
            this.#networkProviders.socketIoProvider.onMessage(IO_MESSAGES.CHANNEL_UNSUBSCRIBED, (payload)=>{
                this.#isJoined = false;
                resolve();
            });
            this.#networkProviders.socketIoProvider.send(IO_MESSAGES.UNSUBSCRIBE_CHANNEL, {channel: {type: 'topic', _id: this.#id}});
        })
    }

    /** 
     * Returns num of messages for given topic  
     * @param {Number} numberOfMessages
     * @returns {Promise<PagingDataSet>}
     */
    async getMessages(numberOfMessages) {
        return new Promise((resolve,reject)=>{
            if(Number.isInteger(numberOfMessages)){
                this.#networkProviders.restProvider.get(this.#networkProviders.restProvider.serverUrl+SPACES_URL+this.#id+'/messages/byref?size='+numberOfMessages).then((response)=>{
                    resolve(Utils.createPagingDataSet(response, this.#networkProviders));
                })
                .catch((error)=>{
                    Logger.error("Error getting messages", error);
                    reject(error);
                });
            } else{
                reject();
            }
        })
    }

    /**
     * Returns num of posts for given topic
     * @param {Number} numberOfPosts
     * @returns {Promise<PagingDataSet>}
     */
    async getPosts(numberOfPosts) {
        return new Promise((resolve,reject)=>{
            if(Number.isInteger(numberOfPosts)){
                this.#networkProviders.restProvider.get(this.#networkProviders.restProvider.serverUrl+SPACES_URL+this.#id+'/ideas?size='+numberOfPosts).then((response)=>{
                    resolve(Utils.createPagingDataSet(response, this.#networkProviders));
                })
                .catch((error)=>{
                    Logger.error("Error retrieving posts", error);
                    reject(error);
                });
            } else{
                reject();
            }
        })
    }

    /**
     * Returns num of tasks for given topic
     * @param {Number} numberOfTasks
     * @returns {Promise<PagingDataSet>}
     */    
    async getTasks(numberOfTasks) {
        return new Promise((resolve,reject)=>{
            if(Number.isInteger(numberOfTasks)){
                this.#networkProviders.restProvider.get(this.#networkProviders.restProvider.serverUrl+SPACES_URL+this.#id+'/tasks?size='+numberOfTasks).then((response)=>{
                    resolve(Utils.createPagingDataSet(response, this.#networkProviders));
                })
                .catch((error)=>{
                    Logger.error("Error retrieving tasks", error);
                    reject(error);
                });
            } else{
                reject();
            }
        })
    }

    /**
     * Deletes messages using given messageIds
     * @param {Array} messageIds
     * @returns {Promise<undefined>}
     */
    async deleteMessages(messageIds) {
        return new Promise((resolve,reject)=>{
            if(Array.isArray(messageIds)){
                this.#networkProviders.restProvider.post(this.#networkProviders.restProvider.serverUrl+DELETE_MESSAGES_URL, JSON.stringify(messageIds)).then((response)=>{
                    resolve();
                })
                .catch((error)=>{
                    Logger.error("Error deleting messages", error);
                    reject(error);
                });
            } else{
                reject();
            }
        })
    }

    /**
     * Sends message to the topic
     * @param {Object} content
     * @returns {Promise<undefined>}
     */
    async sendMessage(content) {
        return new Promise((resolve,reject)=>{
            if(typeof content === 'object' && content !== null){
                if(!!this.#isJoined){
                    this.#networkProviders.socketIoProvider.send(IO_MESSAGES.SEND_MESSAGE, {topicId: this.#id, content: content, category: 'chat', chatMessages:{}});
                    this.#networkProviders.socketIoProvider.on(IO_MESSAGES.MESSAGE_SENT, (payload)=>{
                        resolve();
                    });
                    this.#networkProviders.socketIoProvider.on(IO_MESSAGES.SEND_MESSAGE_FAILED, (payload)=>{
                        reject(payload.error);
                    });
                } else {
                    let payload = {'content': content};
                    this.#networkProviders.restProvider.post(this.#networkProviders.restProvider.serverUrl+SPACES_URL+this.#id+'/chats', JSON.stringify(payload)).then(()=>{
                        resolve();
                    })
                    .catch((error)=>{
                        Logger.error("Error sending a message", error);
                        reject(error);
                    });
                }
            } else {
                reject();
            }
        });
    }


    /**
     * Creates a post
     * @param {Object} content
     * @returns {Promise<undefined>}
     */
    async createPost(content) {
        return new Promise((resolve,reject)=>{
            if(typeof content === 'object' && content !== null){
                let payload = {'content': content};
                this.#networkProviders.restProvider.post(this.#networkProviders.restProvider.serverUrl+SPACES_URL+this.#id+'/ideas', JSON.stringify(payload)).then((response)=>{
                    resolve();
                })
                .catch((error)=>{
                    Logger.error("Error creating a post", error);
                    reject(error);
                });
            }else{
                reject();
            }
        })
    }

    /**
     * Creates a task
     * @param {Object} content
     * @param {Array} assignees
     * @param {String} dueDate
     * @param {Number} status
     * @returns {Promise<undefined>}
     */
    async createTask(content, assignees, dueDate, status) {
        return new Promise((resolve,reject)=>{
            if(typeof content === 'object' && content !== null && Array.isArray(assignees) && Number.isInteger(status) && typeof dueDate === 'string'){
                let payload = {'content': content, 'assignees': assignees, 'dueDate': dueDate, 'status': status};
                this.#networkProviders.restProvider.post(this.#networkProviders.restProvider.serverUrl+SPACES_URL+this.#id+'/tasks', JSON.stringify(payload)).then(()=>{
                    resolve();
                })
                .catch((error)=>{
                    Logger.error("Error creating a task", error);
                    reject(error);
                });
            } else{
                reject();
            }
        });
    }
}