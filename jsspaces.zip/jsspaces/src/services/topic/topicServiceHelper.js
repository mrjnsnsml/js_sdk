/*
 * Avaya Inc. Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to company instructions.
 * Copyright 2021 Avaya Inc. All Rights Reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual or
 * intended publication of such source code.
 */

import NetworkProviders from '../../base/network/networkProviders.js';
import Utils from '../../base/utils.js';
import PagingDataSet from '../shared/pagingDataSet_api.js';
import Topic, {TopicType, Role} from "./topic_api.js";
import TopicHelper from './topicHelper';

const RETRIEVE_GROUP_TOPICS_URL = '/api/users/me/spaces?topictype=group';
const RETRIEVE_DIRECT_TOPICS_URL = '/api/users/me/spaces?topictype=direct';
const RETRIEVE_PERSONAL_TOPIC_URL = '/api/users/meetingroom/';
const SPACES_URL = '/api/spaces/';
import Logger from '../../base/logger.js';

export default class TopicServiceHelper {
    #userInfo;
    #networkProviders;
    #personalTopicId;

    /**
     * Returns the user info 
     * @readonly
     * @returns {UserInfo}
     */
    get userInfo() {
        return this.#userInfo;
    }

    /**
     * Returns network providers
     * @readonly
     * @returns {NetworkProviders}
     */
    get networkProviders(){
        return this.#networkProviders;
    }

    /**
     * Returns personal topic id
     * @readonly
     * @returns {String}
     */
    get personalTopicId(){
        return this.#personalTopicId;
    }

    /**
     * Sets the user info 
     * @param {UserInfo} user
     */
    set userInfo(user) {
        this.#userInfo = user;
    }

    /**
     * Sets network providers
     * @param {NetworkProviders} networkProviders
     */
    set networkProviders(networkProviders) {
        this.#networkProviders = networkProviders;
    }

    /**
     * Sets personal topicId 
     * @param {String} personalTopicId
     */
    set personalTopicId(personalTopicId){
        this.#personalTopicId = personalTopicId;
    }

    /**
     * Creates a topic
     * @param {Response} topicResponse 
     * @param {NetworkProviders} networkProviders 
     * @returns {Topic}
     */
    createTopic(topicResponse, networkProviders) {
        let topic;
        let topicHelper = new TopicHelper();
        topicHelper.type = topicResponse.type;
        topicHelper.id = topicResponse._id;
        topicHelper.title = topicResponse.title;
        topicHelper.created = topicResponse.created;
        topicHelper.role = topicResponse.role;
        topicHelper.status = topicResponse.status;
        topicHelper.lastAccess = topicResponse.lastAccess;
        topicHelper.networkProviders = networkProviders;
        topicHelper.isMyPersonalTopic = topicResponse.role === Role.ADMIN  && topicResponse.type === TopicType.PERSONAL? true : false;
        topic = new Topic(topicHelper);
        return topic;
    }

    /**
     * Returns group topics of the user
     * @returns {Promise<PagingDataSet>}
     */
    async getMyGroupTopics() {
        return new Promise((resolve,reject)=>{
            this.#networkProviders.restProvider.get(this.#networkProviders.restProvider.serverUrl+RETRIEVE_GROUP_TOPICS_URL).then((response)=>{
                resolve(Utils.createPagingDataSet(response, this.#networkProviders));
            })
            .catch((error)=>{
                Logger.error("Error getting group topics", error);
                reject(error);
            });
        })
    }

    /**
     * Returns direct topics of the user
     * @returns {Promise<PagingDataSet>}
     */    
    async getMyDirectTopics() {
        return new Promise((resolve,reject)=>{
            this.#networkProviders.restProvider.get(this.#networkProviders.restProvider.serverUrl+RETRIEVE_DIRECT_TOPICS_URL).then((response)=>{
                resolve(Utils.createPagingDataSet(response, this.#networkProviders));
            })
            .catch((error)=>{
                Logger.error("Error getting direct topics", error);
                reject(error);
            });
        })
    }

    /**
     * Returns personal topic of the user
     * @returns {Promise<Topic>}
     */
    async getPersonalTopic() {
        let email = this.#userInfo.emailAddresses[0].value;
        return new Promise((resolve,reject)=>{
            this.#networkProviders.restProvider.get(this.#networkProviders.restProvider.serverUrl+RETRIEVE_PERSONAL_TOPIC_URL+email).then((response)=>{
                resolve(this.createTopic(response.data, this.#networkProviders));
            })
            .catch((error)=>{
                Logger.error("Error getting personal topic", error);
                reject(error);
            });
        })
    }

    /**
     * Joins personal topic
     * @returns {Promise<Topic>}
     */
    async joinPersonalTopic() {
        return new Promise((resolve,reject)=>{
            if(!!this.#personalTopicId){
                this.joinTopicById(this.#personalTopicId).then((response)=>{
                    resolve(response);
                })
                .catch((error)=>{
                    Logger.error("Error joining personal topic", error);
                    reject(error);
                });
            }else{
                let email = this.#userInfo.emailAddresses[0].value;
                this.#networkProviders.restProvider.get(this.#networkProviders.restProvider.serverUrl+RETRIEVE_PERSONAL_TOPIC_URL+email).then((response)=>{
                    this.#personalTopicId = response.data._id;
                    this.joinTopicById(this.#personalTopicId).then((response)=>{
                        resolve(response);
                    }).catch((error)=>{
                        Logger.error("Error joining personal topic", error);
                        reject(error);
                    });
                })
                .catch((error)=>{
                    Logger.error("Error getting personal topic", error);
                    reject(error);
                });
            }
        });
    }

    /**
     * Returns topic by id
     * @param {String} topicId 
     * @returns {Promise<Topic>}
     */    
    async getTopicById(topicId) {
        return new Promise((resolve,reject)=>{
            this.#networkProviders.restProvider.get(this.#networkProviders.restProvider.serverUrl+SPACES_URL+topicId).then((response)=>{
                resolve(this.createTopic(response, this.#networkProviders));
            })
            .catch((error)=>{
                Logger.error("Error getting topic by id", error);
                reject(error);
            });
        })
    }

    /**
     * Joins topic by id
     * @param {String} topicId 
     * @returns {Promise<Topic>}
     */  
    async joinTopicById(topicId) {
        return new Promise((resolve,reject)=>{
            this.#networkProviders.restProvider.get(this.#networkProviders.restProvider.serverUrl+SPACES_URL+topicId+'/join').then((response)=>{
                resolve(this.createTopic(response.topic, this.#networkProviders));
            })
            .catch((error)=>{
                Logger.error("Error joining topic by id", error);
                reject(error);
            });
        })
    }
    
    /**
     * Update the topic of given topicId
     * @param {String} topicId 
     * @param {Object} content
     * @returns {Promise<Topic>}
     */  
    async updateTopic(topicId, content){
        return new Promise((resolve,reject)=>{
            this.#networkProviders.restProvider.post(this.#networkProviders.restProvider.serverUrl+SPACES_URL+topicId, content).then((response)=>{
                resolve();
            })
            .catch((error)=>{
                Logger.error("Error updating the topic", error);
                reject(error);
            });
        })
    }
}