/*
 * Avaya Inc. Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to company instructions.
 * Copyright 2021 Avaya Inc. All Rights Reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual or
 * intended publication of such source code.
 */

/**
 * This class represents the topicService.
 * @hideconstructor
 */
export default class TopicService {
    #topicServiceHelper;

    constructor(topicServiceHelper){
        this.#topicServiceHelper = topicServiceHelper;
    }

    /**
     * Returns group topics of the user
     * @returns {Promise<PagingDataSet>}
     */
    async getMyGroupTopics() {
        return this.#topicServiceHelper.getMyGroupTopics();
    }

    /**
     * Returns direct topics of the user
     * @returns {Promise<PagingDataSet>}
     */    
    async getMyDirectTopics() {
        return this.#topicServiceHelper.getMyDirectTopics();
    }

    /**
     * Returns personal topic of the user
     * @returns {Promise<Topic>}
     */
    async getPersonalTopic() {
        return this.#topicServiceHelper.getPersonalTopic();
    }

    /**
     * Joins personal topic
     * @returns {Promise<Topic>}
     */
    async joinPersonalTopic(topicId) {
        return this.#topicServiceHelper.joinPersonalTopic(topicId);
    }

    /**
     * Returns topic by id
     * @param {String} topicId 
     * @returns {Promise<Topic>}
     */    
    async getTopicById(topicId) {
        return this.#topicServiceHelper.getTopicById(topicId);
    }

    /**
     * Joins topic by id
     * @param {String} topicId 
     * @returns {Promise<Topic>}
     */  
    async joinTopicById(topicId) {
        return this.#topicServiceHelper.joinTopicById(topicId);
    }
    
    /**
     * Update the topic of given topicId
     * @param {String} topicId 
     * @param {Object} content
     * @returns {Promise<Topic>}
     */  
    async updateTopic(topicId, content){
        return this.#topicServiceHelper.updateTopic(topicId, content);
    }
}