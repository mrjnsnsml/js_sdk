/*
 * Avaya Inc. Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to company instructions.
 * Copyright 2020 Avaya Inc. All Rights Reserved.
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual or
 * intended publication of such source code.
 */

/**
 * This class represents a collaboration service.  
 * It can be used to extend collaboration functionalities.
 * @hideconstructor
 */
export default class CollaborationHelper {

    /**
     * Collaboration
     * @readonly
     * @type {AvayaMedia.Collaboration}
     */
    #collaboration = undefined;

    /**
     * @type {AvayaMedia.Callbacks}
     */
    #serviceAvailableCallback = undefined;
    #serviceUnavailableCallback = undefined;
    #collaborationEndedCallback = undefined;
    #collaborationNearEndByEjectCallback = undefined;

    /**
     * @private
     */
    _cleanup() {
        this.#collaborationEndedCallback.cleanup();
        this.#serviceAvailableCallback.cleanup();
        this.#serviceUnavailableCallback.cleanup();
        this.#collaborationNearEndByEjectCallback.cleanup();
    }

    /**
     * True if receiving sharing is paused.
     * @readonly
     * @type {boolean}
     */
    get isReceivingSharingPaused(){
        return this.#collaboration.isReceivingSharingPaused;
    }

    /**
     * The collaboration participants
     * @readonly
     * @return {AvayaMedia.DataRetrieval<Participant>}
     */
    get participants(){
        return this.#collaboration.participants;
    }

    /**
     * Resumes the collaboration. The promise will be resolved if resumed successfully. If an error occurs
     * preventing the collaboration from resuming successfully the promise will be rejected.
     * @returns {Promise<undefined>}
     */
    resume(){
        if (!!this.#collaboration) {
            return this.#collaboration.resume();
        }
        return Promise.reject("Collaboration not resumed");
    }

    /**
     * Pauses the collaboration. The promise will be resolved if started successfully. If an error occurs
     * preventing the collaboration from pausing successfully the promise will be rejected.
     * @returns {Promise<undefined>}
     */
    pause(){
        if (!!this.#collaboration) {
            return this.#collaboration.pause();
        }
        return Promise.reject("Collaboration not paused");
    }

    /**
     * The collaboration content sharing capability
     * @readonly
     * @return {AvayaMedia.Capability}
     */
    get contentSharingCapability(){
        return this.#collaboration.contentSharingCapability;
    }

    /**
     * The collaboration participant list capability
     * @readonly
     * @return {AvayaMedia.Capability}
     */
    get retrieveParticipantListCapability(){
        return this.#collaboration.retrieveParticipantListCapability;
    }

    /**
     * Sets the collaboration
     * @readonly
     * @param {AvayaMedia.Collaboration}
     */
    set collaboration(newCollaboration){
        this.#collaboration = newCollaboration;
        newCollaboration.addOnAvailableCallback(function(){
            this.#serviceAvailableCallback.fire(this);
        }.bind(this));
        newCollaboration.addOnUnavailableCallback(function(){
            this.#serviceUnavailableCallback.fire(this);
        }.bind(this));
        newCollaboration.addOnEndedCallback(function () {
            this.#collaborationEndedCallback.fire(this);
            this._cleanup();
        }.bind(this));
        newCollaboration.addOnNearEndByEjectCallback(function (collaboration) {
            this.#collaborationNearEndByEjectCallback.fire(this);
            this._cleanup();
        }.bind(this));
    }

    /**
     * The Collaboration
     * @readonly
     * @type {AvayaMedia.Collaboration}
     */
    get collaboration(){
        return this.#collaboration;
    }

    /**
     * Delegate callbacks from collaboration service to collaboration class
     * @readonly
     */
    registerCallbacks(serviceAvailableCallback, serviceUnavailableCallback, collaborationEndedCallback, collaborationNearEndByEjectCallback){
        this.#serviceAvailableCallback = serviceAvailableCallback;
        this.#serviceUnavailableCallback = serviceUnavailableCallback;
        this.#collaborationEndedCallback = collaborationEndedCallback;
        this.#collaborationNearEndByEjectCallback = collaborationNearEndByEjectCallback;
    }
}

