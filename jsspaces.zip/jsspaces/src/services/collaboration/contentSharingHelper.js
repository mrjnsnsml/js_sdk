/*
 * Avaya Inc. Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to company instructions.
 * Copyright 2020 Avaya Inc. All Rights Reserved.
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual or
 * intended publication of such source code.
 */

/**
 * This class represents a content sharing helper.  
 * It can be used to extend content sharing functionalities functionalities.
 * @hideconstructor
 */
 export default class ContentSharingHelper {

    /**
     * ContentSharing
     * @readonly
     * @type {AvayaMedia.ContentSharing}
     */
    #contentSharing = undefined;

    /**
     * @type {AvayaMedia.Callbacks}
     */
    #onStartedCallbacks = undefined;
    #onEndedCallbacks = undefined;
    #onPausedCallbacks = undefined;
    #onResumedCallbacks = undefined;
    #onCursorReceivedCallbacks = undefined;
    #onFrameReceivedCallbacks =undefined;
    #onFrameChangedCallbacks = undefined; 
    #onFrameReportReceivedCallbacks = undefined;

    /**
     * Returns full screen sharing capability.
     * @readonly
     * @type {AvayaMedia.Capability}
     */
    get shareFullScreenCapability(){
        return this.#contentSharing.shareFullScreenCapability;
    }

    /**
     * Returns application window screen sharing capability.
     * @readonly
     * @type {AvayaMedia.Capability}
     */
    get shareApplicationWindowCapability(){
        return this.#contentSharing.shareApplicationWindowCapability;
    }

    /**
     * Returns start any type screen sharing capability.
     * @readonly
     * @type {AvayaMedia.Capability}
     */
    get startScreenSharingCapability(){
        return this.#contentSharing.startScreenSharingCapability;
    }

    /**
     * True if sharing full screen.
     * @readonly
     * @type {boolean}
     */
    get isSharingFullScreen(){
        return this.#contentSharing.isSharingFullScreen;
    }

    /**
     * True if sharing application window.
     * @readonly
     * @type {boolean}
     */
    get isSharingApplicationWindow(){
        return this.#contentSharing.isSharingApplicationWindow;
    }

    /**
     * Returns outgoing screen sharing stream
     * @readonly
     * @type {MediaStream}
     */
    get outgoingScreenSharingStream(){
        return this.#contentSharing.outgoingScreenSharingStream;
    }

    /**
     * True if screen sharing is active.
     * @readonly
     * @type {boolean}
     */
    get isActive(){
        return this.#contentSharing.isActive;
    }

    /**
     * True if screen sharing is paused.
     * @readonly
     * @type {boolean}
     */
    get isPaused(){
        return this.#contentSharing.isPaused;
    }

    /**
     * True if presenting.
     * @readonly
     * @type {boolean}
     */
    get isPresenting(){
        return this.#contentSharing.isPresenting;
    }

    /**
     * Returns receiving bitrate
     * @readonly
     * @type {Number}
     */
    get bitrate(){
        return this.#contentSharing.bitrate;
    }

    /**
     * Returns content sharing for renderer
     * @readonly
     * @type {AvayaClientServices.Services.Collaboration.ContentSharing}
     */
    get contentSharingForRenderer(){
        return this.#contentSharing.contentSharingForRenderer;
    }

    /**
     * Starts the screen sharing. The promise will be resolved if started successfully. If an error occurs
     * preventing the screen sharing from starting successfully the promise will be rejected.
     * @returns {Promise<undefined>}
     */
    startScreenSharing(){
        return this.#contentSharing.startScreenSharing();
    }

    /**
     * Starts fullscreen screen sharing. The promise will be resolved if started successfully. If an error occurs
     * preventing the screen sharing from starting successfully the promise will be rejected.
     * @param {undefined|string} mediaSourceId - Optional streamId provided by a third-party Chrome extension. This ID is returned by chrome.desktopCapture.chooseDesktopMedia. This is not necessary for Firefox, or if using the Avaya Screen Sharing extension.
     * @returns {Promise<undefined>}
     */
    startScreenSharingFullScreen(mediaSourceId){
        return this.#contentSharing.startScreenSharingFullScreen(mediaSourceId);
    }

    /**
     * Starts screen sharing on an application window. The promise will be resolved if started successfully. If an error occurs
     * preventing the screen sharing from starting successfully the promise will be rejected.
     * @param {undefined|string} mediaSourceId - Optional streamId provided by a third-party Chrome extension. This ID is returned by chrome.desktopCapture.chooseDesktopMedia. This is not necessary for Firefox, or if using the Avaya Screen Sharing extension.
     * @returns {Promise<undefined>}
     */
    startScreenSharingApplicationWindow(mediaSourceId){
        return this.#contentSharing.startScreenSharingApplicationWindow(mediaSourceId);
    }

    /**
     * Resumes the screen sharing. The promise will be resolved if resumed successfully. If an error occurs
     * preventing the screen sharing from resuming successfully the promise will be rejected.
     * @returns {Promise<undefined>}
     */
    resume(){
        return this.#contentSharing.resume();
    }
     
    /**
     * Pauses the screen sharing. The promise will be resolved if paused successfully. If an error occurs
     * preventing the screen shairng from pausing successfully the promise will be rejected.
     * @returns {Promise<undefined>}
     */
    pause(){
        return this.#contentSharing.pause();
    }

    /**
     * Ends the screen sharing. The promise will be resolved if ended successfully. If an error occurs
     * preventing the screen sharing from ending successfully the promise will be rejected.
     * @returns {Promise<undefined>}
     */
    end(){
        return this.#contentSharing.end();
    }

    /**
     * Sets the content sharing
     * @readonly
     * @param {AvayaMedia.ContentSharing}
     */
    set contentSharing(newContentSharing){
        this.#contentSharing = newContentSharing;
        newContentSharing.addOnStartedCallback(function(){
            this.#onStartedCallbacks.fire(this);
        }.bind(this));
        newContentSharing.addOnEndedCallback(function(){
            this.#onEndedCallbacks.fire(this);
        }.bind(this));
        newContentSharing.addOnPausedCallback(function(){
            this.#onPausedCallbacks.fire(this);
        }.bind(this));
        newContentSharing.addOnResumedCallback(function(){
            this.#onResumedCallbacks.fire(this);
        }.bind(this));
        newContentSharing.addOnCursorReceivedCallback(function(){
            this.#onCursorReceivedCallbacks.fire(this);
        }.bind(this));
        newContentSharing.addOnFrameReceivedCallback(function(){
            this.#onFrameReceivedCallbacks.fire(this);
        }.bind(this));
        newContentSharing.addOnFrameChangedCallback(function(){
            this.#onFrameChangedCallbacks.fire(this);
        }.bind(this));
        newContentSharing.addOnFrameReportReceivedCallback(function(){
            this.#onFrameReportReceivedCallbacks.fire(this);
        }.bind(this));
    }

    /**
     * The content sharing
     * @readonly
     * @type {AvayaMedia.ContentSharing}
     */
    get contentSharing(){
        return this.#contentSharing;
    }

    /**
     * Delegate callbacks from collaboration service to collaboration class
     * @readonly
     */
    registerCallbacks(onStartedCallbacks, onEndedCallbacks, onPausedCallbacks, onResumedCallbacks, onCursorReceivedCallbacks, onFrameReceivedCallbacks, onFrameChangedCallbacks, onFrameReportReceivedCallbacks){
        this.#onStartedCallbacks = onStartedCallbacks;
        this.#onEndedCallbacks = onEndedCallbacks;
        this.#onPausedCallbacks = onPausedCallbacks;
        this.#onResumedCallbacks = onResumedCallbacks;
        this.#onCursorReceivedCallbacks = onCursorReceivedCallbacks;
        this.#onFrameReceivedCallbacks = onFrameReceivedCallbacks;
        this.#onFrameChangedCallbacks = onFrameChangedCallbacks;
        this.#onFrameReportReceivedCallbacks = onFrameReportReceivedCallbacks;
    }
}

