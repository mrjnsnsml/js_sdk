/*
 * Avaya Inc. Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to company instructions.
 * Copyright 2021 Avaya Inc. All Rights Reserved.
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual or
 * intended publication of such source code.
 */

import { Callbacks } from 'avayamedia';

/**
 * This class represents a collaboration.  
 * It can be used to provide functionality of the screen sharing and the whiteboard drawing.
 * @hideconstructor
 */
export default class Collaboration {

    /**
     * The content sharing object for this collaboration. It contains all content sharing functionality.
     *
     * @readonly
     * @type {ContentSharing}
     */
    #contentSharing = undefined;
    
     /**
     * The collaboration helper object for this session. It contains all collaboration helper functionality. 
     * 
     * @readonly
     * @type {CollaborationHelper}
     */
    #collaborationHelper = undefined;

    /**
     * @type {AvayaMedia.Callbacks}
     */
    #onEndedCallbacks = undefined;
    #onAvailableCallbacks = undefined;
    #onUnavailableCallbacks = undefined;
    #onNearEndByEjectCallbacks = undefined;

    /**
     *
     * @param {ContentSharing} contentSharing
     */
    constructor(collaborationHelper, contentSharing) {
        this.#collaborationHelper = collaborationHelper;
        this.#onEndedCallbacks = new Callbacks();
        this.#onAvailableCallbacks = new Callbacks();
        this.#onUnavailableCallbacks = new Callbacks();
        this.#onNearEndByEjectCallbacks = new Callbacks();
        this.#collaborationHelper.registerCallbacks(this.#onAvailableCallbacks, this.#onUnavailableCallbacks, this.#onEndedCallbacks, this.#onNearEndByEjectCallbacks);
        this.#contentSharing = contentSharing;
    }

    /**
     * Resumes the collaboration. The promise will be resolved if resumed successfully. If an error occurs
     * preventing the collaboration from resuming successfully the promise will be rejected.
     * @returns {Promise<undefined>}
     */
    resume(){
        return this.#collaborationHelper.resume();
    }

    /**
     * Pauses the collaboration. The promise will be resolved if started successfully. If an error occurs
     * preventing the collaboration from pausing successfully the promise will be rejected.
     * @returns {Promise<undefined>}
     */
    pause(){
        return this.#collaborationHelper.pause();
    }

    /**
     * The collaboration participants
     * @readonly
     * @type {AvayaMedia.DataRetrieval<Participant>}
     */
    get participants(){
        return this.#collaborationHelper.participants;
    }

    /**
     * True if receiving sharing is paused.
     * @readonly
     * @type {boolean}
     */
    get isReceivingSharingPaused(){
        return this.#collaborationHelper.isReceivingSharingPaused;
    }

    /**
     * The collaboration content sharing.
     * @readonly
     * @type {ContentSharing}
     */
    get contentSharing(){
        return this.#contentSharing;
    }

    /**
     * The collaboration content sharing capability.
     * @readonly
     * @type {AvayaMedia.Capability}
     */
    get contentSharingCapability(){
        return this.#collaborationHelper.contentSharingCapability;
    }

    /**
     * The collaboration retrieve participant list capability.
     * @readonly
     * @type {AvayaMedia.Capability}
     */
    get retrieveParticipantListCapability() {
        return this.#collaborationHelper.retrieveParticipantListCapability;
    }

    /**
     * Interface for callback function to be invoked when a collaboration ends.
     *
     * @group Callbacks
     * @callback OnEndedCallback
     * @param {Collaboration} collaboration Collaboration session that the callback is associated with.
     */

    /**
     * @param {OnEndedCallback} callback the function to be executed when a collaboration ends.
     */
    addOnEndedCallback(callback) {
        this.#onEndedCallbacks.add(callback);
    }

    /**
     * @param {OnEndedCallback} callback the function to be removed.
     */
    removeOnEndedCallback(callback) {
        this.#onEndedCallbacks.remove(callback);
    }


    /**
     * Interface for callback function to be invoked when a collaboration service is available.
     *
     * @group Callbacks
     * @callback OnAvailableCallback
     * @param {Collaboration} collaboration Collaboration session that the callback is associated with.
     */

    /**
     * @param {OnAvailableCallback} callback the function to be executed when a collaboration service is available.
     */
    addOnAvailableCallback(callback) {
        this.#onAvailableCallbacks.add(callback);
    }

    /**
     * @param {OnAvailableCallback} callback the function to be removed.
     */
    removeOnAvailableCallback(callback) {
        this.#onAvailableCallbacks.remove(callback);
    }


    /**
     * Interface for callback function when a collaboration service is unavailable.
     *
     * @group Callbacks
     * @callback OnUnavailableCallback
     * @param {Collaboration} collaboration Collaboration session that the callback is associated with.
     */

    /**
     * @param {OnUnavailableCallback} callback the function to be executed when a collaboration service is unavailable.
     */
    addOnUnavailableCallback(callback) {
        this.#onUnavailableCallbacks.add(callback);
    }

    /**
     * @param {OnUnavailableCallback} callback the function to be removed.
     */
    removeOnUnavailableCallback(callback) {
        this.#onUnavailableCallbacks.remove(callback);
    }


    /**
     * Interface for callback function when a participant is ejected from the collaboration.
     *
     * @group Callbacks
     * @callback OnNearEndByEjectCallback
     * @param {Collaboration} collaboration Collaboration session that the callback is associated with.
     */

    /**
     * @param {OnNearEndByEjectCallback} callback the function to be executed when the participant is ejected from the collaboration.
     */
    addOnNearEndByEjectCallback(callback) {
        this.#onNearEndByEjectCallbacks.add(callback);
    }

    /**
     * @param {OnNearEndByEjectCallback} callback the function to be removed.
     */
    removeOnNearEndByEjectCallback(callback) {
        this.#onNearEndByEjectCallbacks.remove(callback);
    }
}

