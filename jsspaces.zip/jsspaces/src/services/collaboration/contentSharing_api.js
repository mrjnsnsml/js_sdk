/*
 * Avaya Inc. Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to company instructions.
 * Copyright 2020 Avaya Inc. All Rights Reserved.
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual or
 * intended publication of such source code.
 */

import ContentSharingHelper from "./contentSharingHelper.js";
import { Callbacks } from 'avayamedia';

/**
 * This class represents a content sharing.  
 * It can be used to provide functionality of the screen sharing.
 * @hideconstructor
 */
export default class ContentSharing {
    /**
     * ContentSharingHelper
     * @readonly
     * @type {ContentSharingHelper}
     */
    #contentSharingHelper = undefined;
     
    /**
     * @type {Callbacks}
     */
    #onStartedCallbacks = undefined;
    #onEndedCallbacks = undefined;
    #onPausedCallbacks = undefined;
    #onResumedCallbacks = undefined;
    #onCursorReceivedCallbacks = undefined;
    #onFrameReceivedCallbacks =undefined;
    #onFrameChangedCallbacks = undefined; 
    #onFrameReportReceivedCallbacks = undefined;

    /**
     * @param {ContentSharingHelper} contentSharingHelper
     */
    constructor(contentSharingHelper) {
        this.#contentSharingHelper = contentSharingHelper;
        this.#onStartedCallbacks = new Callbacks();
        this.#onEndedCallbacks = new Callbacks();
        this.#onPausedCallbacks = new Callbacks();
        this.#onResumedCallbacks = new Callbacks();
        this.#onCursorReceivedCallbacks = new Callbacks();
        this.#onFrameReceivedCallbacks = new Callbacks();
        this.#onFrameChangedCallbacks = new Callbacks();
        this.#onFrameReportReceivedCallbacks = new Callbacks();
        this.#contentSharingHelper.registerCallbacks(this.#onStartedCallbacks, this.#onEndedCallbacks, this.#onPausedCallbacks, this.#onResumedCallbacks, this.#onCursorReceivedCallbacks, this.#onFrameReceivedCallbacks, this.#onFrameChangedCallbacks, this.#onFrameReportReceivedCallbacks);
    }

    /**
     * Returns full screen sharing capability.
     * @readonly
     * @type {AvayaMedia.Capability}
     */
    get shareFullScreenCapability(){
        return this.#contentSharingHelper.shareFullScreenCapability;
    }

    /**
     * Returns application window screen sharing capability.
     * @readonly
     * @type {AvayaMedia.Capability}
     */
    get shareApplicationWindowCapability(){
        return this.#contentSharingHelper.shareApplicationWindowCapability;
    }

    /**
     * Returns start any type screen sharing capability.
     * @readonly
     * @type {AvayaMedia.Capability}
     */
    get startScreenSharingCapability(){
        return this.#contentSharingHelper.startScreenSharingCapability;
    }

    /**
     * True if sharing full screen.
     * @readonly
     * @type {boolean}
     */
    get isSharingFullScreen(){
        return this.#contentSharingHelper.isSharingFullScreen;
    }

    /**
     * True if sharing application window.
     * @readonly
     * @type {boolean}
     */
    get isSharingApplicationWindow(){
        return this.#contentSharingHelper.isSharingApplicationWindow;
    }

    /**
     * Returns outgoing screen sharing stream
     * @readonly
     * @type {MediaStream}
     */
    get outgoingScreenSharingStream(){
        return this.#contentSharingHelper.outgoingScreenSharingStream;
    }

    /**
     * True if screen sharing is active.
     * @readonly
     * @type {boolean}
     */
    get isActive(){
        return this.#contentSharingHelper.isActive;
    }

    /**
     * True if screen sharing is paused.
     * @readonly
     * @type {boolean}
     */
    get isPaused(){
        return this.#contentSharingHelper.isPaused;
    }

    /**
     * True if presenting.
     * @readonly
     * @type {boolean}
     */
    get isPresenting(){
        return this.#contentSharingHelper.isPresenting;
    }

    /**
     * Returns receiving bitrate
     * @readonly
     * @type {Number}
     */
    get bitrate(){
        return this.#contentSharingHelper.bitrate;
    }

    /**
     * Returns receiving bitrate
     * @readonly
     * @type {AvayaClientServices.Services.Collaboration.ContentSharing}
     */
    get contentSharingForRenderer(){
        return this.#contentSharingHelper.contentSharingForRenderer;
    }

    /**
     * Starts the screen sharing. The promise will be resolved if started successfully. If an error occurs
     * preventing the screen sharing from starting successfully the promise will be rejected.
     * @returns {Promise<undefined>}
     */
    startScreenSharing(){
        return this.#contentSharingHelper.startScreenSharing();
    }

    /**
     * Starts fullscreen screen sharing. The promise will be resolved if started successfully. If an error occurs
     * preventing the screen sharing from starting successfully the promise will be rejected.
     * @param {undefined|string} mediaSourceId - Optional streamId provided by a third-party Chrome extension. This ID is returned by chrome.desktopCapture.chooseDesktopMedia. This is not necessary for Firefox, or if using the Avaya Screen Sharing extension.
     * @returns {Promise<undefined>}
     */
    startScreenSharingFullScreen(mediaSourceId){
        return this.#contentSharingHelper.startScreenSharingFullScreen(mediaSourceId); 
    }

    /**
     * Starts screen sharing on an application window. The promise will be resolved if started successfully. If an error occurs
     * preventing the screen sharing from starting successfully the promise will be rejected.
     * @param {undefined|string} mediaSourceId - Optional streamId provided by a third-party Chrome extension. This ID is returned by chrome.desktopCapture.chooseDesktopMedia. This is not necessary for Firefox, or if using the Avaya Screen Sharing extension.
     * @returns {Promise<undefined>}
     */
    startScreenSharingApplicationWindow(mediaSourceId){
        return this.#contentSharingHelper.startScreenSharingApplicationWindow(mediaSourceId);
    }

    /**
     * Resumes the screen sharing. The promise will be resolved if resumed successfully. If an error occurs
     * preventing the screen sharing from resuming successfully the promise will be rejected.
     * @returns {Promise<undefined>}
     */
    resume(){
        return this.#contentSharingHelper.resume();
    }
     
    /**
     * Pauses the screen sharing. The promise will be resolved if paused successfully. If an error occurs
     * preventing the screen shairng from pausing successfully the promise will be rejected.
     * @returns {Promise<undefined>}
     */
    pause(){
        return this.#contentSharingHelper.pause();
    }

    /**
     * Ends the screen sharing. The promise will be resolved if ended successfully. If an error occurs
     * preventing the screen sharing from ending successfully the promise will be rejected.
     * @returns {Promise<undefined>}
     */
    end(){
        return this.#contentSharingHelper.end();
    }

    /**
     * Interface for callback function when a screen sharing started.
     *
     * @group Callbacks
     * @callback OnStartedCallbacks
     * @param {ContentSharing} contentSharing Content sharing session that the callback is associated with.
     * @param {Participant} participant Participant that has started the content sharing.
     */

    /**
     * @param {OnStartedCallback} callback the function to be executed when the screen sharing started.
     */
    addOnStartedCallback(callback) {
        this.#onStartedCallbacks.add(callback);
    }

    /**
     * @param {OnStartedCallback} callback the function to be removed.
     */
    removeOnStartedCallback(callback) {
        this.#onStartedCallbacks.remove(callback);
    }

    /**
     * Interface for callback function when a screen sharing ended.
     *
     * @group Callbacks
     * @callback OnEndedCallbacks
     * @param {ContentSharing} contentSharing Content sharing session that the callback is associated with.
     */

    /**
     * @param {OnEndedCallback} callback the function to be executed when the screen sharing ended.
     */
    addOnEndedCallback(callback) {
        this.#onEndedCallbacks.add(callback);
    }

    /**
     * @param {OnEndedCallback} callback the function to be removed.
     */
    removeOnEndedCallback(callback) {
        this.#onEndedCallbacks.remove(callback);
    }

    /**
     * Interface for callback function when a screen sharing paused.
     *
     * @group Callbacks
     * @callback OnPausedCallbacks
     * @param {ContentSharing} contentSharing Content sharing session that the callback is associated with.
     */

    /**
     * @param {OnPausedCallback} callback the function to be executed when the screen sharing paused.
     */
    addOnPausedCallback(callback) {
        this.#onPausedCallbacks.add(callback);
    }

    /**
     * @param {OnPausedCallback} callback the function to be removed.
     */
    removeOnPausedCallback(callback) {
        this.#onPausedCallbacks.remove(callback);
    }

    /**
     * Interface for callback function when a screen sharing resumed.
     *
     * @group Callbacks
     * @callback OnResumedCallbacks
     * @param {ContentSharing} contentSharing Content sharing session that the callback is associated with.
     */

    /**
     * @param {OnResumedCallback} callback the function to be executed when the screen sharing resumed.
     */
    addOnResumedCallback(callback) {
        this.#onResumedCallbacks.add(callback);
    }

    /**
     * @param {OnResumedCallback} callback the function to be removed.
     */
    removeOnResumedCallback(callback) {
        this.#onResumedCallbacks.remove(callback);
    }

    /**
     * Interface for callback function when a cursor was received.
     *
     * @group Callbacks
     * @callback OnCursorReceivedCallbacks
     * @param {ContentSharing} contentSharing Content sharing session that the callback is associated with.
     * @param {Point} position Position of cursor.
     */

    /**
     * @param {OnCursorReceivedCallback} callback the function to be executed when the cursor was received.
     */
    addOnCursorReceivedCallback(callback) {
        this.#onCursorReceivedCallbacks.add(callback);
    }

    /**
     * @param {OnCursorReceivedCallback} callback the function to be removed.
     */
    removeOnCursorReceivedCallback(callback) {
        this.#onCursorReceivedCallbacks.remove(callback);
    }

    /**
     * Interface for callback function when a frame was received.
     *
     * @group Callbacks
     * @callback OnFrameReceivedCallbacks
     * @param {ContentSharing} contentSharing Content sharing session that the callback is associated with.
     * @param {Frame} frame Received sharing frame
     */

    /**
     * @param {OnFrameReceivedCallback} callback the function to be executed when the frame was received.
     */
    addOnFrameReceivedCallback(callback) {
        this.#onFrameReceivedCallbacks.add(callback);
    }

    /**
     * @param {OnFrameReceivedCallback} callback the function to be removed.
     */
    removeOnFrameReceivedCallback(callback) {
        this.#onFrameReceivedCallbacks.remove(callback);
    }

    /**
     * Interface for callback function when frame size or position changed.
     *
     * @group Callbacks
     * @callback OnFrameChangedCallbacks
     * @param {ContentSharing} contentSharing Content sharing session that the callback is associated with.
     * @param {Frame} frame The frame size and the position of current sharing.
     */

    /**
     * @param {OnFrameChangedCallback} callback the function to be executed when the frame changed.
     */
    addOnFrameChangedCallback(callback) {
        this.#onFrameChangedCallbacks.add(callback);
    }

    /**
     * @param {OnFrameChangedCallback} callback the function to be removed.
     */
    removeOnFrameChangedCallback(callback) {
        this.#onFrameChangedCallbacks.remove(callback);
    }

    /**
     * Interface for callback function when a frame report was received.
     *
     * @group Callbacks
     * @callback OnFrameChangedCallbacks
     * @param {ContentSharing} contentSharing Content sharing session that the callback is associated with.
     * @param {Object} reportEvent Frame report data object.
     */

    /**
     * @param {OnFrameReportReceivedCallback} callback the function to be executed when the frame report was received.
     */
    addOnFrameReportReceivedCallback(callback) {
        this.#onFrameReportReceivedCallbacks.add(callback);
    }

    /**
     * @param {OnFrameReportReceivedCallback} callback the function to be removed.
     */
    removeOnFrameReportReceivedCallback(callback) {
        this.#onFrameReportReceivedCallbacks.remove(callback);
    }
}

