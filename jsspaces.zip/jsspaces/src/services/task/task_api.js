/*
 * Avaya Inc. Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to company instructions.
 * Copyright 2021 Avaya Inc. All Rights Reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual or
 * intended publication of such source code.
 */

import MessageDataSet from '../message/messageDataSet_api.js';
import Message from '../message/message_api.js';

/**
 * This class represents the network exception.
 * @hideconstructor
 */
export default class Task extends Message {

    constructor(created){
        super(created);
    }

    /**
     * 
     * @return {Promise<MessageDataSet>}
     */
    getChats(){
        return Promise.reject("NOT implemented yet");
    }

    /**
     * 
     * @return {Promise}
     */
    sendMessage(body, description){
        return Promise.reject("NOT implemented yet");
    }
}