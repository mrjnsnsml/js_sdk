/*
 * Avaya Inc. Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to company instructions.
 * Copyright 2021 Avaya Inc. All Rights Reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual or
 * intended publication of such source code.
 */


import PagingDataSet from '../shared/pagingDataSet_api.js';
import {Callbacks} from 'avayamedia';

/**
 * This class represents the taskDataSet.
 * @hideconstructor
 */
export default class TaskDataSet extends PagingDataSet {
    #data = [];
    #hasNextPage = false;
    #onDataChangedCallback = new Callbacks();

    /**
     * Returns true if there is additional page; otherwise, false.
     * @returns {boolean}
     */
    get hasNextPage() {
        return this.#hasNextPage;
    }

    /**
     * Returns the next set of paging data.
     * @returns {Promise<Object[]>}
     */
    get nextPage() {
        return Promise.reject("NOT implemented yet");
    }
}