/*
 * Avaya Inc. Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to company instructions.
 * Copyright 2021 Avaya Inc. All Rights Reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual or
 * intended publication of such source code.
 */

import Topic from '../topic/topic_api.js';
import Utils from '../../base/utils.js';
import Logger from '../../base/logger.js'
import NetworkProviders, {IO_MESSAGES, CATEGORY} from '../../base/network/networkProviders.js';
import {AudioChannel, VideoChannel, AudioMode, VideoMode, Callbacks, SessionCreationOptions, SessionException} from 'avayamedia';
import Collaboration from '../collaboration/collaboration_api.js';
import CollaborationHelper from '../collaboration/collaborationHelper.js';
import ContentSharing from '../collaboration/contentSharing_api.js';
import ContentSharingHelper from '../collaboration/contentSharingHelper.js';

const TOKEN_PATH = '/api/mediasessions/mpaas/token/';

/**
 * @hideconstructor
 */
export default class Call {
    #topic;
    #session;
    #sessionId;
    #userInfo;
    #networkProviders;
    #sessionOptions;
    #subscribedTime;
    #collaboration;
    #contentSharing = undefined;
    #contentSharingHelper;
    #collaborationHelper;
    #avayaMediaInstance = undefined;
    #audioChannel = undefined;
    #videoChannel = undefined;
    #remoteVideoElem = undefined;
    #localVideoElem = undefined;
    #onCallEndedCallback = new Callbacks();
    #onCallFailedCallback = new Callbacks();
    #onMediaConnectedCallback = new Callbacks();
    #onMediaDisconnectedCallback = new Callbacks();
    #onMediaFailedCallback = new Callbacks();


    /**
     * @param {Topic} topic 
     * @param {UserInfo} userInfo
     * @param {NetworkProviders} networkProviders 
     */
    constructor(avayaMediaInstance, topic, userInfo, networkProviders) {
        this.#avayaMediaInstance = avayaMediaInstance;
        this.#userInfo = userInfo;
        this.#networkProviders = networkProviders;
        this.#topic = topic;    
        this.#sessionOptions = new SessionCreationOptions(); 
        this.#collaborationHelper = new CollaborationHelper();
        this.#contentSharingHelper = new ContentSharingHelper();
        this.#contentSharing = new ContentSharing(this.#contentSharingHelper);
        this.#collaboration = new Collaboration(this.#collaborationHelper, this.#contentSharing);
    }

    /**
     * @type {Topic}
     */
    get topic() {
        return this.#topic;
    }

    /**
     * @returns {Collaboration| undefined}
     */
    get collaboration(){
        return this.#collaboration;
    }

    /**
     * @type {AudioChannel|undefined}
     */
    get audioChannel() {
        return this.#audioChannel;
    }

    /**
     * @type {VideoChannel|undefined}
     */
    get videoChannel() {
        return this.#videoChannel;
    }

    /**
     * @type {boolean}
     */
    get isMediaConnected() {
        return this.#session ? this.#session.isMediaConnected : false;
    }

    /**
     * @type {boolean}
     */
    get isHeld() {
        return this.#session ? this.#session.isHeld : false;
    }

    /**
     * @type {boolean}
     */
    get isServiceAvailable() {
        return this.#session ? this.#session.isServiceAvailable : false;
    }

    /**
     * @type {String}
     */
    get establishedTime() {
        return this.#session ? this.#session.establishedTime : '';
    }

    /**
     * @type {boolean}
     */
    get updateWebCollaborationCapability(){
        return this.#session ? this.#session.updateWebCollaborationCapability.isAllowed : false;
    }

    /**
     * @returns {Promise<undefined>}
     */
    async start() {
        const enableAudio = this.#sessionOptions.audioMode !== AudioMode.DISABLE;
        const enableVideo = this.#sessionOptions.videoMode !== VideoMode.DISABLE;
        const enableCollab = this.#sessionOptions.collaborationEnabled;
        const tokenUrl = this.#networkProviders.restProvider.serverUrl + TOKEN_PATH + this.#topic.id + '?isSpaceCall=false&' +
                'isCollab=' + this.#sessionOptions.collaborationEnabled + '&audio=' + enableAudio + '&video=' + enableVideo;
                Logger.info("tokenurl = " + tokenUrl);
        try {
            // Retrieves MPaaS sessionId and token
            const response = await this.#networkProviders.restProvider.get(tokenUrl);

            this.#sessionId = response.sessionId;
            this.#session = this.#avayaMediaInstance.sessionService.createSession(response.token, this.#sessionOptions);
            this.#collaborationHelper.collaboration = this.#session.collaboration;
            this.#contentSharingHelper.contentSharing = this.#session.collaboration.contentSharing;
            this.#audioChannel = this.#session.audioChannel;
            this.#videoChannel = this.#session.videoChannel;
            
            this.#subscribedTime = new Date().toISOString;

            if (!!this.#localVideoElem) {
                this.#session.videoChannel.insertLocalVideo(this.#localVideoElem);
            }

            if (!!this.#remoteVideoElem) {
                this.#session.videoChannel.insertRemoteVideo(this.#remoteVideoElem);
            }

            this.#session.addOnSessionEndedCallback((session) => {
                this.#onCallEndedCallback.fire(this);
            });

            this.#session.addOnSessionFailedCallback((session) => {
                this.#onCallFailedCallback.fire(this);
            });

            this.#session.addOnMediaConnectedCallback((session) => {
                this.#networkProviders.socketIoProvider.send(IO_MESSAGES.SEND_MEDIA_SESSION_EVENTS, 
                Utils.createMediaSessionEvents(this.topic.id, CATEGORY.TRACK_STATUS, this.#userInfo, enableAudio, 
                    enableVideo, enableCollab, this.#subscribedTime, this.#session.audioChannel.remoteStream.id));
                this.#onMediaConnectedCallback.fire(this);
            });

            this.#session.addOnMediaDisconnectedCallback((session) => {
                this.#onMediaDisconnectedCallback.fire(this);
            });

            this.#session.addOnMediaFailedCallback((session) => {
                this.#onMediaFailedCallback.fire(this);
            });


            this.#session.addOnMediaConnectedCallback((session) => {
                this.#networkProviders.socketIoProvider.send(IO_MESSAGES.SEND_MEDIA_SESSION_EVENTS, 
                Utils.createMediaSessionEvents(this.topic.id, CATEGORY.TRACK_STATUS, this.#userInfo, enableAudio, 
                    enableVideo, enableCollab, this.#subscribedTime, this.#session.audioChannel.remoteStream.id));
            });

            this.#networkProviders.socketIoProvider.send(IO_MESSAGES.SEND_PRESENCE_EVENT, 
                Utils.createPresenceEvent(this.topic.id, CATEGORY.PRESENCE_ONLINE, this.#userInfo));

            this.#networkProviders.socketIoProvider.send(IO_MESSAGES.SEND_MEDIA_SESSION_EVENTS, 
            Utils.createMediaSessionEvents(this.topic.id, CATEGORY.TRACK_STATUS, this.#userInfo, enableAudio, 
                enableVideo, enableCollab));

            return this.#session.start();
        } catch(error) {
            return Promise.reject(error);
        }
    }

    /**
     * @returns {Promise<undefined>}
     */
    end() {        
        let offline = true;

        this.#networkProviders.socketIoProvider.send(IO_MESSAGES.SEND_PRESENCE_EVENT, 
            Utils.createPresenceEvent(this.topic.id, CATEGORY.PRESENCE_LEAVE, this.#userInfo, offline));

        this.#networkProviders.socketIoProvider.send(IO_MESSAGES.SEND_MEDIA_SESSION_EVENTS, 
            Utils.createMediaSessionEvents(this.topic.id, CATEGORY.END_VIDEO, this.#userInfo));

        if (!!this.#localVideoElem) {
            this.#session.videoChannel.removeLocalVideo(this.#localVideoElem);
        }

        if (!!this.#remoteVideoElem) {
            this.#session.videoChannel.removeRemoteVideo(this.#remoteVideoElem);
        }

        if (!!this.#session) {
            return this.#session.end();
        } 
        return Promise.reject("Session not started");
    }

    /**
     * @param {AudioMode} audioMode
     */
    setAudioMode(audioMode) { 
        if (this.#session) {
            this.#session.audioChannel.setAudioMode(audioMode);
        } else {
            this.#sessionOptions.audioMode = audioMode;       
        }
    }

    /**
     * @param {VideoMode} videoMode
     * @returns {Promise<undefined|SessionException>}
     */
    setVideoMode(videoMode) {
        if (this.#session) {
            return this.#session.setVideoMode(videoMode);
        } else {
            this.#sessionOptions.videoMode = videoMode;
            return Promise.resolve();
        }
    }

    /**
     * @param {Boolean}
     */
    setWebCollaboration(enabled) {
        if(this.#session){
            this.#session.setWebCollaboration(enabled);
        }else{
            this.#sessionOptions.collaborationEnabled = enabled;
        }
    }

    /**
     * @returns {Promise<undefined>}
     */
    hold() {
       
    }

    /**
     * @returns {Promise<undefined>}
     */
    unhold() {
        
    }

    /**
     * @returns {Promise<undefined>}
     */
    addParticipant() {

    }

    /**
     * Inserts a video elemnet into the DOM to playback the local video.
     *
     * @param {String} elementId The id of a div in which to insert a video element
     */
    insertLocalVideo(elementId) {
        this.#localVideoElem = elementId;
    }

    /**
     * Inserts a video element into the DOM to playback the remote video.
     *
     * @param {String} elementId The id of a div in which to insert a video element
     */
    insertRemoteVideo(elementId) {
        this.#remoteVideoElem = elementId;
    }

    /**
     * Interface for the callback function to be invoked when a call is ended either locally or
     * remotely.
     *
     * @group Callbacks
     * @callback OnCallEndedCallback
     * @param {Call} call The call that was ended.
     * @param {*} event End session event.
     */

    /**
     * @param {OnCallEndedCallback} callback The function to be executed and added callback when the call is ended.
     */
     addOnCallEndedCallback(callback) {
         this.#onCallEndedCallback.add(callback);
    }

    /**
     * @param {OnCallEndedCallback} callback The function to be executed and removed callback when the call is ended.
     */
     removeOnCallEndedCallback(callback) {
        this.#onCallEndedCallback.remove(callback);
    }


    /**
     * Interface for the callback function to be invoked when the call fails. This callback method
     * is called when the call has failed either by a local error or by an error feedback received
     * over the signaling network. The specific reason for failure is identified by the SessionException
     * argument. It should be noted that the Call that has failed is not automatically ended. The
     * application needs to call {@link Call#end|Call.end()} to end the failed call.
     *
     * @group Callbacks
     * @callback OnCallFailedCallback
     * @param {Call} call The call that has failed.
     * @param {*} event Call failed event.
     */

    /**
     * @param {OnCallFailedCallback} callback The function to be executed and added callback and when the call failed.
     */
    addOnCallFailedCallback(callback) {
        this.#onCallFailedCallback.add(callback);
    }

    /**
     * @param {OnCallFailedCallback} callback The function to be executed and removed callback and when the call failed.
     */
    removeOnCallFailedCallback(callback) {
        this.#onCallFailedCallback.remove(callback);
    }


    /**
     * Interface for the callback function to be invoked when the audio/video media path is
     * connected.
     *
     * @group Callbacks
     * @callback OnMediaConnectedCallback
     * @param {Call} call
     */

    /**
     * @param {OnMediaConnectedCallback} callback The function to be executed and added callback when the audio/video media path is connected.
     *
     */
     addOnMediaConnectedCallback(callback) {
        this.#onMediaConnectedCallback.add(callback); 
    }

    /**
     * @param {OnMediaConnectedCallback} callback The function to be executed and removed callback when the audio/video media path is connected.
     */
    removeOnMediaConnectedCallback(callback) {
        this.#onMediaConnectedCallback.remove(callback); 
    }


    /**
     * Interface for the callback function to be invoked when the audio/video media path is
     * disconnected but may still be recoverable.
     *
     * @group Callbacks
     * @callback OnMediaDisconnectedCallback
     * @param {Call} call
     */

    /**
     * @param {OnMediaDisconnectedCallback} callback The function to be executed and added callback when the audio/video media path is disconnected.
     *
     */
    addOnMediaDisconnectedCallback(callback) {
        this.#onMediaDisconnectedCallback.add(callback); 
    }

    /**
     * @param {OnMediaDisconnectedCallback} callback The function to be executed and removed callback when the audio/video media path is disconnected.
     */
    removeOnMediaDisconnectedCallback(callback) {
        this.#onMediaDisconnectedCallback.remove(callback); 
    }


    /**
     * Interface for the callback function to be invoked when the audio/video media path has
     * failed and will never be re-connected.
     *
     * @group Callbacks
     * @callback OnMediaFailedCallback
     * @param {Call} call
     */

    /**
     * @param {OnMediaFailedCallback} callback The function to be executed and added callback when the audio/video media path has failed.
     *
     */
    addOnMediaFailedCallback(callback) {
        this.#onMediaFailedCallback.add(callback); 
    }

    /**
     * @param {OnMediaFailedCallback} callback The function to be executed and removed callback when the audio/video media path has failed.
     */
    removeOnMediaFailedCallback(callback) {
        this.#onMediaFailedCallback.remove(callback); 
    }

}