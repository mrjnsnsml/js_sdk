/*
 * Avaya Inc. Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to company instructions.
 * Copyright 2021 Avaya Inc. All Rights Reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual or
 * intended publication of such source code.
 */

import {Callbacks} from 'avayamedia';
import Call from './call_api.js';
import IncomingCall from './incomingCall_api.js';
import UserInfo from '../shared/userInfo_api.js';
import NetworkProviders from '../../base/network/networkProviders.js';

/**
 * @hideconstructor
 */
class IncomingCallHandler {
    #callService;
    #onIncomingCallCallback = new Callbacks();
  
    constructor(callService) {
        this.#callService = callService;
    }

    callback(call) {
        // TODO: What to do with call. How to get topic.
        const topic = "IncomingCall";
        const incomingCall = new IncomingCall(topic, this.#callService);
        this.#callService.getCalls().push(incomingCall);
        this.#onIncomingCallCallback.fire(incomingCall);
    }

    addOnIncomingCallCallback(callback) {
        this.#onIncomingCallCallback.add(callback);
    }

    removeOnIncomingCallCallback(callback) {
        this.#onIncomingCallCallback.remove(callback);
    }
}

/**
 * @hideconstructor
 */
export default class CallService {
    #userInfo;
    #calls = []; 
    #activeCall = undefined;
    #incomingCallHandler = undefined;
    #networkProviders = undefined;
    #avayaMediaInstance = undefined;

    /**
     * @param {NetworkProviders} networkProviders 
     */
    constructor(avayaMediaInstance, networkProviders) {
        this.#avayaMediaInstance = avayaMediaInstance;
        this.#networkProviders = networkProviders;
        this.#incomingCallHandler = new IncomingCallHandler(this);
    }

    /**
     * Creates a new call based on the given topic.
     * @param {Topic} topic 
     */
    createCallForTopic(topic) {
        const call = new Call(this.#avayaMediaInstance, topic, this.#userInfo, this.#networkProviders);
        this.#calls.push(call);
        return call;
    }

    /**
    * Registers for incoming call if calls service has not started.
    * @returns {boolean}
    */
    registerForIncoming() {
        return this.#avayaMediaInstance.registerIncomingCall();
    }
    
    /**
     * @param {UserInfo} userInfo
     */
    set userInfo(user) {
        this.#userInfo = user;
    }

    get userInfo() {
        return this.#userInfo;
    }

    /**
     * Returns all calls that belongs to the current session.
     * @returns {Call[]} 
     */
    get calls() {
        return this.#calls;
    }

    /**
     * Returns the current active call.
     * @returns {Call}
     */
    get activeCall() {
        return this.#activeCall;
    }    

    /**
     * Interface for the callback function to be invoked when there is an incoming call.
     *
     * @group Callbacks
     * @callback OnIncomingCallCallback
     */

    /**
    * @param {OnIncomingCallCallback} callback The function to be executed and added callback when an incoming call available.
    *
    */
     addOnIncomingCallCallback(callback) {
        this.#incomingCallHandler.addOnIncomingCallCallback(callback);
        this.#avayaMediaInstance.addOnIncomingCallCallback(this.#incomingCallHandler.callback);
    }

    /**
    * @param {OnIncomingCallCallback} callback The function to be executed and removed callback when an incoming call available.
    */
    removeOnIncomingCallCallback(callback) {
        this.#incomingCallHandler.removeOnIncomingCallCallback(callback);
        this.#avayaMediaInstance.removeOnIncomingCallCallback(this.#incomingCallHandler.callback);
    }
}