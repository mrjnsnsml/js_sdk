/*
 * Avaya Inc. Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to company instructions.
 * Copyright 2021 Avaya Inc. All Rights Reserved.
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual or
 * intended publication of such source code.
 */

import PagingDataSetHelper from "../services/shared/pagingDataSetHelper.js";
import PagingDataSet from "../services/shared/pagingDataSet_api.js";
import MediaSession from "../services/media/mediaSession.js";
import MediaSessionEvents from "../services/media/mediaSessionEvents.js";
import MediaSessionSender from "../services/media/mediaSessionSender.js";
import PresenceEvent from '../services/presence/presenceEvent.js';

import UserInfo, {PhoneNumber, EmailAddress} from '../services/shared/userInfo_api.js';

export default class Utils {
    static createUserInfo(userResponse) {
        let userInfo;
        if (userResponse.aType === 'anonymous') { // guest
            userInfo = new UserInfo(userResponse._id, userResponse.aType, userResponse.username, userResponse.displayname);
        } else {
            userInfo = new UserInfo(userResponse._id, userResponse.aType, userResponse.username, userResponse.displayname, 
                userResponse.name.familyname, userResponse.name.givenname, userResponse.name.middleName);
            userInfo.honorificPrefix = userResponse.name.honorific_prefix;
            userInfo.honorificSuffix = userResponse.name.honorific_suffix;
            userInfo.pronunciation = userResponse.name.pronunciation;
            userInfo.pictureUrl = userResponse.picture_url;
            userInfo.timezone = userResponse.timezone;
            userInfo.type = userResponse.aType;
            userResponse.phone_numbers.forEach((phone) => {
                const newPhone = new PhoneNumber(phone.type, phone.formattedType, phone.value, phone.canonicalForm);
                newPhone.identity = phone.identity;
                newPhone.login = phone.login;
                newPhone.primary = phone.primary;
                newPhone.private_num = phone.private_num;
                newPhone.unique = phone.unique;
                newPhone.verified = phone.verified;
                userInfo.phoneNumbers.push(newPhone);
            });
            userResponse.emails.forEach((email) => {
                const newEmail = new EmailAddress(email.value, email.primary);
                newEmail.label = email.label;
                newEmail.type = email.type;
                newEmail.relationdef_id = email.relationdef_id;
                userInfo.emailAddresses.push(newEmail);
            });
        }

        return userInfo;
    }

    static createPagingDataSet(response, networkProviders){
        let dataSetHelper = new PagingDataSetHelper();
        let dataSet = new PagingDataSet(dataSetHelper);
        dataSetHelper.restProvider = networkProviders.restProvider;
        dataSetHelper.data = response.data;
        if(response.nextPageUrl===''){
            dataSetHelper.hasNextPage = false;
        } else{
            dataSetHelper.hasNextPage = true;
            dataSetHelper.nextPageUrl = response.nextPageUrl;
        }
        return dataSet;
    }

    static createMediaSession(audioEnabled, videoEnabled, collabEnabled, remoteStreamId) {
        let mediaSession;
        if (audioEnabled || videoEnabled || collabEnabled) {
            const isCollabOnly = !audioEnabled && !videoEnabled && collabEnabled;
            mediaSession = new MediaSession(audioEnabled, videoEnabled, isCollabOnly); 
            if (remoteStreamId) {
                mediaSession.connected = true;
            }           
        }

        return mediaSession;
    }

    static createMediaSessionEvents(topicId, category, userInfo, audioEnabled, videoEnabled, collabEnabled, remoteStreamId, data=[]) {
        let mediaSession = Utils.createMediaSession(audioEnabled, videoEnabled, collabEnabled, remoteStreamId);
        let sessionEvent = new MediaSessionEvents(topicId, category, mediaSession, new MediaSessionSender(userInfo), remoteStreamId);
        return sessionEvent.json();
    }

    static createPresenceEvent(topicId, category, userInfo, offline=false, idle=false) {
        let sessionEvent = new PresenceEvent(topicId, category, offline, idle, new MediaSessionSender(userInfo));
        return sessionEvent.json();
    }
}