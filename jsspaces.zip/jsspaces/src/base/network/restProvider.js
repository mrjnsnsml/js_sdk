/*
 * Avaya Inc. Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to company instructions.
 * Copyright 2021 Avaya Inc. All Rights Reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual or
 * intended publication of such source code.
 */

import CredentialProvider from '../../config/credentialProvider_api.js';
import AbstractNetworkProvider from "./abstractNetworkProvider.js";
import NetworkException from './networkException_api.js';
import Logger from '../logger.js';
import TokenType from '../../config/tokenType_api.js';

export default class RESTProvider extends AbstractNetworkProvider{
    #serverUrl;

    /**
     * @param {String} url 
     * @param {CredentialProvider} credentialProvider 
     */
    constructor(credentialProvider) {
        super(undefined, credentialProvider);
    }
    
    set serverUrl(url) {
        this.#serverUrl = url;
    }

    get serverUrl() {
        return this.#serverUrl;
    }
    
    /**
     * Sends message to network provider
     * @param {String} url
     * @param {*} [options] 
     * @returns {Promise<String|CommunicationException>}
     */
    async get(url, options={}) {
        const authType = this._credentialProvider.tokenType === TokenType.JWT ? `${TokenType.JWT} `: `${TokenType.BEARER} `;
        const defaultOptions = {
            method: 'GET',
            mode: 'cors',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'Authorization': authType + this._credentialProvider.token
            }            
        };

        const finalOptions = !!options ? Object.assign(defaultOptions, options) : defaultOptions;
        try {
            const response = await fetch(url, finalOptions);

            if (!response.ok) {
                this._triggerInvalidCredentialIfNeeded(response);
                return Promise.reject(new NetworkException(response.status, response.statusText));
            } else if (response.status === 202 || response.status === 204) {
                return Promise.resolve();
            } else {     
                return response.json();
            }
        } catch (error) {
            Logger.error("Error during GET request: ", error);
            return Promise.reject(new NetworkException(500, error.message));
        }
    }

    /**
     * Sends message to network provider
     * @param {String} url
     * @param {*} [options] 
     * @returns {Promise<undefined|CommunicationException>}
     */
     async delete(url, options={}) {
        const authType = this._credentialProvider.tokenType === TokenType.JWT ? `${TokenType.JWT} `: `${TokenType.BEARER} `;
        const defaultOptions = {
            method: 'DELETE',
            mode: 'cors',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'Authorization': authType + this._credentialProvider.token
            }            
        };

        const finalOptions = !!options ? Object.assign(defaultOptions, options) : defaultOptions;
        try {
            const response = await fetch(url, finalOptions);
            if (!response.ok) {
                this._triggerInvalidCredentialIfNeeded(response);
                return Promise.reject(new NetworkException(response.status, response.statusText));
            }                
            return Promise.resolve();
        } catch (error) {
            Logger.error("Error during DELETE request: ", error);
            return Promise.reject(new NetworkException(500, error.message));
        }
    }

    /**
     * Sends message to network provider
     * @param {String} url
     * @param {String} content
     * @param {*} [options] 
     * @returns {Promise<undefined|CommunicationException>}
     */
    async post(url, content, options={}) {
        const authType = this._credentialProvider.tokenType === TokenType.JWT ? `${TokenType.JWT} `: `${TokenType.BEARER} `;
        const defaultOptions = {
            method: 'POST',
            mode: 'cors',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'Authorization': authType + this._credentialProvider.token
            },
            body: content           
        };

        const finalOptions = !!options ? Object.assign(defaultOptions, options) : defaultOptions;
        try {
            const response = await fetch(url, finalOptions);
            if (!response.ok) {
                this._triggerInvalidCredentialIfNeeded(response);
                return Promise.reject(new NetworkException(response.status, response.statusText));
            } else if (response.status === 202 || response.status === 204) {
                return Promise.resolve();
            } else {     
                return response.json();
            }
        } catch (error) {
            Logger.error("Error during POST request: ", error);
            return Promise.reject(new NetworkException(500, error.message));
        }
    }

    _triggerInvalidCredentialIfNeeded(response) {
        if (response.status === 401 || response.status === 403) {
            this._credentialProvider._triggerInvalidCredential(response.status, response.statusText);
        }
    }
}