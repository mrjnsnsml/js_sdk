/*
 * Avaya Inc. Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to company instructions.
 * Copyright 2021 Avaya Inc. All Rights Reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual or
 * intended publication of such source code.
 */

import CredentialProvider from '../../config/credentialProvider_api.js';

export default class AbstractNetworkProvider {
    /**
     * @param {String} url 
     * @param {CredentialProvider} credentialProvider 
     */
    constructor(url, credentialProvider) {
        this._url = url;
        this._credentialProvider = credentialProvider;
    }

    /**
     * Triggers when connected to network provider
     */
    onOpen() {}

    /**
     * Triggers when connection to network provider is closed
     */
    onClose() {}
    
    /**
     * Triggers when error sending message to network provider or unexpected error
     * @param {*} error 
     */
    onError(error) {}
    
    /**
     * Triggers when disconnected from network provider
     */
    onConnectionUnavailable(reason) {}

    /**
     * Triggers when failed to connection
     * @param {String} reason 
     */
    onConnectionError(reason) {}

    /**
     * Initiates connection to network provider

     * @param {*} [options] 
     */
    start(options) {
        this.onOpen();
    }

    /**
     * Closes network connection to network provider
     */
    close() {
        this.onClose();
    }

}