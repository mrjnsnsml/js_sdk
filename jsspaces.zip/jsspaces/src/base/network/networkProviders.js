/*
 * Avaya Inc. Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to company instructions.
 * Copyright 2021 Avaya Inc. All Rights Reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual or
 * intended publication of such source code.
 */

import SocketIOProvider from './socketIoProvider.js';
import RestProvider from './restProvider.js';
import CredentialProvider from '../../config/credentialProvider_api.js';


const SOCKET_IO_NAMESPACE = '/chat';

const CATEGORY = {
    TRACK_STATUS: 'tracksstatus', // Toggled our local audio or video
    PRESENCE_ONLINE: 'app.event.presence.party.online', // Changes in the state of the media session
    PRESENCE_LEAVE: 'app.event.presence.party.leaves', // 
    START_SCREENSHARE: 'video.startscreenshare', // Begin screen sharing 
    SCREENSHARE_UPLOAD_URL: 'video.screenshare.uploadurl', // URLs to upload the frames of the screen to be shared
    SCREENSHARE_DATA: 'video.screensharedata', // When each frame is uploaded
    STOP_SCREENSHARE: 'video.stopscreenshare', // Screen is no longer being shared
    END_VIDEO: 'video.end' // User no longer wants to participate in a call they can leave the media session
};

const IO_MESSAGES = {
    SUBSCRIBE_CHANNEL: 'SUBSCRIBE_CHANNEL',
    SUBSCRIBE_CHANNEL_FAILED: 'SUBSCRIBE_CHANNEL_FAILED',
    UNSUBSCRIBE_CHANNEL: 'UNSUBSCRIBE_CHANNEL',
    CHANNEL_SUBSCRIBED: 'CHANNEL_SUBSCRIBED',
    CHANNEL_UNSUBSCRIBED:'CHANNEL_UNSUBSCRIBED',
    SEND_MESSAGE: 'SEND_MESSAGE',
    MESSAGE_SENT: 'MESSAGE_SENT',
    SEND_MESSAGE_FAILED: 'SEND_MESSAGE_FAILED',
    SEND_MEDIA_SESSION_EVENTS: 'SEND_MEDIA_SESSION_EVENTS',
    MEDIA_SESSION_RESPONSE: 'MEDIA_SESSION_RESPONSE',
    SEND_PRESENCE_EVENT: 'SEND_PRESENCE_EVENT',
    PRESENCE_EVENT_RESPONSE: 'PRESENCE_EVENT_RESPONSE',
    PRESENCE_EVENT_RESPONSE_BATCHED: 'PRESENCE_EVENT_RESPONSE_BATCHED',
    APP_PAIRING_AUTHORIZED: 'APP_PAIRING_AUTHORIZED'
};

export default class NetworkProviders {
    #socketIoProvider;
    #restProvider;
    #credentialProvider;

    /**
     * Creates REST provider. Needs to be created before SocketIO provider.
     * @param {CredentialProvider} credentialProvider 
     */
    createRestProvider(credentialProvider) {
        this.#credentialProvider = credentialProvider;    
        this.#restProvider = new RestProvider(this.#credentialProvider);   
    }

    /**
     * Creates SocketIO provider
     * @param {String} serverUrl 
     */
    createSocketIoProvider(serverUrl) {
        this.#socketIoProvider = new SocketIOProvider(serverUrl, this.#credentialProvider, SOCKET_IO_NAMESPACE);
    }

    /**
     * @type {SocketIOProvider}
     */
    get socketIoProvider() {
        return this.#socketIoProvider;
    }

    /**
     * @type {RESTProvider}
     */
    get restProvider() {
        return this.#restProvider;
    }
}

export {SOCKET_IO_NAMESPACE, IO_MESSAGES, CATEGORY};