/*
 * Avaya Inc. Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to company instructions.
 * Copyright 2021 Avaya Inc. All Rights Reserved.
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual or
 * intended publication of such source code.
 */

/**
 * This class represents the network exception.
 * @hideconstructor
 */
 export default class NetworkException {
    #code;
    #message;

    constructor(code = 500, message = '') {
        this.#code = code;
        this.#message = message;
    }

    /**
     * HTTP Error Code
     * @readonly
     * @type {Number}
     */
    get code() {
        return this.#code;
    }

    /**
     * Detail message if provided.
     * @readonly
     * @type {String}
     */
    get message() {
        return this.#message;
    }

    toString() {
        return 'NetworkException: (' + this.code + ',' + this.message + ')';
    }
}
