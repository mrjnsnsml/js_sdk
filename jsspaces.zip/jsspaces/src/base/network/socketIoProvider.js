/*
 * Avaya Inc. Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to company instructions.
 * Copyright 2021 Avaya Inc. All Rights Reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual or
 * intended publication of such source code.
 */

import {io} from './socketIOClient.js';
import CredentialProvider from '../../config/credentialProvider_api.js';
import AbstractNetworkProvider from "./abstractNetworkProvider";
import NetworkException from './networkException_api.js';
import Logger from '../logger.js';

/**
 * @hideconstructor
 */
export default class SocketIOProvider extends AbstractNetworkProvider {
    #socket;
    #namespace;
    #ioClient;

    /**
     * @param {String} url 
     * @param {CredentialProvider} credentialProvider 
     * @param {String} [namespace]
     * @param {*} [mockClient] for unit testing only
     */
    constructor(url, credentialProvider, namespace='/', mockClient) {
        super(url, credentialProvider);
        this.#namespace = namespace;
        this.#ioClient = mockClient || io; 
    }

    /**
     * Initiates connection to network provider

     * @param {*} [options] 
     */
    start(options={}) {
      const defaultOptions = {
          query: "token=" + this._credentialProvider.token + `&tokenType=${this._credentialProvider.tokenType === 'bearer' ? 'oauth' : 'jwt'}`,
          transports: ['websocket']
      };

      const finalOptions = !!options ? Object.assign(defaultOptions, options) : defaultOptions;

      if (this.#socket && !this.#socket.disconnected) {
        this.#socket.close();
      }

      return new Promise((resolve, reject) => {
            const socketUrl = this.#namespace === '/' ? this._url : this._url + this.#namespace;          
            this.#socket = this.#ioClient(socketUrl, finalOptions);

            this.#socket.on("connect", () => {
                Logger.debug("Socket IO message connected");
                this.onOpen();
                resolve();
            });
            
            this.#socket.on("disconnect", (reason) => {
                Logger.warn("Socket IO disconnected reason: ", reason);
                this.onConnectionUnavailable(reason);

                // else the socket will automatically try to reconnect
                reject(new NetworkException(503, reason));
            });
            
            this.#socket.on("connect_error", (error) => {
                Logger.error("Socket IO connection error: ", error);
                this.onConnectionError(error);
                reject(new NetworkException(503, error));
            });

            this.#socket.on("error", (error) => {
                Logger.error("Socket IO error: ", error);
                this.onError(error);
                reject(new NetworkException(500, error));
            });
      });
    }

    /**
     * Generic events listener
     * @param {String[]} events 
     * @param {(event, payload)} callback 
     */
    addEventsListener(events, callback) {
        if (this.#socket && !this.#socket.disconnected) {
            events.forEach((event) => {
                this.#socket.on(event, (payload) => {
                    callback(event, payload);
                });
            });
        }
    }

    /**
     * Specific event listener
     * @param {String} event 
     * @param {(payload)} callback 
     */
    onMessage(event, callback) {
        if (this.#socket && !this.#socket.disconnected) {
            this.#socket.on(event, callback);
        }
    }

    /**
     * Sends message to network provider
     * @param {String} message 
     * @param {*} [payload] 
     */
    send(message, payload) {
        this.#socket.emit(message, payload);
    }

    /**
     * Closes network connection to network provider
     */
    close() {
        this.#socket.close();
        this.onClose();
    }

}