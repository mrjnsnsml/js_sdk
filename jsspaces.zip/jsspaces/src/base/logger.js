/*
 * Avaya Inc. Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to company instructions.
 * Copyright 2020 Avaya Inc. All Rights Reserved.
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual or
 * intended publication of such source code.
 */

import loggerTags from './loggerTags.js'

/**
* Logger class for CloudCommunication
* @hideconstructor
*/
export default class Logger {
    /**
     * @type {AvayaClientServices.Base.Logger}
    */
    static #logger;
  
    /**
     * @param {AvayaClientServices.Base.Logger} logger
     */
    static set logger(logger) {
        this.#logger = logger;
    }
  
    /**
     * @returns {AvayaClientServices.Base.Logger} logger
     */
    static get logger() {
        return this.#logger;
    }
  
    static debug() { 
        if (this.#logger) {
            if (arguments.length === 1) {
                this.#logger.debug(loggerTags.CLOUD_COMMUNICATION, arguments[0]);
            } else if (arguments[0] === loggerTags.CLOUD_COMMUNICATION) {
                    this.#logger.debug(...arguments);
                } else {
                    this.#logger.debug(loggerTags.CLOUD_COMMUNICATION, ...arguments);
            }
        }
    }
  
    static trace() {
        if (this.#logger) {
            if (arguments.length === 1) {
                this.#logger.trace(loggerTags.CLOUD_COMMUNICATION, arguments[0]);
            } else if (arguments[0] === loggerTags.CLOUD_COMMUNICATION) {
                    this.#logger.trace(...arguments);
                } else {
                    this.#logger.trace(loggerTags.CLOUD_COMMUNICATION, ...arguments);
            }
        }
    }
  
    static info() {
        if (this.#logger) {
            if (arguments.length === 1) {
                this.#logger.info(loggerTags.CLOUD_COMMUNICATION, arguments[0]);
            } else if (arguments[0] === loggerTags.CLOUD_COMMUNICATION) {
                    this.#logger.info(...arguments);
                } else {
                    this.#logger.info(loggerTags.CLOUD_COMMUNICATION, ...arguments);
            }
        }
    }
  
    static warn() {
        if (this.#logger) {
            if (arguments.length === 1) {
                this.#logger.warn(loggerTags.CLOUD_COMMUNICATION, arguments[0]);
            } else if (arguments[0] === loggerTags.CLOUD_COMMUNICATION) {
                    this.#logger.warn(...arguments);
                } else {
                    this.#logger.warn(loggerTags.CLOUD_COMMUNICATION, ...arguments);
            }
        }
    }
  
    static error() {
        if (this.#logger) {
            if (arguments.length === 1) {
                this.#logger.error(loggerTags.CLOUD_COMMUNICATION, arguments[0]);
            } else if (arguments[0] === loggerTags.CLOUD_COMMUNICATION) {
                    this.#logger.error(...arguments);
                } else {
                    this.#logger.error(loggerTags.CLOUD_COMMUNICATION, ...arguments);
            }
        }
    }
  
    static fatal() {
        if (this.#logger) {
            if (arguments.length === 1) {
                this.#logger.fatal(loggerTags.CLOUD_COMMUNICATION, arguments[0]);
            } else if (arguments[0] === loggerTags.CLOUD_COMMUNICATION) {
                    this.#logger.fatal(...arguments);
                } else {
                    this.#logger.fatal(loggerTags.CLOUD_COMMUNICATION, ...arguments);
            }
        }
    }

    /**
     * @public
     * @function
     * @param {Object} logger
     * @param {boolean} disableTimestamps
     * @returns {void}
    */
    static addLogger(logger, disableTimestamps) {
        if (!logger || typeof logger.log === 'undefined') {
            throw new TypeError('Logger should implement log method.');
        }
        logger.disableTimestamps = disableTimestamps;
        this.#logger = logger;
    }
}
  