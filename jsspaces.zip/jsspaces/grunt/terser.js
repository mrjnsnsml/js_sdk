module.exports = {
    options: {},
    main: {
        files: {
            'build/CloudCommunication.min.js': ['build/CloudCommunication.js'],
            'build/CloudCommunicationRenderer.min.js': ['build/CloudCommunicationRenderer.js'],
        }
    }
}