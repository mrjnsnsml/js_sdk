module.exports = {
    unit: {
        options: {
            configFile: 'spec/unit.karma.config.js',
            singleRun: true
        }
    },
    functional: {
        options: {
            configFile: 'spec/functional.karma.config.js',
            singleRun: true
        }
    }
}