const fs = require('fs');

module.exports = {
    clone_devlib: {
        files:[
            { src: 'build/CloudCommunication.js',dest: 'build/CloudCommunication.min.js'},
            { src: 'build/CloudCommunicationRenderer.js', dest:'build/CloudCommunicationRenderer.min.js'}]
    },
    package: {
        src: 'build/CloudCommunication.min.js',
        dest: 'packaging/dist/CloudCommunication.min.js'
    },
    jsmpaas_sdk:{
        files: [
            {
                expand: true,
                cwd: '../jsmpaas/build',
                src: 'AvayaMedia.min.js',
                dest: 'node_modules/avayamedia/dist'
            }
        ]
    },
}