module.exports = {
    prod_docs: {
        options: {
            archive: 'target/docs/production_docs.zip'
        },
        files: [
            {expand: true, cwd: 'api_docs/', src: ['**/*'], dest: '/'}
        ]
    },
    test_app: {
        options: {
            archive: 'target/test_app/test_app.zip'
        },
        files: [
            {expand: true, cwd: 'test-app/build/', src: ['**/*'], dest: '/'}
        ]
    },
    full_package: {
        options: {
            archive: 'target/full_package.zip'
        },
        files: [
            {expand: true, cwd: 'api_docs/', src: ['**/*'], dest: '/api_docs'},
            {expand: true, cwd: 'test-app/build/', src: ['**/*'], dest: '/test_app'},
            {expand: true, cwd: 'build/', src: ['**/*'], dest: '/'}
        ]
    }
}