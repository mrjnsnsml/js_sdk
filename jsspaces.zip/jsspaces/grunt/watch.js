module.exports = {
    /**
     * Runs dev build after every change in project or test files
     */
    dev: {
        options: {
            spawn: false,
            interrupt: true,
            interval: 500
        },
        files: ['src/*.js', 'src/**/*.js', 'spec/functional/*.spec.js', 'spec/functional/**/*.mock.js'],
        tasks: ['devSpaces']
    },

    /**
     * Runs unit test after every change in project files
     */
    unit: {
        options: {
            atBegin: true,
            spawn: false,
            interrupt: true
        },
        files: ['src/*.js', 'src/**/*.js', 'spec/unit/*.spec.js'],
        tasks: ['unit']
    },

    /**
     * Runs functional test after every change in project files
     */
    functional: {
        options: {
            atBegin: true,
            spawn: false,
            interrupt: true
        },
        files: ['<%= watch.dev.files %>'],
        tasks: ['functional']
    },
}
