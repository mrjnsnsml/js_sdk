const babel = require('@rollup/plugin-babel').default;
const nodeResolve = require("@rollup/plugin-node-resolve").nodeResolve;

module.exports = {
    cloudCommunication: {
        options: {
            plugins: function() {
                return [
                    babel({
                        babelHelpers: 'bundled',
                        exclude: './node_modules/**'
                    }),
                    nodeResolve({
                        browser: true,
                        resolveOnly: ['avayamedia']
                    })
                ]
            }
        },
        dest: 'build/CloudCommunication.js',
        src: 'src/cloudCommunication_api.js'
    },
    cloudCommunicationRenderer: {
        options: {
            plugins: function() {
                return [
                    babel({
                        babelHelpers: 'bundled',
                        exclude: './node_modules/**'
                    }),
                    nodeResolve({
                        browser: true,
                        resolveOnly: ['avayamedia']
                    })
                ]
            }
        },
        dest: 'build/CloudCommunicationRenderer.js',
        src: 'src/services/collaboration/cloudCommunicationRenderer_api.js'
    },
}