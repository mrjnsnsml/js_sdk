var { version } = require('../package.json');
var buildNumber = require("grunt").option('buildNumber') || '0';
var preReleaseTag = require('grunt').option('preReleaseTag') || '-';

module.exports = {
  prod: {
    options: {
      patterns: [
        {
          match: 'PROJECT_VERSION',
          replacement: version + '.' + buildNumber
        }
      ]
    },
    files: [
      {expand: true, src: ['src/cloudCommunication_api.js']}
    ]
  },
  publish_prod: {
    options: {
      patterns: [
        {
          match: 'VERSION',
          replacement: version + preReleaseTag + buildNumber
        }
      ]
    },
    files: [
      {expand: true, src: ['packaging/package.json']}
    ]
  },
  socketio: {
    options: {
      patterns: [
        {
          match: '})(this, function() {',
          replacement: '})(self, function() {'
        }
      ],
      usePrefix: false
    },
    files: [
      {expand: true, src: ['node_modules/socket.io-client/dist/socket.io.dev.js']}
    ]
  }
};