module.exports = {
    options: {
        configFile: '.eslintrc',
        fix: true
    },
    
    target: [
      'src/*.js',
      'src/**/*.js',
      'spec/unit/**/**/*.spec.js',
      'spec/functional/**/*.mock.js',
      'spec/functional/**/*.spec.js'
    ] 
}