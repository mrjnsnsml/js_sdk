module.exports = {
    options: {
        limit: 10
    },

    dev: [
        'clean:build',
        'rollup'
    ],

    clean_prod: [
        'clean:build',
        'clean:result'
    ],

    copy_libs: [
        'copy:jsmpaas_sdk',
    ],

    prod_rollup: [
        'rollup'
    ],

    prod_terser: [
        'terser'
    ],

    prod_clean_compress: [
        'clean:result',
        'compress:prod_docs',
        'compress:full_package'
    ],

    packaging: [
        'copy:package',
        'clean:result'
    ],

    rename_devlib: [
        'copy:clone_devlib'
    ],
}