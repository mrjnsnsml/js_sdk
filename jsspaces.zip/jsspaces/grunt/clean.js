module.exports = {
    doc: ['doc'],
    build: ['build', 'coverage'],
    result: ['build/CloudCommunication.js', 'build/CloudCommunicationRenderer.js']
}