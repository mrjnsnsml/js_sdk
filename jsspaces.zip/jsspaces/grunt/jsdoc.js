module.exports = {
    api: {
        options: {
            private: false,
            destination: 'api_docs',
            recurse: true,
            template: "jsdoc_tpl/api_tpl",
            configure: "jsdoc_tpl/api_tpl/jsdoc.api.conf.json"
        }
    }
}