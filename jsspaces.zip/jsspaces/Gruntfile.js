module.exports = (grunt) => {
    require('time-grunt')(grunt);
    require('load-grunt-config')(grunt, {
      jitGrunt: {
      // here you can pass options to jit-grunt (or just jitGrunt: true)
      staticMappings: {
        sprite: 'grunt-spritesmith'
      }
    }
  });
};