const fs = require('fs');
const path = require('path');

const libDirectory = path.join(__dirname, 'lib');

fs.readdir(path.join(__dirname, '../libs'), (err, data) => {
    if (!err) {
        if (!fs.existsSync(libDirectory)) {
            fs.mkdirSync(libDirectory);
        }
        const readDir = (route) => {
            fs.readdir(route, (err, data) => {
                for (const file of data) {
                    if (fs.lstatSync(path.join(route, file)).isDirectory()) {
                        if (Array.isArray(path.join(route, file)) && file.length) {
                            for (const filePath of file) {
                                readDir(path.join(route, filePath));
                            }
                        } else {
                            readDir(path.join(route, file));
                        }
                    } else {
                        fs.createReadStream(path.join(route, file)).pipe(fs.createWriteStream(path.join(libDirectory, file)));
                    }
                }
            });
        };

        for (const file of data) {
            if (fs.lstatSync(path.join(__dirname, '../libs', file)).isDirectory()) {
                if (Array.isArray(file) && file.length) {
                    for (const dir of file) {
                        readDir(dir);
                    }
                } else {
                    readDir(path.join(__dirname, '../libs', file));
                }
            } else {
                fs.copyFileSync(path.join(__dirname, '../libs', file), path.join(__dirname, 'libs', file));
            }
        }
    }

});
