const path = require('path');
const fs = require('fs');
const webpack = require('webpack');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const CopyWebpackPlugin = require('copy-webpack-plugin');
const { CleanWebpackPlugin } = require('clean-webpack-plugin');
const ZipPlugin = require('zip-webpack-plugin');

const Paths = {
    SRC: path.join(__dirname, './src'),
    DIST: path.join(__dirname, './dist'),
    BUILD: path.join(__dirname, './build'),
    PUBLIC: path.join(__dirname, './public/'),
    NODE_MODULES: path.join(__dirname, './node_modules')
};

const DEFAULT_ZIP_NAME = 'jsspaces-test-app';

const config = {
    entry: {
        main: path.join(__dirname, 'src', 'index.js'),
    },
    output: {
        path: Paths.BUILD,
        filename: '[name].js',
    },
    module: {
        rules: [
            {
                test: /\.(js|jsx)$/,
                exclude: /node_modules/,
                use: {
                    loader: 'babel-loader',
                    options: {
                        "presets": [
                            [
                                "@babel/env",
                                {
                                    "targets": [
                                        "defaults",
                                        {
                                            "chrome" : "59",
                                            "safari" : "11",
                                            "firefox": "54",
                                            "node": "current"
                                        }
                                    ],
                                    "useBuiltIns": "usage",
                                    "corejs": 3
                                }
                            ],
                            "@babel/react"
                        ],
                        "plugins": ["@babel/plugin-proposal-class-properties", "@babel/plugin-proposal-private-methods"]
                    }
                },
            },
            {
                test: /\.css$/,
                use: [
                    'style-loader',
                    {
                        loader: 'css-loader',
                        options: {
                            modules: true,
                        },
                    },
                    'postcss-loader',
                ],
            },
            {
                test: /\.(?:ico|gif|png|jpg|jpeg)$/i,
                type: 'asset/resource',
            },
            {
                test: /\.(woff(2)?|eot|ttf|otf|svg|)$/,
                type: 'asset/inline',
            },
        ],
    },
    resolve: {
        modules: [Paths.SRC, Paths.NODE_MODULES],
        extensions: ['.js', '.jsx', '.json', '.css'],
        fallback: { util: false,
                    stream: false,
                    buffer: false,
        },
        alias: {
            '@actions': path.resolve(__dirname, 'src/actions/'),
            '@build': path.resolve(__dirname, '../build/'),
            '@components': path.resolve(__dirname, 'src/components/'),
            '@constants': path.resolve(__dirname, 'src/constants/'),
            '@context': path.resolve(__dirname, 'src/context'),
            '@layouts': path.resolve(__dirname, 'src/layouts/'),
            '@pages': path.resolve(__dirname, 'src/pages/'),
            '@reducers': path.resolve(__dirname, 'src/reducers/'),
            '@routers': path.resolve(__dirname, 'src/routers/'),
            '@shared': path.resolve(__dirname, 'src/shared/'),
            '@utils': path.resolve(__dirname, 'src/shared/utils/'),
            '@styles': path.resolve(__dirname, 'src/styles/'),
        },
    },
    plugins: [
        new CleanWebpackPlugin(),
        new webpack.ProvidePlugin({
            $: 'jquery',
            jQuery: 'jquery',
            xmlToJSON: 'xmltojson',
            JSZip: 'jszip'
          })
    ],
}

module.exports = (env, argv) => {
    config.mode = argv.mode || 'development';
    config.plugins.push(
        new HtmlWebpackPlugin({
            title: 'JSCSDK spaces test application',
            template: `${Paths.PUBLIC}index.html`,
            favicon: path.join(__dirname, 'public', 'favicon.ico'),
            filename: 'index.html',
            version: argv.env && argv.env.VERSION ? argv.env.VERSION : 'not specified'
        })
    );

    const isDev = config.mode === 'development';
    const isServe = argv.env && argv.env.WEBPACK_SERVE || false;

    if (isDev) {
        config.target = 'web';
        config.devServer = {
            contentBase: Paths.DIST,
            port: 7000,
            historyApiFallback: true,
            open: true,
            compress: true,
            hot: true,
        };
        config.devtool = 'source-map';
        config.optimization = {
            minimize: !isDev,
        };
    }

    if (isServe) {
        config.output.path = Paths.DIST;
    }

    if (!isServe) {
        new CopyWebpackPlugin({
            patterns: [
                {
                    from: Paths.PUBLIC,
                    globOptions: {
                        ignore: '*/index.html',
                    },
                    to: '',
                },
            ],
        });
    }

    if (!isDev) {
        // internet explorer 11 support
        config.target = 'es6';
    }

    if (env && env.cert) {
        config.devServer.https = true;
        try {
            fs.readFileSync(path.join(__dirname, 'key.pem')) || fs.readFileSync(path.join(__dirname, '../key.pem'))
            fs.readFileSync(path.join(__dirname, 'cert.pem')) || fs.readFileSync(path.join(__dirname, '../cert.pem'));
            config.devServer.key = fs.readFileSync(path.join(__dirname, 'key.pem')) || fs.readFileSync(path.join(__dirname, '../key.pem'));
            config.devServer.cert = fs.readFileSync(path.join(__dirname, 'cert.pem')) || fs.readFileSync(path.join(__dirname, '../cert.pem'));
        } catch (e) {
            console.error('Please create key.pem and cert.pem files')
        }
    }

    if (env && env.zip) {
        config.plugins.push(
            new ZipPlugin({
                path: 'zip',
                filename: DEFAULT_ZIP_NAME + '.zip',
                pathPrefix: 'relative/path',
            })
        );
    }

    return config;
};
