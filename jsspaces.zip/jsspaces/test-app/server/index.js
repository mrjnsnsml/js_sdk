const express = require('express');
const fs = require('fs');
const qs = require('qs');
const https = require('https');
const path = require('path');
const request = require('request');
const { urlencoded } = require('body-parser');
const { env } = require('process');

const app = express();
const cert = fs.readFileSync(path.resolve(__dirname, '../cert.pem'));
const key = fs.readFileSync(path.resolve(__dirname,'../key.pem'));

const environmentType = {
    PRODUCTION: 'production',
    TESTING: 'testing'
}

app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
})
app.use(urlencoded({ extended: true }));

app.post('/access_token', (req, res, next) => {
    let form = {
        client_id: req.body.envType === environmentType.PRODUCTION ? '51637e9fc6ef6d6ee6ca' : '51637e9fc6ef6d6ee6ca',
        client_secret: req.body.envType === environmentType.PRODUCTION ? 'dba27928e18ad13528be1fc662eb01e19df7b171' : 'dba27928e18ad13528be1fc662eb01e19df7b171',
        ...req.body
    }
    delete form.envType;
    let url = req.body.envType === environmentType.PRODUCTION ? 'https://onesnatesting.esna.com/oauth2/access_token' : 'https://onesnatesting.esna.com/oauth2/access_token';
    let options = {
        'method': 'POST',
        'url': url,
        'headers': {
          'Accept': 'application/json',
          'Content-type': 'application/x-www-form-urlencoded'
        },
        form: qs.stringify(form),
        rejectUnauthorized: false,
        requestCert: false,
        agent: false
      };
    request(options, (error, response) => {
        if (error) return res.status(error.response.statusCode).send(error.response.statusText)
        return res.status(response.statusCode).send(response.body);
    });
})

const port = env.PORT || 7001;
const server = https.createServer({ key: key, cert: cert }, app);
server.listen(port, () => {
    console.log(`Server has started on port ${port}...`);
    console.log(`Press CTRL + C to stop`);
});