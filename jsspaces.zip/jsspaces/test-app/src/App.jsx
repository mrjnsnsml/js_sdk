import React from 'react';

import { CircularProgress } from '@material-ui/core';
import { createMuiTheme, ThemeProvider } from '@material-ui/core/styles';
import { blue, orange } from '@material-ui/core/colors';
import { Switch, Route } from 'react-router-dom';
import { appRoutes } from '@routers';

const theme = createMuiTheme({
    palette: {
        primary: {
            main: blue[800]
        },
        secondary: {
            main: orange[600],
        },
    },
});

export const App = () => {
    const renderRoute = (
        {
            protected: isProtectedRoute,
            exact = true,
            ...restRouteProps
        },
        idx,
    ) => {
        if (isProtectedRoute) {
            return <ProtectedRoute key={idx} exact={exact} {...restRouteProps} />;
        }
        return <Route key={idx} exact={exact} {...restRouteProps} />;
    };

    return (
        <ThemeProvider theme={theme}>
            <React.Suspense fallback={<CircularProgress/>}>
                <Switch>
                    {appRoutes.map(renderRoute)}
                </Switch>
            </React.Suspense>
        </ThemeProvider>
    );
};
