import React, { useState, createContext, useContext } from 'react';

export const CloudConnectContext = createContext({
    credentialProvider: null,
    myTopic: null,
    userInfo: null
});


export const CloudConnectProvider = (props) => {
    const context = useContext(CloudConnectContext);

    const [ userInfo, setUserInfo ] = useState(context.userInfo);
    const [ credentialProvider, setCredentialProvider ] = useState(context.credentialProvider);
    const [ myTopic, setMyTopic ] = useState(context.myTopic);

    return (
        <CloudConnectContext.Provider value={{
            credentialProvider,
            setCredentialProvider,
            userInfo,
            setUserInfo,
            myTopic,
            setMyTopic
        }}>
            {props.children}
        </CloudConnectContext.Provider>
    );
};
