import React, { createContext, useContext, useState } from 'react';
import CloudCommunicationRenderer from '@build/CloudCommunicationRenderer.min';

export const CollaborationContext = createContext({
    collaboration : undefined,
    isCollaborationEnabled: true,
    isCollaborationAvailable: false,
    isCollaborationPaused: false,
    isContentSharingStarted: false,
    isContentSharingPaused: false,
    isCollaborationOnlyEnabled: false,
    isPresenting: false,
    zoom: 1, 
    renderer : new CloudCommunicationRenderer(),
});


export const CollaborationProvider = (props) => {
    const context = useContext(CollaborationContext);

    const [ collaboration, setCollaboration ] = useState(context.collaboration);
    const [ isCollaborationEnabled, setIsCollaborationEnabled ] = useState(context.isCollaborationEnabled);
    const [ isCollaborationAvailable, setIsCollaborationAvailable ] = useState(context.isCollaborationAvailable);
    const [ isCollaborationPaused, setIsCollaborationPaused ] = useState(context.isCollaborationPaused);
    const [ isContentSharingStarted, setIsContentSharingStarted ] = useState(context.isContentSharingStarted);
    const [ isContentSharingPaused, setIsContentSharingPaused ] = useState(context.isContentSharingPaused);
    const [ zoom , setZoom ] = useState(context.zoom);
    const [ renderer, setRenderer] = useState(context.renderer);
    const [ isCollaborationOnlyEnabled, setIsCollaborationOnlyEnabled ] = useState(context.isCollaborationOnlyEnabled);
    const [ isPresenting, setIsPresenting ] = useState(context.isPresenting);

    return (
        <CollaborationContext.Provider value={{
            collaboration, 
            setCollaboration,
            isCollaborationEnabled, 
            setIsCollaborationEnabled,
            isCollaborationAvailable, 
            setIsCollaborationAvailable,
            isCollaborationPaused,
            setIsCollaborationPaused,
            isContentSharingStarted,
            setIsContentSharingStarted,
            isContentSharingPaused,
            setIsContentSharingPaused,
            isCollaborationOnlyEnabled,
            setIsCollaborationOnlyEnabled,
            isPresenting, 
            setIsPresenting,
            zoom,
            setZoom,
            renderer, 
            setRenderer
        }}>
            {props.children}
        </CollaborationContext.Provider>
    );
};
