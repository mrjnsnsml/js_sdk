import React, { useState, createContext, useContext } from 'react';

import { LocalStorageNames } from '@constants/storageDict';
import { TokenType, EnvironmentType } from '@build/CloudCommunication.min';

export const AuthContext = createContext({
    accessToken: window.localStorage.getItem(LocalStorageNames.ACCESS_TOKEN) || "",
    envType: EnvironmentType.TESTING,
    tokenType: TokenType.JWT,
    jwt: window.localStorage.getItem(LocalStorageNames.JWT) || "",
    isTokenReceived: false
});


export const AuthProvider = (props) => {
    const context = useContext(AuthContext);

    const [ envType, setEnvType ] = useState(context.envType);
    const [ tokenType, setTokenType ] = useState(context.tokenType);
    const [ jwt, setJWT ] = useState(context.jwt);
    const [ accessToken, setAccessToken ] = useState(context.accessToken);
    const [ isTokenReceived, setIsTokenReceived ] = useState(context.isTokenReceived);

    return (
        <AuthContext.Provider value={{
            envType,
            setEnvType,
            tokenType,
            setTokenType,
            jwt,
            setJWT,
            accessToken,
            setAccessToken,
            isTokenReceived,
            setIsTokenReceived
        }}>
            {props.children}
        </AuthContext.Provider>
    );
};
