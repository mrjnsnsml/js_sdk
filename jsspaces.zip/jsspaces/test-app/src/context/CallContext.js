import React, { useState, createContext, useContext } from 'react';

import { AudioMode, VideoMode } from '@build/CloudCommunication.min';

export const CallContext = createContext({
    call: null,
    audioMode: AudioMode.SEND_RECEIVE,
    videoMode: VideoMode.SEND_RECEIVE,
    isAudioMuted: false,
    isSpeakerMuted: false,
    isVideoMuted: false,
    isCallStarted: false,
    isAudio: true
});
export const DispatchContext = createContext();

export const CallProvider = (props) => {
    const context = useContext(CallContext);

    const [ call, setCall ] = useState(context.call);
    const [ audioMode, setAudioMode ] = useState(context.audioMode);
    const [ videoMode, setVideoMode ] = useState(context.videoMode);
    const [ isAudioMuted, setIsAudioMuted ] = useState(context.isAudioMuted);
    const [ isSpeakerMuted, setIsSpeakerMuted ] = useState(context.isSpeakerMuted);
    const [ isVideoMuted, setIsVideoMuted ] = useState(context.isVideoMuted);
    const [ isCallStarted, setIsCallStarted ] = useState(context.isCallStarted);
    const [ isAudio, setIsAudio ] = useState(context.isAudio); 

    return (
        <CallContext.Provider value={{
            call,
            setCall,
            isCallStarted, 
            setIsCallStarted,
            audioMode,
            setAudioMode,
            videoMode,
            setVideoMode,
            isAudioMuted,
            setIsAudioMuted,
            isSpeakerMuted,
            setIsSpeakerMuted,
            isVideoMuted,
            setIsVideoMuted,
            isAudio,
            setIsAudio
        }}>
            {props.children}
        </CallContext.Provider>
    );
};