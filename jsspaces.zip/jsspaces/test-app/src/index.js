import React from 'react';
import ReactDOM from 'react-dom';
import { HashRouter } from 'react-router-dom';
import Konva from '../../libs/konva.min.js';
import { SnackbarProvider } from 'notistack';
import CloudCommunication from '@build/CloudCommunication.min';

import { AuthProvider } from '@context/AuthContext';
import { CloudConnectProvider } from '@context/CloudConnectionContext';

import '@styles/main.css';
import { App } from 'App';

export const renderApp = () => {
    window.CloudCommunication = new CloudCommunication();
    CloudCommunication.registerLogger(window.console);

    ReactDOM.render(
        <AuthProvider>
            <CloudConnectProvider>
                <SnackbarProvider>
                    <HashRouter history={history}>
                        <App />
                    </HashRouter>
                </SnackbarProvider>
            </CloudConnectProvider>
        </AuthProvider>
    , document.getElementById('root'));
};

renderApp();
