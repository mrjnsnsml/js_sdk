import { Urls } from '@constants/urls';
import { InitializationPage } from '@pages/InitializationPage';
import { DashboardPage } from '@pages/DashboardPage';
import { TopicServicePage } from '@pages/TopicServicePage';
import { TopicPage } from '@pages/TopicPage';

export const appRoutes = [
    {
        path: Urls.INITIALIZATION,
        component: InitializationPage
    },
    {
        path: Urls.DASHBOARD,
        component: DashboardPage
    },
    {
        path: Urls.TOPIC_SERVICE,
        component: TopicServicePage
    },
    {
        path: Urls.TOPIC + '/:id',
        component: TopicPage
    }
];
