import React, {useContext, useEffect, useState, useRef} from 'react';

import { Button, Grid } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import { useSnackbar } from 'notistack';

import { SnackbarVariants } from '@constants/notifications';
import { CollaborationContext } from '@context/CollaborationContext';

const useStyles = makeStyles(() => ({
}))

export const Collaboration = () => {
    const classes = useStyles();
    const collaborationContext = useContext(CollaborationContext);
    const { collaboration, isCollaborationAvailable, setIsCollaborationAvailable, isCollaborationPaused, setIsCollaborationPaused, isContentSharingStarted, setIsContentSharingStarted, isContentSharingPaused, setIsContentSharingPaused, isPresenting, setIsPresenting } = collaborationContext;
    const { enqueueSnackbar: openSnackBar } = useSnackbar();
    const outGoingPreview  = useRef(null);

    useEffect(()=>{
        if(outGoingPreview.current !== null && isContentSharingStarted === true && 
            collaboration !== null &&
            collaboration.contentSharing.outgoingScreenSharingStream instanceof MediaStream === true){
                outGoingPreview.current.srcObject = collaboration.contentSharing.outgoingScreenSharingStream;
            }
    },[isContentSharingStarted, collaboration]);

    collaboration.contentSharing.addOnStartedCallback(()=>{
        if(collaboration.contentSharing.outgoingScreenSharingStream){
            document.getElementById("sharingPreview").srcObject = collaboration.contentSharing.outgoingScreenSharingStream;
        }
    });

    collaboration.contentSharing.addOnEndedCallback(()=>{
        setIsContentSharingStarted(false);
        setIsContentSharingPaused(false);
    })

    collaboration.contentSharing.addOnPausedCallback(() => {
        if(collaboration.contentSharing.isPresenting){
            setIsContentSharingPaused(true);
        }
    });

    collaboration.contentSharing.addOnResumedCallback(() => {
        if(collaboration.contentSharing.isPresenting){
            setIsContentSharingPaused(false);
        }
    });

    const pauseCollaboration = () => {
        collaboration.pause()
            .then(() => {
                openSnackBar('Collaboration was successfully paused', { variant: SnackbarVariants.SUCCESS });
                setIsCollaborationPaused(true);
            },() => {
                openSnackBar('Attempt to pause the collaboration failed', { variant: SnackbarVariants.ERROR });
            });
    };

    const resumeCollaboration = () => {
        collaboration.resume()
            .then(() => {
                openSnackBar('Collaboration was successfully resumed', { variant: SnackbarVariants.SUCCESS });
                setIsCollaborationPaused(false);
            },() => {
                openSnackBar('Attempt to resume the collaboration failed', { variant: SnackbarVariants.ERROR });
            });
    };

    const startFullscreenSharing = () => {
        collaboration.contentSharing.startScreenSharingFullScreen()
            .then(() => {
                openSnackBar('Fullscreen sharing started', { variant: SnackbarVariants.SUCCESS });
            },() => {
                openSnackBar('Attempt to start the screen sharing failed', { variant: SnackbarVariants.ERROR });
            });
    };

    const startWindowSharing = () => {
        collaboration.contentSharing.startScreenSharingApplicationWindow()
            .then(() => {
                openSnackBar('Application window sharing started', { variant: SnackbarVariants.SUCCESS });
            },() => {
                openSnackBar('Attempt to start the screen sharing failed', { variant: SnackbarVariants.ERROR });
            });
    };

    const startSharing = () => {
        collaboration.contentSharing.startScreenSharing()
            .then(() => {
                openSnackBar('Screen sharing started', { variant: SnackbarVariants.SUCCESS });
                setIsPresenting(true);
            },() => {
                openSnackBar('Attempt to start the screen sharing failed', { variant: SnackbarVariants.ERROR });
                setIsPresenting(false);
            });
    };

    const endScreenSharing = () => {
        collaboration.contentSharing.end()
            .then(() => {
                openSnackBar('Screen sharing successfully ended', { variant: SnackbarVariants.SUCCESS });
                setIsPresenting(false);
            },() => {
                openSnackBar('Attempt to end the screen sharing failed', { variant: SnackbarVariants.ERROR });
            });
            if(isContentSharingPaused){
                setIsContentSharingPaused(false);
                setIsContentSharingStarted(false);
            }
    };

    const pauseScreenSharing = () => {
        collaboration.contentSharing.pause()
            .then(() => {
                openSnackBar('Screen sharing successfully paused', { variant: SnackbarVariants.SUCCESS });
            },() => {
                openSnackBar('Attempt to pause the screen sharing failed', { variant: SnackbarVariants.ERROR });
            });
    };

    const resumeScreenSharing = () => {
        collaboration.contentSharing.resume()
            .then(() => {
                openSnackBar('Screen sharing successfully resumed', { variant: SnackbarVariants.SUCCESS });
            },() => {
                openSnackBar('Attempt to resume the screen sharing failed', { variant: SnackbarVariants.ERROR });
            });
    };
    
    return (
        <div className={classes.container}>
            <Grid container spacing={1}>
                <Grid item xs={6}>
                    <Button className={classes.resumeCollaborationBtn} style={{ marginRight: '10px' }} variant="contained" color="primary" disabled={!isCollaborationAvailable?!isCollaborationAvailable:!isCollaborationPaused} onClick = {resumeCollaboration}>
                        {'Resume Collaboration'}
                    </Button>
                    <Button className={classes.pauseCollaborationBtn} style={{ marginRight: '10px' }} variant="contained" color="primary" disabled={!isCollaborationAvailable?!isCollaborationAvailable:isCollaborationPaused} onClick = {pauseCollaboration}>
                        {'Pause Collaboration'}
                    </Button>
                </Grid>
                <Grid item xs={6}>
                    <Button className={classes.startFullscreenBtn} style={{ marginRight: '10px' }} variant="contained" color="primary" disabled onClick = {startFullscreenSharing}>
                        {'Start Fullscreen'}
                    </Button>
                    <Button className={classes.startWindowBtn} style={{ marginRight: '10px' }} variant="contained" color="primary" disabled onClick = {startWindowSharing}>
                        {'Start Window'}
                    </Button>
                    <Button className={classes.startSharingBtn} style={{ marginRight: '10px' }} variant="contained" color="primary" disabled={!isCollaborationAvailable ? !isCollaborationAvailable : !collaboration.contentSharing.startScreenSharingCapability.isAllowed ? !collaboration.contentSharing.startScreenSharingCapability.isAllowed : isCollaborationPaused ? isCollaborationPaused : isContentSharingStarted } onClick = {startSharing}>
                        {'Start Sharing'}
                    </Button>
                </Grid>
                <Grid item xs={3}></Grid>
                <Grid item xs={3}></Grid>
                <Grid item xs={3}>
                    <Button className={classes.endScreenSharingBtn} style={{ marginRight: '10px' }} variant="contained" color="primary" disabled={!isCollaborationAvailable?!isCollaborationAvailable: isCollaborationPaused ? isCollaborationPaused : !isContentSharingStarted} onClick = {endScreenSharing}>
                        {'End'}
                    </Button>
                    <Button className={classes.pauseScreenSharingBtn} style={{ marginRight: '10px' }} variant="contained" color="primary" disabled={!isCollaborationAvailable?!isCollaborationAvailable: isCollaborationPaused ? isCollaborationPaused : !isContentSharingStarted ? !isContentSharingStarted : !(collaboration.contentSharing.isPresenting && isPresenting) ? !(collaboration.contentSharing.isPresenting && isPresenting) : isContentSharingPaused} onClick = {pauseScreenSharing}>
                        {'Pause'}
                    </Button>
                    <Button className={classes.resumeScreenSharingBtn} style={{ marginRight: '10px' }} variant="contained" color="primary" disabled={!isCollaborationAvailable?!isCollaborationAvailable: isCollaborationPaused ? isCollaborationPaused : !isContentSharingStarted ? !isContentSharingStarted : !isContentSharingPaused} onClick = {resumeScreenSharing}>
                        {'Resume'}
                    </Button>
                </Grid>
                <Grid item xs={3}></Grid>
                <Grid item xs={6}>
                    <video id="sharingPreview" autoPlay={true} ref={outGoingPreview}></video>
                </Grid>
                <Grid item xs={6}></Grid>
            </Grid>
        </div>
    )
};