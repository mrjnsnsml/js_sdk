import React, { useCallback, useContext, useEffect, useRef, useState } from 'react';

import { Grid } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';

import { MediaDirection } from '@constants/mediaDirections';
import { CallContext } from '@context/CallContext';
import { isObjectEmpty } from '@utils';

const useStyles = makeStyles((theme) => ({
    videoContainer: {
        margin: '15px auto',
        justifyContent: 'center'
    },
    videoContainerRemote: {
        minWidth: '100px',
        minHeight: '100px',
        margin: 'auto',
        [theme.breakpoints.up(700)]: {
            position: 'relative'
        }
    },
    videoContainerLocal: {
        minWidth: '100px',
        minHeight: '100px',
        margin: 'auto',
        position: 'absolute',
        maxWidth: '170px',
        [theme.breakpoints.up('xs')]: {
            top: '75%'
        },
        [theme.breakpoints.up(700)]: {
            top: '10%'
        },
        right: '10%'
    },
}))

export const ActiveCall = () => {
    const classes = useStyles();

    const [ establishedTime, setEstablishedTime ] = useState('');

    const callContext = useContext(CallContext);
    const { 
        call, 
        isCallStarted, 
        videoMode,
    } = callContext;

    const localVideoContainer = useRef();
    const remoteVideoContainer = useRef();

    const videoElementsRender = useCallback(() => {
        switch(call.videoChannel.requestedDirection) {
            case MediaDirection.SEND_RECV: {
                return (
                    <div
                        ref={remoteVideoContainer}
                        id="remote-video-container"
                        className={classes.videoContainerRemote}
                    >
                        <div
                            ref={localVideoContainer}
                            id="local-video-container"
                            className={classes.videoContainerLocal}
                        />
                    </div>
                )
            }
            case MediaDirection.RECV_ONLY: {
                return (
                    <div
                        ref={remoteVideoContainer}
                        id="remote-video-container"
                        className={classes.videoContainerRemote}
                    />
                )
            }
            case MediaDirection.SEND_ONLY: {
                return (
                    <div
                        ref={localVideoContainer}
                        id="local-video-container"
                        className={classes.videoContainerRemote}
                    />
                )
            }
            case MediaDirection.DISABLE: {
                return;
            }
            default: {
                return;
            }
        }
    }, [isCallStarted, videoMode]);

    useEffect(() => {
        if (!!call && isObjectEmpty(call)) {
            return;
        }

        setEstablishedTime(call.establishedTime);

        if (!!localVideoContainer && localVideoContainer.current) {
            call.videoChannel.insertLocalVideo(localVideoContainer.current.getAttribute('id'));
        }
        if (!!remoteVideoContainer && remoteVideoContainer.current) {
            call.videoChannel.insertRemoteVideo(remoteVideoContainer.current.getAttribute('id'));
        }

        document.getElementsByTagName('video').forEach((element) => {
            if(element.paused) {
                element.play();
            }
            if(element.parentElement.id === 'local-video-container') element.style.borderRadius = '5%';
        });

        if (!!call && call.videoChannel) {
            call.videoChannel.addOnVideoChannelUpdatedCallback(function(videoChannel) {
                if(videoChannel.isCameraAccessDenied) {
                    openSnackBar(videoChannel.cameraDenialReason, { variant: SnackbarVariants.INFO });
                }
                if(videoChannel.isDisabled && !videoChannel.isSendVideoNegotiated && !videoChannel.isReceiveVideoNegotiated) {
                    openSnackBar(videoChannel.disabledReason.reason, { variant: SnackbarVariants.INFO });
                }
                if (!!localVideoContainer && localVideoContainer.current) {
                    call.videoChannel.insertLocalVideo(localVideoContainer.current.getAttribute('id'));
                }
                if (!!remoteVideoContainer && remoteVideoContainer.current) {
                    call.videoChannel.insertRemoteVideo(remoteVideoContainer.current.getAttribute('id'));
                }
            });
        }
        

        return () => {
            call.videoChannel.removeOnVideoChannelUpdatedCallback((videoChannel) => {
                if(videoChannel.isCameraAccessDenied) {
                    openSnackBar(videoChannel.cameraDenialReason, { variant: SnackbarVariants.INFO });
                }
                if(videoChannel.isDisabled && !videoChannel.isSendVideoNegotiated && !videoChannel.isReceiveVideoNegotiated) {
                    openSnackBar(videoChannel.disabledReason.reason, { variant: SnackbarVariants.INFO });
                }
            });
        }
    }, [ call, videoMode ]);

    return (
        <>
            <Grid container justify="space-between" className={classes.videoContainer}>
                <Grid item xs={12} md={9}>
                    {videoElementsRender()}
                </Grid>
            </Grid>
            {establishedTime?.toString() &&
                <div>
                    Established time {establishedTime.toString()}
                </div>
            }
        </>
    )
}