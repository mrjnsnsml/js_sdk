import React, { useContext, useEffect, useRef } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { CollaborationContext } from '@context/CollaborationContext';
import { Button, Grid} from '@material-ui/core';
import { blue, orange } from '@material-ui/core/colors';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';

const useStyles = makeStyles((theme) => ({
}));

export const Capabilities = () => {
    const classes = useStyles();
    const collaborationContext = useContext(CollaborationContext);
    const { collaboration } = collaborationContext;

    return (
             <Grid container spacing={1}>
                <Grid item xs={3}></Grid>
                <Grid item xs={6}>
                    <TableContainer component={Paper} spacing={1}>
                        <Table className={classes.table} aria-label="simple table">
                            <TableHead style={{backgroundColor: blue[800], fontWeight: 'bold', color: 'white'}}>
                            <TableRow>
                                <TableCell>Collaboration Capability</TableCell>
                                <TableCell align="right">Name</TableCell>
                                <TableCell align="right">isAllowed</TableCell>
                            </TableRow>
                            </TableHead>
                            <TableBody>
                                <TableRow key={'collaboration'}>
                                    <TableCell></TableCell>
                                    <TableCell align="right">contentSharing</TableCell>
                                    <TableCell align="right">{JSON.stringify(!!collaboration?collaboration.contentSharingCapability.isAllowed:false)}</TableCell>
                                </TableRow>
                                {/* <TableRow key={'collaboration1'}>
                                    <TableCell></TableCell>
                                    <TableCell align="right">whiteboard</TableCell>
                                    <TableCell align="right">{JSON.stringify(!!collaboration?collaboration.whiteboardCapability.isAllowed:false)}</TableCell>
                                </TableRow> */}
                                <TableRow key={'collaboration2'}>
                                    <TableCell></TableCell>
                                    <TableCell align="right">retrieveParticipantList</TableCell>
                                    <TableCell align="right">{JSON.stringify(!!collaboration?collaboration.retrieveParticipantListCapability.isAllowed:false)}</TableCell>
                                </TableRow>
                            </TableBody>
                        </Table>
                    </TableContainer>
                    <TableContainer component={Paper} spacing={1}>
                        <Table className={classes.table} aria-label="simple table">
                            <TableHead style={{backgroundColor: blue[800], fontWeight: 'bold', color: 'white'}}>
                            <TableRow>
                                <TableCell>Content Sharing Capability</TableCell>
                                <TableCell align="right">Name</TableCell>
                                <TableCell align="right">isAllowed</TableCell>
                            </TableRow>
                            </TableHead>
                            <TableBody>
                                <TableRow key={'contentSharing'}>
                                    <TableCell></TableCell>
                                    <TableCell align="right">shareApplicationWindow</TableCell>
                                    <TableCell align="right">{JSON.stringify(!!collaboration?!!collaboration.contentSharing?!!collaboration.contentSharing.shareApplicationWindowCapability?collaboration.contentSharing.shareApplicationWindowCapability.isAllowed:false:false:false)}</TableCell>
                                </TableRow>
                                <TableRow key={'contentSharing1'}>
                                    <TableCell></TableCell>
                                    <TableCell align="right">shareFullScreen</TableCell>
                                    <TableCell align="right">{JSON.stringify(!!collaboration?!!collaboration.contentSharing?!!collaboration.contentSharing.shareFullScreenCapability?collaboration.contentSharing.shareFullScreenCapability.isAllowed:false:false:false)}</TableCell>
                                </TableRow>
                                <TableRow key={'contentSharing2'}>
                                    <TableCell></TableCell>
                                    <TableCell align="right">startScreenSharing</TableCell>
                                    <TableCell align="right">{JSON.stringify(!!collaboration?!!collaboration.contentSharing?!!collaboration.contentSharing.startScreenSharingCapability?collaboration.contentSharing.startScreenSharingCapability.isAllowed:false:false:false)}</TableCell>
                                </TableRow>
                            </TableBody>
                        </Table>
                    </TableContainer>
                {/*     <TableContainer component={Paper} spacing={1}>
                        <Table className={classes.table} aria-label="simple table">
                            <TableHead style={{backgroundColor: 'green', fontWeight: 'bold', color: 'white'}}>
                            <TableRow>
                                <TableCell>Whiteboard Capability</TableCell>
                                <TableCell align="right">Name</TableCell>
                                <TableCell align="right">isAllowed</TableCell>
                            </TableRow>
                            </TableHead>
                            <TableBody>
                                <TableRow key={'whiteboard'}>
                                    <TableCell></TableCell>
                                    <TableCell align="right">addWhiteboard</TableCell>
                                    <TableCell align="right">true</TableCell>
                                </TableRow>
                                <TableRow key={'whiteboard2'}>
                                    <TableCell></TableCell>
                                    <TableCell align="right">removeWhiteboard</TableCell>
                                    <TableCell align="right">true</TableCell>
                                </TableRow>
                            </TableBody>
                        </Table>
                    </TableContainer> */}
                </Grid>
                <Grid item xs={3}></Grid>
            </Grid>
    );
};
