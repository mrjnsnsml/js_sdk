import React, { useContext, useEffect, useState } from 'react';
import { useHistory } from 'react-router';

import { Button, Grid } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import { green, red } from '@material-ui/core/colors';
import { useSnackbar } from 'notistack';

import { SnackbarVariants } from '@constants/notifications';
import { Urls } from '@constants/urls';
import { CloudConnectContext } from '@context/CloudConnectionContext';

const useStyles = makeStyles(() => ({
    backBtn: {
        display: 'block',
        marginLeft: 'auto'
    },
    callStatus: {
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center'
    },
    callStatusIcon: {
        display: 'block',
        height: '20px',
        width: '20px',
        marginRight: '12px',
        backgroundColor: red[600],
        borderRadius: '50%'
    },
    callStatusIconActive: {
        backgroundColor: green[800],
    }
}));

export const SdkStatusBar = () => {
    const classes = useStyles();
    const history = useHistory();
    const { enqueueSnackbar: openSnackBar } = useSnackbar();

    const cloudConnectContext = useContext(CloudConnectContext);
    const { setUserInfo } = cloudConnectContext;
    const [ isServiceAvailable, setIsServiceAvailable ] = useState(false);

    useEffect(() => {
        if (!!CloudCommunication) {
            if (CloudCommunication.isServiceAvailable) {
                setUserInfo(CloudCommunication.callService?.userInfo);
                setIsServiceAvailable(CloudCommunication?.isServiceAvailable);
            } else {
                history.push(Urls.INITIALIZATION);
            }
        } else {
            history.push(Urls.INITIALIZATION);
        }
    }, [CloudCommunication]);

    const backToHome = () => {
        history.push(Urls.INITIALIZATION);
    }

    const stopSdk = () => {
        try {
            CloudCommunication.stop();
            openSnackBar('CloudCommunication has been successfully stopped', { variant: SnackbarVariants.SUCCESS });
        } catch (err) {
            const errorMessage = err ? `${err.name} ${err.message}` : 'Attempt to stop CloudCommunication failed';
            openSnackBar(errorMessage, { variant: SnackbarVariants.ERROR });
        }
        backToHome();
    }

    return (
        <>
            <Grid container justify="space-between">
                <Button variant="contained" color="primary" onClick={stopSdk}>
                    Stop SDK
                </Button>
                <Button className={classes.backBtn} variant="contained" color="primary" onClick={backToHome}>
                    Back to home
                </Button>
            </Grid>
            <p className={classes.callStatus}>
                <span className={`${classes.callStatusIcon}${isServiceAvailable ? ' ' + classes.callStatusIconActive : ''}`}/>
                Session service
            </p>
        </>
    );
};
