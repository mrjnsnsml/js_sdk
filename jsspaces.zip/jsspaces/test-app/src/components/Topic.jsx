import React, { useCallback, useContext, useEffect, useRef, useState } from 'react';
import { useHistory, useParams } from 'react-router';

import { makeStyles } from '@material-ui/core/styles';
import { Button, Card, CardHeader, CardContent, Container, Drawer, Grid, IconButton, List, ListItem, ListItemText, Tabs, Tab, Toolbar } from '@material-ui/core';
import MenuIcon from '@material-ui/icons/Menu';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import clsx from 'clsx';
import { useSnackbar } from 'notistack';

import { VideoMode } from '@build/CloudCommunication.min';
import { Call } from '@components/Call';
import { Collaboration } from '@components/Collaboration';
import { CallContext } from '@context/CallContext';
import { CollaborationContext } from '@context/CollaborationContext';
import { CloudConnectContext } from '@context/CloudConnectionContext';
import { SnackbarVariants } from '@constants/notifications';
import { Urls } from '@constants/urls';
import { Renderer } from '@components/Renderer';

const useStyles = makeStyles((theme) => ({
  navBar: {
    marginBottom: '25px',
    [theme.breakpoints.down(1300)]: {
      display: 'none'
    }
  },
  drawer: {
    width: 500
  },
  root: {
    width: '80%',
    margin: '20px auto',
  },
  backBtn: {
    display: 'block',
    marginLeft: 'auto'
  },
  tab: {
    maxWidth: '100%',
    width: '100%'
  },
  menuButton: {
    marginRight: theme.spacing(2),
  },
  hide: {
    display: 'none',
  },
  drawerHeader: {
    display: 'flex',
    alignItems: 'center',
    padding: theme.spacing(0, 1),
    // necessary for content to be below app bar
    ...theme.mixins.toolbar,
    justifyContent: 'flex-end',
  },
  drawerNavbar: {
    flexDirection: 'column'
  },
  toolbar: {
    display: 'none',
    [theme.breakpoints.down(1300)]: {
      display: 'block'
    }
  },
  videoContainerRemoteMinified: {
    minWidth: '100px',
    minHeight: '100px',
    margin: 'auto',
    position: 'absolute',
    maxWidth: '170px',
    top: '55%',
    right: '30%'
},
}));

const MESSAGES_TAB = 'MessagesTab';
const TASKS_TAB = 'TasksTab';
const POSTS_TAB = 'PostsTab';
const CALL_TAB = 'CallTab';
const COLLABORATION_TAB = 'CollaborationTab';

export const Topic = () => {
  const { enqueueSnackbar: openSnackBar } = useSnackbar();
  const classes = useStyles();
  const history = useHistory();
  const { id } = useParams();

  const callContext = useContext(CallContext);
  const collaborationContext = useContext(CollaborationContext);
  const { isCollaborationAvailable } = collaborationContext;
  const { 
      call, 
      isCallStarted,
      videoMode,
  } = callContext;
  const cloudConnectContext = useContext(CloudConnectContext);
  const { userInfo } = cloudConnectContext;

  const [ topicInfoData, setTopicInfoData] = useState(null)
  const [ selectedTab, setSelectedTab ] = useState(MESSAGES_TAB);
  const [ isNavbarOpen, setIsNavbarOpen ] = useState(false);
  const isRemoteVideoEnabled = !!videoMode && (videoMode === VideoMode.SEND_RECEIVE || videoMode === VideoMode.RECEIVE_ONLY);

  const remoteMinifiedVideoContainer = useRef();

  const minifiedRemoteVideo = useCallback(() => {
    if (isCallStarted && selectedTab !== CALL_TAB && isRemoteVideoEnabled) {
      return (
        <div
            ref={remoteMinifiedVideoContainer}
            id="remote-minified-video-container"
            className={classes.videoContainerRemoteMinified}
            onClick={() => setSelectedTab(CALL_TAB)}
        />
      )
    }
  }, [isCallStarted, selectedTab]);

  useEffect(() => {
    if (isCallStarted && selectedTab !== CALL_TAB && isRemoteVideoEnabled) {
      remoteMinifiedVideoContainer.current?.children.forEach((children) => {
        if(children.tagName === 'VIDEO') {
            children.remove();
        }
      });
      call.videoChannel.insertRemoteVideo(remoteMinifiedVideoContainer.current?.getAttribute('id'));
    }
  }, [isCallStarted, selectedTab]);

  useEffect(() => {
    if (!!CloudCommunication) {
        if (!CloudCommunication.isServiceAvailable) {
          history.push(Urls.INITIALIZATION);
        }
    } else {
        history.push(Urls.INITIALIZATION);
    }
  }, [CloudCommunication]);


  useEffect(() => {
    if(!!CloudCommunication.topicService && !!userInfo && userInfo.type !== 'anonymous') {
        CloudCommunication.topicService.getTopicById(id)
          .then(res => {
            openSnackBar('Getting current topic successfully', { variant: SnackbarVariants.SUCCESS });
            setTopicInfoData(() => {
              return {
                  created: res.created,
                  id: res.id,
                  info: res.type,
                  isMyPersonalTopic: res.isMyPersonalTopic,
                  lastAccess: res.lastAccess,
                  role: res.role
              }
            });
          })
          .catch(() => {
            openSnackBar('Getting current topic failed', { variant: SnackbarVariants.ERROR })
          })
    }
  }, [CloudCommunication])

  const tabValueChangesHandler = (event, newValue) => {
    setSelectedTab(newValue);
  }
  
  const tabRender = useCallback(() => {
    switch(selectedTab) {
        case MESSAGES_TAB: {
            return (
              // implement Messages component this
              <div>Message</div>
            )
        }
        case TASKS_TAB: {
            return (
              // implement Tasks component this
              <div>Tasks</div>
            )
        }
        case POSTS_TAB: {
            return (
              // implement Posts component this
              <div>Posts</div> 
            )
        }
        case CALL_TAB: {
            return (
              <Call />
            )
        }
        case COLLABORATION_TAB: {
            return  isCollaborationAvailable ? <Collaboration /> : <Call />;
        }
        default: {
            return;
        }
    }
  }, [selectedTab]);

  const backToHome = () => {
    history.push(Urls.INITIALIZATION);
  }

  const toggleDrawer = (status) => {
    setIsNavbarOpen(status);
  }

  return (
    <div className={classes.root}>
      <Grid container>
        <Grid item xs={9}>
          <Tabs className={classes.navBar} value={selectedTab} onChange={tabValueChangesHandler}>
            <Tab label="Messages" value={MESSAGES_TAB} />
            <Tab label="Tasks" value={TASKS_TAB} />
            <Tab label="Posts" value={POSTS_TAB} />
            <Tab label="Call" value={CALL_TAB} />
            <Tab label="Collaboration" value={COLLABORATION_TAB} disabled = {!isCollaborationAvailable} />
          </Tabs>
          <Toolbar className={classes.toolbar}>
            <IconButton
              color="inherit"
              aria-label="open drawer"
              onClick={() => toggleDrawer(true)}
              className={clsx(classes.menuButton, isNavbarOpen && classes.hide)}
            >
              <MenuIcon />
            </IconButton>
          </Toolbar>
          <Drawer
            variant="persistent"
            anchor="left"
            open={isNavbarOpen}
            transitionDuration={700}
            className={classes.drawer}
          >
            <div className={classes.drawerHeader}>
              <IconButton onClick={() => toggleDrawer(false)}>
                <ChevronRightIcon />
              </IconButton>
            </div>
            <Tabs value={selectedTab} orientation="vertical" onChange={tabValueChangesHandler}>
              <Tab label="Messages" value={MESSAGES_TAB} />
              <Tab label="Tasks" value={TASKS_TAB} />
              <Tab label="Posts" value={POSTS_TAB} />
              <Tab label="Call" value={CALL_TAB} />
              <Tab label="Collaboration" value={COLLABORATION_TAB} />
            </Tabs>
          </Drawer>
          <Container >
            {tabRender()}
          </Container>
        </Grid>
        <Grid item xs={3}>
          <Button className={classes.backBtn} variant="contained" color="primary" onClick={backToHome}>
            Back to home
          </Button>
          {!!userInfo && userInfo.type !== 'anonymous' &&
          <Card className={classes.root} variant="outlined" component="fieldset">
            <CardHeader title="Topic Info" component="legend" />
            <CardContent className={classes.cardContent}>
                <List>
                    {!!topicInfoData && Object.keys(topicInfoData)
                        .map((el, idx) => (
                            <ListItem key={idx}>
                                <ListItemText primary={`${el}: ${topicInfoData[el]}`} />
                            </ListItem>
                    ))}
                </List>
            </CardContent>
        </Card>
        }
        </Grid>
      </Grid>
      {minifiedRemoteVideo()}
      <Renderer selected={selectedTab}/>
    </div>
  );
}