import React, { useContext, useEffect, useState } from 'react';

import { Grid, IconButton } from '@material-ui/core';
import MicIcon from '@material-ui/icons/Mic';
import MicOffIcon from '@material-ui/icons/MicOff';
import VolumeUpIcon from '@material-ui/icons/VolumeUp';
import VolumeOffIcon from '@material-ui/icons/VolumeOff';
import InfoIcon from '@material-ui/icons/Info';
import { makeStyles } from '@material-ui/core/styles';
import { blue } from '@material-ui/core/colors';
import clsx from 'clsx';
import { useSnackbar } from 'notistack';

import { capabilitiesInfoData, statusInfoData } from '@constants/audioInfo';
import { SnackbarVariants } from '@constants/notifications';
import { CallContext } from '@context/CallContext';
import { MediaInfo } from './MediaInfo';

const useStyles = makeStyles(() => ({
    activeButton: {
		color: blue[800],
		'&:hover': {
			color: 'rgba(0, 0, 0, 0.54);'
		}
	},
	buttonIcon: {
		'&:hover': {
			color: blue[800]
		}
	},
    dialogTitle: {
        backgroundColor: blue[800],
        color: 'white'
    },
    audioCard: {
        flexDirection: 'column'
    }
}))
export const AudioCard = () => {
    const classes = useStyles();
    const { enqueueSnackbar: openSnackBar } = useSnackbar();
    
    const callContext = useContext(CallContext);
    const { call, isAudioMuted, setIsAudioMuted, isSpeakerMuted, setIsSpeakerMuted } = callContext;

    const [ isButtonBlocked, setIsButtonBlocked ] = useState({
        audioMuteButton: false,
        speakerMuteButton: false
    });
    const [ isAudioInfoOpen, setIsAudioInfoOpen ] = useState(false);
    const [ audioCapabilitiesInfo, setAudioCapabilitiesInfo ] = useState(capabilitiesInfoData);
	const [ audioStatusInfo, setAudioStatusInfo ] = useState(statusInfoData);

    useEffect(() => {
			setAudioCapabilitiesInfo({
				MUTE_CAPABILITY: call.audioChannel.muteCapability.isAllowed,
				UNMUTE_CAPABILITY: call.audioChannel.unmuteCapability.isAllowed,
                MUTE_SPEAKER_CAPABILITY: call.audioChannel.muteSpeakerCapability.isAllowed,
				UNMUTE_SPEAKER_CAPABILITY: call.audioChannel.unmuteSpeakerCapability.isAllowed,
                SET_NOISE_REDUCTION_CAPABILITY: call.audioChannel.setNoiseReductionCapability.isAllowed
			});
			setAudioStatusInfo({
				MUTED: call.audioChannel.muted,
				SPEAKER_MUTED: call.audioChannel.speakerMuted,
				NOISE_REDUCTION_SETTINGS: call.audioChannel.noiseReductionSetting
			});
		}, [ call, isAudioInfoOpen ]
	);

    const muteMicro = () => {
        setIsButtonBlocked((prevState) => {
            return {
                ...prevState,
                audioMuteButton: true
            }
        });
        if (call.audioChannel.muted) {
            call.audioChannel.unmute()
                .then(() => {
                    setIsAudioMuted(false);
                    openSnackBar(`Microphone was unmuted`, { variant: SnackbarVariants.SUCCESS });
                })
                .catch((error) => {
                    openSnackBar(`${error.name}: ${error.message}`, { variant: SnackbarVariants.ERROR });
                })
                .finally(() => {
                    setIsButtonBlocked((prevState) => {
                        return {
                            ...prevState,
                            audioMuteButton: false
                        }
                    });
                })
        } else {
            call.audioChannel.mute()
                .then(() => {
                    setIsAudioMuted(true);
                    openSnackBar(`Microphone was muted`, { variant: SnackbarVariants.SUCCESS });
                })
                .catch((error) => {
                    openSnackBar(`${error.name}: ${error.message}`, { variant: SnackbarVariants.ERROR });
                })
                .finally(() => {
                    setIsButtonBlocked((prevState) => {
                        return {
                            ...prevState,
                            audioMuteButton: false
                        }
                    });
                })
        }
    };

    const muteSpeaker = () => {
        setIsButtonBlocked((prevState) => {
            return {
                ...prevState,
                speakerMuteButton: true
            }
        });
        if (call.audioChannel.speakerMuted) {
            call.audioChannel.unmuteSpeaker()
                .then(() => {
                    setIsSpeakerMuted(false);
                    openSnackBar(`Speaker was unmuted`, { variant: SnackbarVariants.SUCCESS });
                })
                .catch((error) => {
                    openSnackBar(`${error.name}: ${error.message}`, { variant: SnackbarVariants.ERROR });
                })
                .finally(() => {
                    setIsButtonBlocked((prevState) => {
                        return {
                            ...prevState,
                            speakerMuteButton: false
                        }
                    });
                })
        } else {
            call.audioChannel.muteSpeaker()
                .then(() => {
                    setIsSpeakerMuted(true);
                    openSnackBar(`Speaker was muted`, { variant: SnackbarVariants.SUCCESS });
                })
                .catch((error) => {
                    openSnackBar(`${error.name}: ${error.message}`, { variant: SnackbarVariants.ERROR });
                })
                .finally(() => {
                    setIsButtonBlocked((prevState) => {
                        return {
                            ...prevState,
                            speakerMuteButton: false
                        }
                    });
                })
        }
    };
    const showAudioInfo = (status) => {
        setIsAudioInfoOpen(status);
    }

    return (
        <Grid className={classes.audioCard}>
            <Grid item>
                <IconButton 
                    className={clsx(classes.buttonIcon, {
						[classes.activeButton]: isAudioMuted
					})}
                    onClick={muteMicro}
                    disabled={isButtonBlocked.audioMuteButton}
                    title={isAudioMuted ? 'Unmute audio' : 'Mute audio'}
                >
                    {isAudioMuted ? <MicOffIcon /> : <MicIcon />}
                </IconButton>
            </Grid>
            <Grid item>
                <IconButton 
                    className={clsx(classes.buttonIcon, {
                        [classes.activeButton]: isSpeakerMuted
                    })}
                    onClick={muteSpeaker}
                    disabled={isButtonBlocked.speakerMuteButton}
                    title={isSpeakerMuted ? 'Unmute speaker' : 'Mute speaker'}
                >
                    {isSpeakerMuted ? <VolumeOffIcon /> : <VolumeUpIcon />}
                </IconButton>
            </Grid>
            <Grid item>
                <IconButton 
                    className={clsx(classes.buttonIcon, {
                        [classes.activeButton]: isAudioInfoOpen
                    })}
                    onClick={() => showAudioInfo(true)}
                    title='Show audio info'
                >
                    <InfoIcon />
                </IconButton>
                <MediaInfo
                    classes={classes}
                    isInfoOpen={isAudioInfoOpen}
                    onInfoDialogClose={() => showAudioInfo(false)}
                    typeOfMedia="Audio"
                    capabilitiesInfo={audioCapabilitiesInfo}
                    statusInfo={audioStatusInfo}
                />
            </Grid>
        </Grid>
    )
}
