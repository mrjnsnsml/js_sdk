import React from 'react';
import { useHistory } from 'react-router';

import { Button, Card } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import ArrowForwardIosIcon from '@material-ui/icons/ArrowForwardIos';

import { Urls } from '@constants/urls';
import { UserCard } from './UserCard';
import { SdkStatusBar } from './SdkStatusBar';

const useStyles = makeStyles(() => ({
    btn: {
        alignSelf: 'center'
    },
    container: {
        display: 'flex',
        flexDirection: 'column',
        margin: "auto",
        maxWidth: "1400px",
        padding: '20px',
    }
}));

export const Dashboard = () => {
    const classes = useStyles();
    const history = useHistory();
    
    const goToTopicsPage = () => {
        history.push(Urls.TOPICS);
    }

    const goToTopicServicePage = () => {
        console.log('Go to topics page');
        history.push(Urls.TOPIC_SERVICE);
    }

    return (
        <Card className={classes.container}>
            <SdkStatusBar />
            <UserCard />
            <Button className={classes.btn} variant="contained" color="primary" onClick={goToTopicServicePage}>
                Topic Service <ArrowForwardIosIcon />
            </Button>
        </Card>
    );
};
