import React, { useContext, useEffect, useState } from 'react';

import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import CardHeader from '@material-ui/core/CardHeader';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';

import { CloudConnectContext } from '@context/CloudConnectionContext';
import { isObjectEmpty } from '@utils';

const useStyles = makeStyles({
    cardContent: {
        display: 'flex',
        justifyContent: 'center'
    },
    root: {
        width: '50%',
        margin: '30px auto',
        minWidth: 275,
        alignSelf: 'center'
    }
});

export const UserCard = () => {
    const classes = useStyles();

    const cloudConnectContext = useContext(CloudConnectContext);
    const { userInfo } = cloudConnectContext;
    const [ userInfoData, setUserInfoData ] = useState(null);

    useEffect(() => {
        if(!!userInfo) {
            if(!isObjectEmpty(userInfo)) {
                setUserInfoData(() => {
                    return {
                        id: userInfo.id,
                        info: userInfo.type,
                        displayName: userInfo.displayName
                    }
                });
            }
        }
    }, [userInfo]);

    return (
        <Card className={classes.root} variant="outlined" component="fieldset">
            <CardHeader title="User Info" component="legend" />
            <CardContent className={classes.cardContent}>
                <List>
                    {!!userInfoData && Object.keys(userInfoData)
                        .map((el, idx) => (
                            <ListItem key={idx}>
                                <ListItemText primary={`${el}: ${userInfoData[el]}`} />
                            </ListItem>
                    ))}
                </List>
            </CardContent>
        </Card>
    );
}
