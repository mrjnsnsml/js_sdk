import React, { useContext, useState } from 'react';

import { Button, CircularProgress, TextField } from '@material-ui/core';
import { useSnackbar } from 'notistack';

import { SnackbarVariants } from '@constants/notifications';
import { LocalStorageNames } from '@constants/storageDict';
import { Urls } from '@constants/urls';
import { AuthContext } from '@context/AuthContext';
import { EnvironmentType, TokenType } from '@build/CloudCommunication.min';

export const GuestLoginTab = ({ classes, setIsLoginInProgress, isLoginInProgress }) => {
    const { enqueueSnackbar: openSnackBar } = useSnackbar();

    const authContext = useContext(AuthContext);
    const { envType, setIsTokenReceived, setJWT, tokenType, setTokenType } = authContext;

    const [ displayName, setDisplayName ] = useState('');

    const handleTextInputChange = (event) => {
        setDisplayName(event.target.value);
    }

    const handleGuestRequest = () => {
        setIsLoginInProgress(true);
        let url = (envType === EnvironmentType.PRODUCTION ? Urls.PRODUCTION_ENV_URL : Urls.TESTING_ENV_URL) + Urls.GUEST_REQUEST_PATH;
        fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: new URLSearchParams({
                displayname: displayName
            }),
        })
            .then(res => {
                if(res.ok) {
                    return res.json();
                } else {
                    openSnackBar(`Received error code: ${res?.status}`, { variant: SnackbarVariants.ERROR });
                }
            })
            .then(res => {
                if (res.token) {
                    setJWT(res?.token);
                    if (tokenType !== TokenType.JWT) setTokenType(TokenType.JWT);
                    window.localStorage.setItem(LocalStorageNames.JWT, res?.token);
                    openSnackBar('Token was successfully received', { variant: SnackbarVariants.SUCCESS });
                    setIsTokenReceived(true);
                } else {
                    openSnackBar(res?.errorMessage, { variant: SnackbarVariants.ERROR });
                }
            })
            .catch((e) => {
                openSnackBar(`Couldn't get token ${e.message}`, { variant: SnackbarVariants.ERROR });
            });
    }
    return (
        <form className={classes.form} noValidate>
            <TextField 
                id="display-name" 
                label="Display name" 
                className={classes.textField}
                onChange={handleTextInputChange}
                value={displayName}
            />
            <Button
                variant="contained" 
                color="primary" 
                className={classes.button}
                onClick={handleGuestRequest}
                disabled={isLoginInProgress}
            >
                {isLoginInProgress ? <CircularProgress size={28}/> : "Start SDK"}
            </Button>
        </form>
    )
}
