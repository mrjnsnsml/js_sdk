import { Typography } from '@material-ui/core';
import React from 'react';

export const Header = ({ classes }) => {
    return (
        <div className={classes.root}>
            <Typography className={classes.heading} variant="h5" component="h3" align="center">
                Spaces API Test App
            </Typography>
        </div>
    );
};
