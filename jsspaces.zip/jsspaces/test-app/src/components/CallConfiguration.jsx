import React, { useContext, useEffect, useState } from 'react';

import {
    CircularProgress,
    Dialog, 
    DialogTitle, 
    DialogContent, 
    FormControl, 
    FormGroup, 
    FormControlLabel, 
    Checkbox, 
    InputLabel,
    MenuItem, 
    Select, 
    Button 
} from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import { blue } from '@material-ui/core/colors';
import { useSnackbar } from 'notistack';

import { SnackbarVariants } from '@constants/notifications';
import { CloudConnectContext } from '@context/CloudConnectionContext';
import { CallContext } from '@context/CallContext';
import { CollaborationContext } from '@context/CollaborationContext';

import { AudioMode, VideoMode } from '@build/CloudCommunication.min';

const useStyles = makeStyles(() => ({
    container: {
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
    },
    formControl: {
        marginLeft: 20,
        marginRight: 20,
    },
    startCallBtn: {
        minWidth: '110px',
        margin: '20px'
    },
    title: {
        background: blue[800],
        color: 'white'
    }
}))

export const CallConfiguration = ({collaborationOnlyEnabled, isCallConfigDialogOpen, setIsCallConfigDialogOpen}) => {
    const classes = useStyles();
    const { enqueueSnackbar: openSnackBar } = useSnackbar();

    const cloudConnectContext = useContext(CloudConnectContext);
    const { myTopic } = cloudConnectContext;

    const callContext = useContext(CallContext);
    const collaborationContext = useContext(CollaborationContext);
    const {
        audioMode,
        setAudioMode,
        setCall, 
        setIsCallStarted,
        videoMode, 
        setVideoMode,
        isAudio,
        setIsAudio
    } = callContext;

    const { isCollaborationEnabled, setIsCollaborationEnabled, setCollaboration, setIsCollaborationAvailable, setIsContentSharingStarted, renderer, isPresenting } = collaborationContext;

    const [ isSelectMenuOpen, setIsSelectMenuOpen ] = useState(false);
    const [ isCallCreating, setIsCallCreating ] = useState(false);
    const [ isNetworkAvailable, setIsNetworkAvailable ] = useState(true);

    const isAudioDisabled = videoMode !== VideoMode.DISABLE;

    useEffect(() => {
        let unmounted = false;
        const interval = setInterval(() => {
            !unmounted && setIsNetworkAvailable(navigator.onLine);
        }, 1000);
        return () => {
            clearInterval(interval);
            unmounted = true;
        }
    }, []);

    const handleAudioModeChange = (event) => {
        if (event.target.checked) {
            setIsAudio(true);
            setAudioMode(AudioMode.SEND_RECEIVE);
            openSnackBar(`Audio mode updated to ${AudioMode.SEND_RECEIVE}`, {variant: SnackbarVariants.SUCCESS});
        } else {
            setIsAudio(false);
            setAudioMode(AudioMode.DISABLE);
            if(!isCollaborationEnabled) setIsCollaborationEnabled(true);
            openSnackBar(`Audio mode updated to ${AudioMode.DISABLE}`, {variant: SnackbarVariants.SUCCESS});
        }
    }

    const handleVideoModeChange = (event) => {
        setVideoMode(event.target.value);
        if (event.target.value !== VideoMode.DISABLE) {
            setIsAudio(true);
            setAudioMode(AudioMode.SEND_RECEIVE);
        }
        openSnackBar(`Video mode updated to ${event.target.value}`, {variant: SnackbarVariants.SUCCESS});
    };

    const handleCollaborationModeChange = (event) => {
        if (event.target.checked) {
            setIsCollaborationEnabled(true);
            openSnackBar(`Collaboration mode enabled`, {variant: SnackbarVariants.SUCCESS});
        } else {
            setIsCollaborationEnabled(false);
            if(!isAudio) setIsAudio(true);
            openSnackBar(`Collaboration mode disabled`, {variant: SnackbarVariants.SUCCESS});
        }
    }

    const handleSelectOpenStatus = (status) => {
        setIsSelectMenuOpen(status);
    }

    const startCall = () => {
        setIsCallCreating(true);
        let call = CloudCommunication.callService.createCallForTopic(myTopic);
        setCall(call);
        call.setAudioMode(audioMode);
        call.setVideoMode(videoMode);
        call.setWebCollaboration(isCollaborationEnabled);
        call.start()
            .then(() => {
                setIsCallConfigDialogOpen(false);
                setIsCallStarted(true);
                openSnackBar('Call was successfully started', {variant: SnackbarVariants.SUCCESS});

                // Call callbacks
                if (call.isServiceAvailable) {
                    call.addOnCallFailedCallback((call) => {
                        openSnackBar('Call failed', { variant: SnackbarVariants.ERROR });
                    });
                    call.addOnCallEndedCallback((call) => {
                        openSnackBar('Call ended', { variant: SnackbarVariants.INFO });
                    });
                }

                // Collaboration callbacks
                call.collaboration.addOnAvailableCallback(() => {
                    setCollaboration(call.collaboration);
                    setIsCollaborationAvailable(true);
                    openSnackBar('Collaboration available', { variant: SnackbarVariants.SUCCESS });
                });
                call.collaboration.addOnEndedCallback(() => {
                    openSnackBar('Collaboration ended', { variant: SnackbarVariants.INFO });
                });
                call.collaboration.addOnUnavailableCallback(() => {
                    setIsCollaborationAvailable(false);
                    openSnackBar('Collaboration unavailable', { variant: SnackbarVariants.ERROR });
                });
                call.collaboration.addOnNearEndByEjectCallback(() => {
                    openSnackBar('Collaboration near and ejected', { variant: SnackbarVariants.ERROR });
                });

                call.collaboration.contentSharing.addOnStartedCallback(() => {
                    renderer.insertRenderer(call.collaboration.contentSharing.contentSharingForRenderer, 'konvaCanvas');
                    setIsContentSharingStarted(true);
                    if (!(call.collaboration.contentSharing.isPresenting && isPresenting)) {
                        openSnackBar('Remote user started screen sharing.', {variant: SnackbarVariants.SUCCESS});
                    }
                });

                // Media Callbacks
                call.addOnMediaConnectedCallback((call) => {
                    openSnackBar('Media has been connected', { variant: SnackbarVariants.INFO });
                });
                if (isAudio) {
                    const intervalID = setInterval(function () {
                        call.audioChannel.getStatistics().then(audioDetails => {
                            console.info('Statistics for the audio channel of the call download successful: ', audioDetails);
                        });
                        call.videoChannel.getStatistics().then(videoDetails => {
                            console.info('Statistics for the video channel of the call download successful: ', videoDetails);
                        });
                    }, 60000);
        
                    call.addOnCallEndedCallback(() => {
                        setIsCallStarted(false);
                        clearInterval(intervalID)
                    });
                }
                call.addOnMediaDisconnectedCallback((call) => {
                    openSnackBar('Call media has been disconnected', { variant: SnackbarVariants.WARNING });
                });
                call.addOnMediaFailedCallback((call) => {
                    openSnackBar('Call media has been failed', { variant: SnackbarVariants.ERROR });
                });
            })
            .catch((err) => {
                console.log(err);
                openSnackBar(`${err.name ? err.name : ''} ${err.message ? err.message : ''}`, {variant: SnackbarVariants.ERROR});
            })
            .finally(() => {
                setIsCallCreating(false);
            });
    };

    const handleCloseCallConfigDialog = () => {
        setIsCallConfigDialogOpen(false);
    };

    return (isCallConfigDialogOpen ? (
        <Dialog fullWidth={true} maxWidth='sm' open={isCallConfigDialogOpen} onClose={handleCloseCallConfigDialog} aria-labelledby="form-dialog-title">
            <DialogTitle id="form-dialog-title" className={classes.title}>
                Please, setup your call
            </DialogTitle>
            <DialogContent className={classes.container}>
                <FormControl className={classes.formControl}>
                    <FormGroup>
                        <FormControlLabel
                            control={
                                <Checkbox
                                    checked={isAudio}
                                    onChange={handleAudioModeChange}
                                    name="audio"
                                    color="primary"
                                    disabled={isAudioDisabled}
                                />
                            }
                            label="Audio"
                        />
                        <FormControlLabel
                            control={
                                <Checkbox
                                    checked={isCollaborationEnabled}
                                    onChange={handleCollaborationModeChange}
                                    name="collaboration"
                                    color="primary"
                                />
                            }
                            label="Collaboration"
                        />
                    </FormGroup>
                </FormControl>
                <FormControl className={classes.formControl}>
                    <FormGroup>
                        <InputLabel htmlFor="video-mode-label">Video Mode</InputLabel>
                        <Select
                            id="video-mode-label"
                            open={isSelectMenuOpen}
                            onClose={() => handleSelectOpenStatus(false)}
                            onOpen={() => handleSelectOpenStatus(true)}
                            value={videoMode}
                            onChange={handleVideoModeChange}
                        >
                            {
                                Object.values(VideoMode)
                                    .filter((mode) => mode !== VideoMode.SEND_ONLY)
                                    .map((mode, idx) => <MenuItem key={idx} value={mode}>{mode}</MenuItem>)
                            }
                        </Select>
                    </FormGroup>
                </FormControl>

                <Button
                    className={classes.startCallBtn}
                    variant="contained"
                    color="primary"
                    onClick={startCall}
                    disabled={!isCollaborationEnabled && !isAudio || isCallCreating || !isNetworkAvailable}
                >
                    {!isCallCreating && (collaborationOnlyEnabled ? 'Start Collaboration Only' : 'Start call')}
                    {isCallCreating && <CircularProgress size={28}/>}
                </Button>
            </DialogContent>
        </Dialog>
    ) : "");
};