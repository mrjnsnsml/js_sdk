import React, {useContext, useState} from 'react';

import { Button, Grid } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import { useSnackbar } from 'notistack';

import { SnackbarVariants } from '@constants/notifications';
import { CallContext } from '@context/CallContext';
import { CollaborationContext } from '@context/CollaborationContext';
import { ActiveCall } from '@components/ActiveCall';
import { CallConfiguration } from '@components/CallConfiguration';
import { AudioCard } from '@components/AudioCard';
import { VideoCard } from '@components/VideoCard';
import { AudioMode, VideoMode } from '@build/CloudCommunication.min';

const useStyles = makeStyles(() => ({
    mediaCard: {
        position: 'absolute',
        top: '35%',
        left: '5%'
    }
}))

export const Call = () => {
    const classes = useStyles();
    const { enqueueSnackbar: openSnackBar } = useSnackbar();

    const callContext = useContext(CallContext);
    const collaborationContext = useContext(CollaborationContext);

    const { 
        call, 
        isCallStarted, 
        setIsCallStarted, 
        setIsAudioMuted, 
        setIsSpeakerMuted, 
        setIsVideoMuted, 
        audioMode,
        videoMode, 
        isAudio, 
        isAudioMuted,
        isSpeakerMuted,
        isVideoMuted,
        setAudioMode,
        setVideoMode,
        setIsAudio,
    } = callContext;

    const { isCollaborationEnabled, setIsCollaborationEnabled, isCollaborationAvailable, setIsCollaborationAvailable, isCollaborationPaused, setIsCollaborationPaused } = collaborationContext;

    const collaborationOnlyEnabled = (isCollaborationEnabled && videoMode === VideoMode.DISABLE
        && !isAudio && !isAudioMuted && !isVideoMuted
    );
    
    const [ isCallConfigDialogOpen, setIsCallConfigDialogOpen ] = useState(false);

    const configCall = () => {
        setIsCallConfigDialogOpen(true);
    };
    const endCall = () => {
        if (!!call) {
            call.end()
                .then(() => {
                    setIsCallStarted(false);
                    if(isAudioMuted) setIsAudioMuted(false);
                    if(isSpeakerMuted) setIsSpeakerMuted(false);
                    if(isVideoMuted) setIsVideoMuted(false);
                    if(videoMode !== VideoMode.SEND_RECEIVE) setVideoMode(VideoMode.SEND_RECEIVE);
                    if(audioMode !== AudioMode.SEND_RECEIVE) setAudioMode(AudioMode.SEND_RECEIVE);
                    if(!isAudio) setIsAudio(true);
                    if(!isCollaborationEnabled) setIsCollaborationEnabled(true);
                    if(isCollaborationAvailable) setIsCollaborationAvailable(false);
                    if(isCollaborationPaused) setIsCollaborationPaused(false);
                    // Call callbacks
                    if (call.isServiceAvailable) {
                        call.removeOnCallFailedCallback((call) => {
                            openSnackBar('Call failed', { variant: SnackbarVariants.ERROR });
                        });
                        call.removeOnCallEndedCallback((call) => {
                            openSnackBar('Call ended', { variant: SnackbarVariants.INFO });
                        });
                    }
            
                    // Collaboration callbacks
                    call.collaboration.removeOnAvailableCallback(() => {
                        openSnackBar('Collaboration available', { variant: SnackbarVariants.SUCCESS });
                    });
                    call.collaboration.removeOnEndedCallback(() => {
                        openSnackBar('Collaboration ended', { variant: SnackbarVariants.INFO });
                    });
                    call.collaboration.removeOnUnavailableCallback(() => {
                        openSnackBar('Collaboration unavailable', { variant: SnackbarVariants.ERROR });
                    });
                    call.collaboration.removeOnNearEndByEjectCallback(() => {
                        openSnackBar('Collaboration near and ejected', { variant: SnackbarVariants.ERROR });
                        console.log('Collaboration near end ejected');
                    });

                    // Media callbacks
                    call.removeOnMediaConnectedCallback((call) => {
                        openSnackBar('Media has been connected', { variant: SnackbarVariants.INFO });
                    });
                    call.removeOnMediaDisconnectedCallback((call) => {
                        openSnackBar('Call media has been disconnected', { variant: SnackbarVariants.WARNING });
                    });
                    call.removeOnMediaFailedCallback((call) => {
                        openSnackBar('Call media has been failed', { variant: SnackbarVariants.ERROR });
                    });
                })
                .catch((err) => {
                    openSnackBar(err, {variant: SnackbarVariants.ERROR});
                })
        }
    };
    
    return (
        <>
            <Grid container justify="space-between">
                <Button variant="contained" color="primary" onClick={configCall} disabled={isCallStarted}>
                    Start Call
                </Button>
                <Button variant="contained" color="primary" onClick={endCall}>
                    End Call
                </Button>
            </Grid>
            <CallConfiguration 
                collaborationOnlyEnabled={collaborationOnlyEnabled}
                isCallConfigDialogOpen={isCallConfigDialogOpen} 
                setIsCallConfigDialogOpen={setIsCallConfigDialogOpen}
            />
            { isCallStarted && <ActiveCall /> }
            { isCallStarted && (
                <Grid container spacing={2} direction="column" className={classes.mediaCard}>
                    <Grid item xs={12}>
                        {!collaborationOnlyEnabled && <AudioCard />}
                    </Grid>
                    <Grid item xs={12}>
                        {!collaborationOnlyEnabled && <VideoCard />}
                    </Grid>
                </Grid>
            )}
        </>
    )
};