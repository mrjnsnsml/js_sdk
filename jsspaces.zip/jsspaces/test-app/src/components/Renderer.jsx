import React, { useContext, useEffect, useRef } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Box from '@material-ui/core/Box';
const COLLABORATION_TAB = 'CollaborationTab';
import { CollaborationContext } from '@context/CollaborationContext';
import { Button, Grid} from '@material-ui/core';
import Typography from '@material-ui/core/Typography';
import Slider from '@material-ui/core/Slider';
import { Capabilities } from '@components/Capabilities';

const useStyles = makeStyles((theme) => ({
    container: {
        maxWidth: '1200px',
        margin: 'auto',
        padding: '10px',
    },
    canvas: {
        width: 'inherit',
        height: '600px',
        background: '#aaa',
        maxHeight: '600px',
        overflow: 'scroll',
        alignItems: 'center',
        justifyContent: 'center',
    },
}));

export const Renderer = (props) => {
    const classes = useStyles();
    const collaborationContext = useContext(CollaborationContext);
    const { collaboration, isCollaborationAvailable, isContentSharingStarted, zoom, setZoom, renderer, isPresenting } = collaborationContext;
   
    const autoFitCanvas = () => {
        let canvas = document.querySelector('#konvaCanvas');
        let zoomValue = renderer.autoFit(canvas.clientWidth, canvas.clientHeight);
        setZoom(parseFloat(zoomValue).toFixed(1));
    };

    const handleZoomChange = (event, newValue) => {
      renderer.zoom(parseFloat(newValue));
      setZoom(newValue);
    };

    return (
        <div style={{ display: props.selected === COLLABORATION_TAB ? "block":"none" }} >
            <Grid container spacing={1}>
                <Grid item xs={2}></Grid>
                {isCollaborationAvailable && isContentSharingStarted && !(collaboration.contentSharing.isPresenting && isPresenting) && <Grid item xs={8}>
                    <Button className={classes.autoFitBtn} style={{ marginRight: '10px' }} variant="contained" color="primary" onClick = {autoFitCanvas}>
                        {'Autofit'}
                    </Button>
                    <Typography id="zoomSlider" gutterBottom> Zoom </Typography>
                    <Slider value={zoom} onChange={handleZoomChange} step={0.1} min={0} max={3} valueLabelDisplay="auto" aria-labelledby="zoomSlider"/>
                </Grid>}
                <Grid item xs={2}></Grid>
            </Grid>
            <Grid container spacing={1}>
                <Grid item xs={2}></Grid>
                <Grid item xs={8}>
                    <Box boxShadow={1}>
                        <div className = {classes.konvaContainer}>
                            <div className = {classes.canvas} id="konvaCanvas" ></div>
                        </div>
                    </Box>
                </Grid>
                <Grid item xs={2}></Grid>
            </Grid>
            <Capabilities/>
        </div>
    );
};
