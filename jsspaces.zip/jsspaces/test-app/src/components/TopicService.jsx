import React, { useEffect, useContext, useState } from 'react';
import { useHistory } from 'react-router';

import { makeStyles } from '@material-ui/core/styles';
import { Card, Grid, Paper, List, ListItem, ListItemText, Button } from '@material-ui/core';

import { SdkStatusBar } from './SdkStatusBar';
import { useSnackbar } from 'notistack';
import { SnackbarVariants } from '@constants/notifications';
import { Urls } from '@constants/urls';
import { CloudConnectContext } from '@context/CloudConnectionContext';

const useStyles = makeStyles((theme) => ({
    container: {
      display: 'flex',
      flexDirection: 'column',
      margin: "auto",
      maxWidth: "1400px",
      padding: '20px',
    },
    root: {
      width: '80%',
      margin: '20px auto'
    },
    paper: {
      padding: theme.spacing(2),
      minHeight: '100%',
      textAlign: 'center',
    },
    listItem: {
      marginBottom: 10,
      textAlign: 'center',
      color: theme.palette.text.secondary,
    },
    listName: {
      fontSize: 20,
      fontWeight: 'bold',
      margin: 10,
    },
    btnPersonal: {
      fontWeight: 'bold',
      alignSelf: 'center'
    }
}));

export const TopicService = () => {
  const { enqueueSnackbar: openSnackBar } = useSnackbar();
  const classes = useStyles();
  const history = useHistory();
  const [group, setGroup] = useState(null);
  const [direct, setDirect] = useState(null);
  const [personal, setPersonal] = useState(null);
  const cloudConnectContext = useContext(CloudConnectContext);
  const { userInfo, setMyTopic } = cloudConnectContext;

  const goToTopicPage = (topic) => {
    console.log('Go to topic page');
    CloudCommunication.topicService.getTopicById(topic._id).then((myTopic) => {
      setMyTopic(myTopic);
    }).catch((error) => {
      console.log(error);
    });
    // Go to topic page
    history.push(Urls.TOPIC + `/${topic._id}`);
  }
  const goToPersonalTopic = () => {
    console.log('Go to personal topic page');
    CloudCommunication.topicService.getTopicById(personal.id).then((personalTopic) => {
      setMyTopic(personalTopic)
    }).catch((error) => {
      console.log(error);
    });
    // Go to personal topic page
    !!personal && personal.id && history.push(Urls.TOPIC + `/${personal.id}`);
  }
  
  useEffect(() => {
    if(userInfo.type === 'anonymous'){
      goToTopicPage(userInfo.id)
    }
    if(!!CloudCommunication.topicService && userInfo.type !== 'anonymous') {
        CloudCommunication.topicService.getMyGroupTopics()
          .then(res => {
            openSnackBar('Getting group topics successfully', { variant: SnackbarVariants.SUCCESS });
            setGroup(res.data)
          })
          .catch(() => {
            openSnackBar('Getting group topics failed', { variant: SnackbarVariants.ERROR })
          }), 
        CloudCommunication.topicService.getMyDirectTopics()
          .then(res => {
            openSnackBar('Getting direct topics successfully', { variant: SnackbarVariants.SUCCESS });
            setDirect(res.data)
          })
          .catch(() => {
            openSnackBar('Getting dirct topics failed', { variant: SnackbarVariants.ERROR })
          }), 
        CloudCommunication.topicService.getPersonalTopic()
          .then(res => {
            openSnackBar('Getting personal topic successfully', { variant: SnackbarVariants.SUCCESS });
            setPersonal(res);
          })
          .catch(() => {
            openSnackBar('Getting personal topic failed', { variant: SnackbarVariants.ERROR })
          })
    }
  }, [CloudCommunication])

    return (
        <Card className={classes.container}>
            <SdkStatusBar />
            <div className={classes.root}>
              <Grid container spacing={3}>
                <Grid item xs={4}>
                  <Paper className={classes.paper}>
                    <p className={classes.listName}>Group</p>
                    <List>
                    {!!group && group
                      .map((el, idx) => (
                      <ListItem className={classes.listItem} key={idx} button onClick={() => goToTopicPage(el)}><ListItemText primary={el.title}/></ListItem>))}
                    </List>
                  </Paper>
                </Grid>
                <Grid item xs={4}>
                  <Paper className={classes.paper}>
                    <p className={classes.listName}>Direct</p>
                    <List>
                      {!!direct && direct
                      .map((el, idx) => (
                      <ListItem className={classes.listItem} key={idx} button onClick={() => goToTopicPage(el)}><ListItemText primary={el.title}/></ListItem>))}
                    </List>
                  </Paper>
                </Grid>
                <Grid item xs={4}>
                  <Paper className={classes.paper}>
                    <Button disabled={!personal} className={classes.btnPersonal} onClick={goToPersonalTopic}> Personal Topic </Button>
                  </Paper>
                </Grid>
              </Grid>
            </div>
        </Card>
    );
};