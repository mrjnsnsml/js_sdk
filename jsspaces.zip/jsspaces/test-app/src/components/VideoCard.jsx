import React, { useContext, useEffect, useState } from 'react';

import {
	Button,
	Dialog,
	DialogActions,
	DialogContent,
	DialogTitle,
	FormControl,
    Grid,
	IconButton,
	InputLabel,
	MenuItem,
	Select
} from '@material-ui/core';
import CameraIcon from '@material-ui/icons/Camera';
import InfoIcon from '@material-ui/icons/Info';
import HdIcon from '@material-ui/icons/Hd';
import PlayCircleOutlineIcon from '@material-ui/icons/PlayCircleOutline';
import VideocamIcon from '@material-ui/icons/Videocam';
import VideocamOffIcon from '@material-ui/icons/VideocamOff';
import { makeStyles } from '@material-ui/core/styles';
import { blue } from '@material-ui/core/colors';
import clsx from 'clsx';
import { useSnackbar } from 'notistack';

import { SnackbarVariants } from '@constants/notifications';
import { CallContext } from '@context/CallContext';
import { resolutionValues } from '@constants/videoResolution';
import { VideoMode, VideoResolutionFactory } from '@build/CloudCommunication.min';
import { capabilitiesInfoData, statusInfoData } from '@constants/videoInfo';
import { MediaInfo } from './MediaInfo';

const useStyles = makeStyles(() => ({
	activeButton: {
		color: 'blue',
		'&:hover': {
			color: 'gray'
		}
	},
	buttonIcon: {
		'&:hover': {
			color: 'blue'
		}
	},
	dialogTitle: {
        backgroundColor: blue[800],
        color: 'white'
    },
    videoCard: {
        flexDirection: 'column'
    }
}));

export const VideoCard = () => {
    const classes = useStyles();
    const { enqueueSnackbar: openSnackBar } = useSnackbar();

    const callContext = useContext(CallContext);
    const { call, isVideoMuted, setIsVideoMuted, setVideoMode } = callContext;

    const [ isVideoResolutionDialogOpen , setIsVideoResolutionDialogOpen ] = useState(false);
    const [ isVideoInfoOpen, setIsVideoInfoOpen ] = useState(false);
    const [ videoResolution, setVideoResolution ] = useState(resolutionValues.DEFAULT);
	const [ isSelectMenuOpen, setIsSelectMenuOpen ] = useState(false);
	const [ isRemoteVideoPaused, setIsRemoteVideoPaused ] = useState(
		call.videoChannel.isSendVideoNegotiated && !call.videoChannel.isReceiveVideoNegotiated
	);
	const [ isCameraBlocked, setIsCameraBlocked ] = useState(
		call.videoChannel.isReceiveVideoNegotiated && !call.videoChannel.isSendVideoNegotiated
	);
	const [ isVideoRemoved, setIsVideoRemoved ] = useState(
		!call.videoChannel.isSendVideoNegotiated && !call.videoChannel.isReceiveVideoNegotiated
	);
	const [ videoCapabilitiesInfo, setVideoCapabilitiesInfo ] = useState(capabilitiesInfoData);
	const [ videoStatusInfo, setVideoStatusInfo ] = useState(statusInfoData);
	const [ isButtonBlocked, setIsButtonBlocked ] = useState({
		muteCameraButton: false,
		pauseRemoteVideoButton: false,
		blockCameraButton: false,
		removeOrAddVideoButton: false
	});

	useEffect(
		() => {
			setVideoCapabilitiesInfo({
				SET_VIDEO_MODE_CAPABILITY: call.videoChannel.setVideoModeCapability.isAllowed,
				UPDATE_PREFERRED_RECEIVE_RESOLUTION_CAPABILITY:
					call.videoChannel.updatePreferredReceiveResolutionCapability.isAllowed,
				MUTE_CAPABILITY: call.videoChannel.muteCapability.isAllowed,
				UNMUTE_CAPABILITY: call.videoChannel.unmuteCapability.isAllowed
			});
			setVideoStatusInfo({
				REQUESTED_DIRECTION: call.videoChannel.requestedDirection,
				IS_SEND_VIDEO_NEGOTIATED: call.videoChannel.isSendVideoNegotiated,
				IS_RECEIVE_VIDEO_NEGOTIATED: call.videoChannel.isReceiveVideoNegotiated,
				PREFERRED_RECEIVE_RESOLUTION: call.videoChannel.preferredReceiveResolution,
				MUTED: call.videoChannel.muted
			});
		},
		[ call, isVideoInfoOpen ]
	);

    const muteCamera = () => {
		setIsButtonBlocked((prevState) => {
			return {
				...prevState,
				muteCameraButton: true
			}
		});
		if (isVideoMuted) {
			call.videoChannel.unmute()
				.then(() => {
					setIsVideoMuted(false);
					setIsButtonBlocked((prevState) => {
						return {
							...prevState,
							muteCameraButton: false
						}
					});
					openSnackBar(`Camera was unmuted`, { variant: SnackbarVariants.SUCCESS });
				})
				.catch((error) => {
					openSnackBar(`${error.name}: ${error.message}`, { variant: SnackbarVariants.ERROR });
				});
		} else {
			call.videoChannel.mute()
				.then(() => {
					setIsVideoMuted(true);
					setIsButtonBlocked((prevState) => {
						return {
							...prevState,
							muteCameraButton: false
						}
					});
					openSnackBar(`Camera was muted`, { variant: SnackbarVariants.SUCCESS });
				})
				.catch((error) => {
					openSnackBar(`${error.name}: ${error.message}`, { variant: SnackbarVariants.ERROR });
				});
		}
	};

	const handleSelectOpenStatus = (selectMenuStatus) => {
		setIsSelectMenuOpen(selectMenuStatus);
	};

	const handleVideoResolutionChange = (event) => {
		let resolution = '';
		switch (event.target.value) {
			case resolutionValues.RESOLUTION_180p: {
				resolution = VideoResolutionFactory.resolution180p;
				break;
			}
			case resolutionValues.RESOLUTION_240p: {
				resolution = VideoResolutionFactory.resolution240p;
				break;
			}
			case resolutionValues.RESOLUTION_360p: {
				resolution = VideoResolutionFactory.resolution360p;
				break;
			}
			case resolutionValues.RESOLUTION_480p: {
				resolution = VideoResolutionFactory.resolution480p;
				break;
			}
			case resolutionValues.RESOLUTION_720p: {
				resolution = VideoResolutionFactory.resolution720p;
				break;
			}
			case resolutionValues.RESOLUTION_1080p: {
				resolution = VideoResolutionFactory.resolution1080p;
				break;
			}
			default: {
				resolution = undefined;
				break;
			}
		}
		call.videoChannel.setPreferredReceiveResolution(resolution)
			.then(() => {
				if(resolution){
					if(call.videoChannel.preferredReceiveResolution.toString() !== resolution.toString()) {
						setVideoResolution(call.videoChannel.preferredReceiveResolution.toString());
						openSnackBar(`You exceeded the negotiated resolution. Resolution set to ${call.videoChannel.preferredReceiveResolution.toString().slice(10)}`, {
							variant: SnackbarVariants.INFO
						});
					}
					else {
						setVideoResolution(event.target.value);
						openSnackBar(`Video resolution was updated to ${event.target.value.slice(10)}`, {
							variant: SnackbarVariants.SUCCESS
						});
					}
				} else {
					setVideoResolution(event.target.value);
					openSnackBar(`Video resolution was updated to ${event.target.value}`, {
						variant: SnackbarVariants.SUCCESS
					});
				}
			})
			.catch((error) => {
				openSnackBar(`${error.name}: ${error.message}`, { variant: SnackbarVariants.ERROR });
			});
	};

	const pauseRemoteVideo = () => {
		setIsButtonBlocked((prevState) => {
			return {
				...prevState,
				pauseRemoteVideoButton: true
			}
		});
		if (isRemoteVideoPaused) {
			call.setVideoMode(VideoMode.SEND_RECEIVE)
				.then(() => {
					setVideoMode(VideoMode.SEND_RECEIVE);
					setIsRemoteVideoPaused(false);
					openSnackBar(`Video was unpaused`, { variant: SnackbarVariants.SUCCESS });
				})
				.catch((error) => {
					openSnackBar(`${error.name}: ${error.message}`, { variant: SnackbarVariants.ERROR });
				})
				.finally(() => {
					setIsButtonBlocked((prevState) => {
						return {
							...prevState,
							pauseRemoteVideoButton: false
						}
					});
				})
		} else {
			call.setVideoMode(VideoMode.SEND_ONLY)
				.then(() => {
					setVideoMode(VideoMode.SEND_ONLY);
					setIsRemoteVideoPaused(true);
					document.getElementsByTagName('video').forEach((element) => {
						if(!element.srcObject) element.remove();
					});
					openSnackBar(`Video was paused`, { variant: SnackbarVariants.SUCCESS });
				})
				.catch((error) => {
					openSnackBar(`${error.name}: ${error.message}`, { variant: SnackbarVariants.ERROR });
				})
				.finally(() => {
					setIsButtonBlocked((prevState) => {
						return {
							...prevState,
							pauseRemoteVideoButton: false
						}
					});
				});
		}
	};

	const blockCamera = () => {
		setIsButtonBlocked((prevState) => {
			return {
				...prevState,
				blockCameraButton: true
			}
		});
		if (isCameraBlocked) {
			call.setVideoMode(VideoMode.SEND_RECEIVE)
				.then(() => {
					setVideoMode(VideoMode.SEND_RECEIVE);
					setIsCameraBlocked(false);
					if (isRemoteVideoPaused) setIsRemoteVideoPaused(false);
					openSnackBar(`Camera was unblocked`, { variant: SnackbarVariants.SUCCESS });
				})
				.catch((error) => {
					openSnackBar(`${error.name}: ${error.message}`, { variant: SnackbarVariants.ERROR });
				})
				.finally(() => {
					setIsButtonBlocked((prevState) => {
						return {
							...prevState,
							blockCameraButton: false
						}
					});
				})
		} else if (isRemoteVideoPaused) {
			call.setVideoMode(VideoMode.DISABLE)
				.then(() => {
					setVideoMode(VideoMode.DISABLE);
					setIsCameraBlocked(true);
					setIsVideoRemoved(true);
					openSnackBar(`Camera was blocked`, { variant: SnackbarVariants.SUCCESS });
				})
				.catch((error) => {
					openSnackBar(`${error.name}: ${error.message}`, { variant: SnackbarVariants.ERROR });
				})
				.finally(() => {
					setIsButtonBlocked((prevState) => {
						return {
							...prevState,
							blockCameraButton: false
						}
					});
				})
		} else {
			call.setVideoMode(VideoMode.RECEIVE_ONLY)
				.then(() => {
					setVideoMode(VideoMode.RECEIVE_ONLY);
					setIsCameraBlocked(true);
					openSnackBar(`Camera was blocked`, { variant: SnackbarVariants.SUCCESS });
				})
				.catch((error) => {
					openSnackBar(`${error.name}: ${error.message}`, { variant: SnackbarVariants.ERROR });
				})
				.finally(() => {
					setIsButtonBlocked((prevState) => {
						return {
							...prevState,
							blockCameraButton: false
						}
					});
				})
		}
	};

	const removeOrAddVideo = () => {
		setIsButtonBlocked((prevState) => {
			return {
				...prevState,
				removeOrAddVideoButton: true
			}
		});
		if (isVideoRemoved) {
			call.setVideoMode(VideoMode.SEND_RECEIVE)
				.then(() => {
					setVideoMode(VideoMode.SEND_RECEIVE);
					setIsVideoRemoved(false);
					if (isCameraBlocked) setIsCameraBlocked(false);
					if (isRemoteVideoPaused) setIsRemoteVideoPaused(false);
					openSnackBar(`Video was added`, { variant: SnackbarVariants.SUCCESS });
				})
				.catch((error) => {
					openSnackBar(`${error.name}: ${error.message}`, { variant: SnackbarVariants.ERROR });
				})
				.finally(() => {
					setIsButtonBlocked((prevState) => {
						return {
							...prevState,
							removeOrAddVideoButton: false
						}
					});
				})
		} else {
			call.setVideoMode(VideoMode.DISABLE)
				.then(() => {
					setVideoMode(VideoMode.DISABLE);
					setIsVideoRemoved(true);
					openSnackBar(`Video was removed`, { variant: SnackbarVariants.SUCCESS });
				})
				.catch((error) => {
					openSnackBar(`${error.name}: ${error.message}`, { variant: SnackbarVariants.ERROR });
				})
				.finally(() => {
					setIsButtonBlocked((prevState) => {
						return {
							...prevState,
							removeOrAddVideoButton: false
						}
					});
				})
		}
	};
    
    const showVideoInfo = (status) => {
        setIsVideoInfoOpen(status);
    };

    const videoResolutionDialogOpen = () => {
        setIsVideoResolutionDialogOpen(true);
    };

    const videoResolutionDialogClose = () => {
        setIsVideoResolutionDialogOpen(false);
    };

    return (
        <Grid className={classes.videoCard}>
            {
                !isVideoRemoved &&
                <Grid item>
                    <IconButton
                        className={clsx(classes.buttonIcon, {
                            [classes.activeButton]: isCameraBlocked
                        })}
                        onClick={blockCamera}
                        disabled={isButtonBlocked.blockCameraButton}
                        title={isCameraBlocked ? "Unblock Camera" : "Block Camera"}
                    >
                        <PlayCircleOutlineIcon />
                    </IconButton>
                </Grid>
            }
            <Grid item>
                <IconButton
                    className={clsx(classes.buttonIcon, {
                        [classes.activeButton]: isVideoMuted
                    })}
                    onClick={muteCamera}
                    disabled={isButtonBlocked.muteCameraButton || isCameraBlocked}
                    title={isVideoMuted ? "Unmute video" : "Mute video"}
                >
                    <CameraIcon />
                </IconButton>
            </Grid>
            {
                (!isVideoRemoved && !isCameraBlocked) &&
                <Grid item>
                    <IconButton
                        className={clsx(classes.buttonIcon, {
                            [classes.activeButton]: isRemoteVideoPaused
                        })}
                        onClick={pauseRemoteVideo}
                        disabled={isButtonBlocked.pauseRemoteVideoButton}
                        title={isRemoteVideoPaused ? "Resume remote video" : "Pause remote video"}
                    >
                        <VideocamOffIcon />
                    </IconButton>
                </Grid>
            }
            <Grid item>
                <IconButton
                    className={clsx(classes.buttonIcon, {
                        [classes.activeButton]: isVideoRemoved
                    })}
                    onClick={removeOrAddVideo}
                    disabled={isButtonBlocked.removeOrAddVideoButton}
                    title={isVideoRemoved ? "Add video" : "Remove video"}
                >
                    <VideocamIcon />
                </IconButton>
            </Grid>
            <Grid item>
                <IconButton 
					className={clsx(classes.buttonIcon, {
                        [classes.activeButton]: isVideoResolutionDialogOpen
                    })}
					onClick={videoResolutionDialogOpen}
					title={"Change video resolution"}
				>
                    <HdIcon />
                </IconButton>
                <Dialog open={isVideoResolutionDialogOpen} onClose={videoResolutionDialogClose}>
                    <DialogTitle className={classes.dialogTitle}>Select video resolution</DialogTitle>
                    <DialogContent>
                        <form className={classes.container}>
                            <FormControl className={classes.formControl}>
                                <InputLabel htmlFor="demo-dialog-native">Age</InputLabel>
                                <Select
                                    label="Video resolution"
                                    id="video-resolution"
                                    open={isSelectMenuOpen}
                                    onClose={() => handleSelectOpenStatus(false)}
                                    onOpen={() => handleSelectOpenStatus(true)}
                                    value={videoResolution}
                                    onChange={handleVideoResolutionChange}
                                >
                                    {Object.values(resolutionValues).map((value, idx) => (
                                        <MenuItem key={idx} value={value}>
                                            {value}
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        </form>
                    </DialogContent>
                    <DialogActions>
						<Button onClick={videoResolutionDialogClose} color="primary">
							Cancel
						</Button>
						<Button onClick={videoResolutionDialogClose} color="primary">
							Ok
						</Button>
                    </DialogActions>
				</Dialog>
            </Grid>
            <Grid item>
                <IconButton 
					className={clsx(classes.buttonIcon, {
						[classes.activeButton]: isVideoInfoOpen
					})}
					onClick={() => showVideoInfo(true)}
					title="Show video info"
				>
                    <InfoIcon />
                </IconButton>
				<MediaInfo
					classes={classes}
                    isInfoOpen={isVideoInfoOpen}
                    onInfoDialogClose={() => showVideoInfo(false)}
                    typeOfMedia="Video"
                    capabilitiesInfo={videoCapabilitiesInfo}
                    statusInfo={videoStatusInfo}
                />
            </Grid>
        </Grid>
    )
}
