import React, { useCallback, useContext, useEffect, useState } from 'react';
import { useHistory } from 'react-router';

import Dialog from '@material-ui/core/Dialog';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import FormControl from '@material-ui/core/FormControl';
import InputLabel from '@material-ui/core/InputLabel';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';

import { makeStyles, Tab, Tabs } from '@material-ui/core';
import { useSnackbar } from 'notistack';

import { SnackbarVariants } from '@constants/notifications';
import { GuestLoginTab } from './GuestLoginTab';
import { RegisteredLoginTab } from './RegisteredLoginTab';
import { TokenLoginTab } from './TokenLoginTab';
import { AuthContext } from '@context/AuthContext';
import { Urls } from '@constants/urls';
import { CredentialProvider, EnvironmentType, TokenType } from '@build/CloudCommunication.min';
import { CloudConnectContext } from '@context/CloudConnectionContext';

const useStyles = makeStyles(() => ({
    button: {
        alignSelf: 'center',
        marginTop: '20px',
        minWidth: '81px',
        margin: '20px'
    },
    content: {
        display: 'flex',
        flexDirection: 'column',
        height: '35vh'
    },
    form: {
        display: 'flex',
        flexDirection: 'column',
        height: '80%',
        justifyContent: 'center',
        width: '80%',
        margin: '0 auto'
    },
    formControl: {
        margin: '0 auto',
        width: '50%'
    },
    title: {
        padding: 0
    }
}));

const GUEST_TAB = 'DashboardTab';
const REGISTERED_TAB = 'SessionTab';
const TOKEN_TAB = 'CollaborationTab';

export const LoginForm = () => {
    const { enqueueSnackbar: openSnackBar } = useSnackbar();
    const classes = useStyles();
    const history = useHistory();

    const authContext = useContext(AuthContext);
    const { 
            envType,
            setEnvType, 
            tokenType, 
            isTokenReceived, 
            setIsTokenReceived, 
            jwt, 
            accessToken
        } = authContext;

    const cloudConnectContext = useContext(CloudConnectContext);
    const { setCredentialProvider } = cloudConnectContext;
    
    const [ selectedTab, setSelectedTab ] = useState(GUEST_TAB);
    const [ isLoginInProgress, setIsLoginInProgress ] = useState(false);

    useEffect(() => {
        if (isTokenReceived) {
            try{
                const credentials = new CredentialProvider(tokenType, tokenType === TokenType.JWT ? jwt : accessToken);
                setCredentialProvider(credentials);
                CloudCommunication.start(credentials, envType)
                    .then(() => {
                        openSnackBar('Token was implemented successfully', { variant: SnackbarVariants.SUCCESS });
                        history.push(Urls.DASHBOARD);
                    })
                    .catch((e) => {
                        console.log(e);
                        openSnackBar('Cloud connection start method failed', { variant: SnackbarVariants.ERROR })
                    })
                    .finally(() => {
                        setIsLoginInProgress(false);
                    })
            } catch(err) {
                setIsLoginInProgress(false);
                openSnackBar('Cloud connection start method failed', { variant: SnackbarVariants.ERROR })
            }
        }
        return () => {
            setIsTokenReceived(false);
        }
    }, [ isTokenReceived ]);

    const tabValueChangesHandler = (event, newValue) => {
        setSelectedTab(newValue);
    }

    const envTypeSelectHandler = (event) => {
        setEnvType(event.target.value);
    }

    const tabRender = useCallback(() => {
        switch(selectedTab) {
            case GUEST_TAB: {
                return (
                    <GuestLoginTab
                        isLoginInProgress={isLoginInProgress}
                        setIsLoginInProgress={setIsLoginInProgress}
                        classes={classes} 
                    />
                )
            }
            case REGISTERED_TAB: {
                return (
                    <RegisteredLoginTab
                        isLoginInProgress={isLoginInProgress}
                        setIsLoginInProgress={setIsLoginInProgress}
                        classes={classes} 
                    />
                )
            }
            case TOKEN_TAB: {
                return (
                    <TokenLoginTab
                        isLoginInProgress={isLoginInProgress}
                        setIsLoginInProgress={setIsLoginInProgress}
                        classes={classes} 
                    />
                )
            }
            default: {
                return;
            }
        }
    })

    return (
        <Dialog open={true} aria-labelledby="form-dialog-title">
            <DialogTitle id="form-dialog-title" className={classes.title}>
                <Tabs value={selectedTab} onChange={tabValueChangesHandler}>
                    <Tab label="Guest" value={GUEST_TAB} />
                    <Tab label="Registered" value={REGISTERED_TAB} />
                    <Tab label="Token" value={TOKEN_TAB} />
                </Tabs>
            </DialogTitle>
            <DialogContent className={classes.content}>
                {tabRender()}
                <FormControl className={classes.formControl}>
                    <InputLabel id="env-type-label">Environment type</InputLabel>
                    <Select
                        labelId="env-type-label"
                        id="env-type"
                        value={envType}
                        onChange={envTypeSelectHandler}
                    >
                        {Object.values(EnvironmentType).map((type, idx) => {
                            return <MenuItem key={idx} value={type}>{type}</MenuItem>
                        })}
                    </Select>
                </FormControl>
            </DialogContent>
        </Dialog>
    );
}
