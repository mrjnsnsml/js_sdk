import React from 'react';

import { 
    Dialog, 
    DialogContent, 
    DialogTitle, 
    Divider, 
    List, 
    ListItem, 
    Typography 
} from '@material-ui/core';

export const MediaInfo = ({ classes, isInfoOpen, onInfoDialogClose, typeOfMedia, capabilitiesInfo, statusInfo }) => {
    return (
        <Dialog onClose={onInfoDialogClose} open={isInfoOpen}>
            <DialogTitle className={classes.dialogTitle}>{typeOfMedia} Information</DialogTitle>
            <DialogContent>
                <List>
                    {Object.keys(capabilitiesInfo).map((value, idx) => (
                        <ListItem key={idx}>
                            <Typography variant="body2" component="p">
                                {value}: {String(capabilitiesInfo[value])}
                            </Typography>
                        </ListItem>
                    ))}
                </List>
                <Divider light variant="middle" />
                <List>
                    {Object.keys(statusInfo).map((value, idx) => (
                        <ListItem key={idx}>
                            <Typography variant="body2">
                                {value}: {String(statusInfo[value])}
                            </Typography>
                        </ListItem>
                    ))}
                </List>
            </DialogContent>
        </Dialog>
    )
}

