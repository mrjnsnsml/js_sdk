import React, { useContext, useState } from 'react';

import { Button, CircularProgress, FormControl, InputLabel, MenuItem, Select, TextField } from '@material-ui/core';

import { LocalStorageNames } from '@constants/storageDict';
import { TokenType } from '@build/CloudCommunication.min';
import { AuthContext } from '@context/AuthContext';

export const TokenLoginTab = ({ classes, setIsLoginInProgress, isLoginInProgress }) => {
    const authContext = useContext(AuthContext);
    const { tokenType, setTokenType, setAccessToken, setJWT, setIsTokenReceived } = authContext;

    const [ token, setToken ] = useState('');

    const handleTokenInputChange = (event) => {
        setToken(event.target.value);
    }

    const handleSelectChange = (event) => {
        setTokenType(event.target.value);
    }

    const handleTokenRequest = () => {
        setIsLoginInProgress(true);
        if (tokenType === TokenType.JWT) {
            setJWT(token);
            window.localStorage.setItem(LocalStorageNames.JWT, token);
        } else {
            setAccessToken(token);
            window.localStorage.setItem(LocalStorageNames.ACCESS_TOKEN, token);
        }
        setIsTokenReceived(true);
    }

    return (
        <form className={classes.form} noValidate>
            <TextField 
                id="token" 
                label="token" 
                size="small" 
                className={classes.textField}
                onChange={handleTokenInputChange}
            />
            <FormControl className={classes.formControl} >
                <InputLabel id="token-type-select-label">Token type</InputLabel>
                <Select
                    labelId="token-type-select-label"
                    id="token-type-select"
                    value={tokenType}
                    onChange={handleSelectChange}
                >
                    {Object.values(TokenType).map((value, idx) => (
                        <MenuItem key={idx} value={value}>
                            {value}
                        </MenuItem>
                    ))}
                </Select>
            </FormControl>
            <Button 
                variant="contained" 
                color="primary" 
                className={classes.button}
                onClick={handleTokenRequest}
                disabled={isLoginInProgress}
            >
                {isLoginInProgress ? <CircularProgress size={28}/> : "Start SDK"}
            </Button>
        </form>
    )
}
