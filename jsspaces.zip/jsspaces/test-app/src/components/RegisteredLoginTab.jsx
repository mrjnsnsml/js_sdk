import React, { useContext, useState } from 'react';

import { Button, CircularProgress, TextField } from '@material-ui/core';
import { useSnackbar } from 'notistack';

import { SnackbarVariants } from '@constants/notifications';
import { RequestData } from '@constants/requestData';
import { LocalStorageNames } from '@constants/storageDict';
import { Urls } from '@constants/urls';
import { AuthContext } from '@context/AuthContext';
import { TokenType } from '@build/CloudCommunication.min';

export const RegisteredLoginTab = ({ classes, setIsLoginInProgress, isLoginInProgress }) => {
    const { enqueueSnackbar: openSnackBar } = useSnackbar();

    const authContext = useContext(AuthContext);
    const { envType, setIsTokenReceived, setJWT, setAccessToken, setTokenType } = authContext;

    const [ username, setUsername ] = useState('');
    const [ password, setPassword ] = useState('');

    const handleUsernameInputChange = (event) => {
        setUsername(event.target.value);
    }

    const handlePasswordInputChange = (event) => {
        setPassword(event.target.value);
    }

    const handleRegisteredRequest = () => {
        setIsLoginInProgress(true);
        fetch(Urls.REGISTERED_REQUEST_URL, {
            method: 'POST',
            headers: {
                'Content-type': 'application/x-www-form-urlencoded'
            },
            body: new URLSearchParams({
                grant_type: RequestData.GRANT_TYPE,
                username: username.includes('@avaya.com') ? username : `${username}@avaya.com`,
                password: password,
                scope: RequestData.SCOPE,
                envType: envType
            }),
        })
            .then(res => {
                if(res.ok) {
                    return res.json();
                } else {
                    console.log(res);
                    openSnackBar(`Received error code: ${res?.status}`, { variant: SnackbarVariants.ERROR });
                }
            })
            .then(res => {
                if (res.id_token) {
                    setJWT(res?.id_token);
                    setAccessToken(res?.access_token);
                    setTokenType(TokenType.BEARER);
                    window.localStorage.setItem(LocalStorageNames.JWT, res?.id_token);
                    window.localStorage.setItem(LocalStorageNames.ACCESS_TOKEN, res?.access_token);
                    window.localStorage.setItem(LocalStorageNames.TOKEN_TYPE, TokenType.BEARER);
                    openSnackBar('Token was successfully received', { variant: SnackbarVariants.SUCCESS });
                    setIsTokenReceived(true);
                }
            })
            .catch((e) => {
                console.log(e);
                openSnackBar(`Couldn't get token ${e.message}`, { variant: SnackbarVariants.ERROR });
            });
    }
    return (
        <form className={classes.form} noValidate>
            <TextField 
                id="username" 
                label="Username" 
                className={classes.textField}
                onChange={handleUsernameInputChange}
            />
            <TextField 
                id="password" 
                label="Password" 
                className={classes.textField}
                onChange={handlePasswordInputChange}
                type="password"
            />
            <Button 
                variant="contained" 
                color="primary" 
                className={classes.button}
                onClick={handleRegisteredRequest}
                disabled={isLoginInProgress}
            >
                {isLoginInProgress ? <CircularProgress size={28}/> : "Start SDK"}
            </Button>
        </form>
    )
}
