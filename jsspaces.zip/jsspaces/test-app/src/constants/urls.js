export const Urls = {
    INITIALIZATION: '/',
    DASHBOARD: '/dashboard',
    PRODUCTION_ENV_URL: 'https://spacesapis.zang.io/',
    TESTING_ENV_URL: 'https://logantesting.esna.com/',
    GUEST_REQUEST_PATH: 'api/anonymous/auth',
    REGISTERED_REQUEST_URL: 'https://localhost:7001/access_token',
    TOPICS: '/topics',
    TOPIC_SERVICE: '/topicService',
    TOPIC: '/topic',
    CALL: '/call',
    GET_SPACES: 'https://spacesapis.avayacloud.com/api/users/me/spaces',
}
