export const capabilitiesInfoData = {
    SET_VIDEO_MODE_CAPABILITY: '',
    UPDATE_PREFERRED_RECEIVE_RESOLUTION_CAPABILITY: '',
    MUTE_CAPABILITY: '',
    UNMUTE_CAPABILITY: ''
}

export const statusInfoData = {
    REQUESTED_DIRECTION: '',
    IS_SEND_VIDEO_NEGOTIATED: false,
    IS_RECEIVE_VIDEO_NEGOTIATED: false,
    PREFERRED_RECEIVE_RESOLUTION: undefined,
    MUTED: false
}