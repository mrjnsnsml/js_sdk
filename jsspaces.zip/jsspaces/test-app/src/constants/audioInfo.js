export const capabilitiesInfoData = {
    MUTE_CAPABILITY: '',
    UNMUTE_CAPABILITY: '',
    MUTE_SPEAKER_CAPABILITY: '',
    UNMUTE_SPEAKER_CAPABILITY: '',
    SET_NOISE_REDUCTION_CAPABILITY: ''
}

export const statusInfoData = {
    MUTED: false,
    SPEAKER_MUTED: false,
    NOISE_REDUCTION_SETTINGS: undefined
}