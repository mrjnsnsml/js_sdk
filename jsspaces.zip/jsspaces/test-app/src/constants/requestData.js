export const RequestData = {
    ACCEPT: 'application/json',
    CONTENT_TYPE: 'application/x-www-form-urlencoded',
    GRANT_TYPE: 'password',
    SCOPE: 'email profile spaces'
}