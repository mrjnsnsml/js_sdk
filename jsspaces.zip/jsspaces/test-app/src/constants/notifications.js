export const SnackbarVariants = {
    DEFAULT: 'default',
    ERROR: 'error',
    SUCCESS: 'success',
    WARNING: 'warning',
    INFO: 'info',
}
