
export const LocalStorageNames = {
    TOKEN_ID: 'tokenId',
    JWT: 'jwt',
    ACCESS_TOKEN: 'accessToken',
    TOKEN_TYPE: 'tokenType'
}
