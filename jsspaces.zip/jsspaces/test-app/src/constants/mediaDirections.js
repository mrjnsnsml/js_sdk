export const MediaDirection = {
    /** Media is received but not sent. */
    RECV_ONLY: "recvonly",
    /** Media is sent but no media is received. */
    SEND_ONLY: "sendonly",
    /** Media is sent and received. */
    SEND_RECV: "sendrecv",
    /** No media flow. No media is transmitted or received. */
    INACTIVE: "inactive",
    /** Media direction has been disabled. */
    DISABLE: "disable",
    /** Media direction has not been set. */
    UNDEFINED: "undefined"
};