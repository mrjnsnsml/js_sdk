import { VideoResolutionFactory } from 'avayamedia';

export const resolutionValues = {
    DEFAULT: 'Choose video resolution',
    RESOLUTION_180p: VideoResolutionFactory.resolution180p.toString(),
    RESOLUTION_240p: VideoResolutionFactory.resolution240p.toString(),
    RESOLUTION_360p: VideoResolutionFactory.resolution360p.toString(),
    RESOLUTION_480p: VideoResolutionFactory.resolution480p.toString(),
    RESOLUTION_720p: VideoResolutionFactory.resolution720p.toString(),
    RESOLUTION_1080p: VideoResolutionFactory.resolution1080p.toString()
}
