import React from 'react'

import { Header } from '@components/Header';
import { Dashboard } from '@components/Dashboard';

import { makeStyles } from '@material-ui/core';

const useStyles = makeStyles(theme => ({
    heading: {
        padding: '8px',
        marginBottom: '40px',
        color: '#ffffff',
        backgroundColor: theme.palette.primary.main,
        boxShadow: theme.shadows[10],
        height: '9vh',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center'
    }
}));

export const DashboardPage = () => {
    const classes = useStyles();

    return (
        <>
            <Header classes={classes} />
            <Dashboard />
        </>
    )
}
