### Generate key and cert files

```sh
openssl req -newkey rsa:2048 -new -nodes -x509 -days 3650 -keyout key.pem -out cert.pem
```

## ONE time installation of AvayaMedia module
# Update .npmrc with your credentials
```
strict-ssl=false
_auth=<BASE64 USERNAME:PASSWORD>
email=<AVAYA_EMAIL>
```
# Install AvayaMedia module
```
npm install avayamedia@dev --registry=https://npm.forge.avaya.com/repository/jscsdk-npm
```
# Update avayamedia module library with your development build
```
grunt dev 
```

## Start build with hot reload
```sh
npm run start
```
## Start build with hot reload and with hosting on 127.0.0.2 host
### You can configure your host to change host number after --host flag
```sh
npm run start-device
```

## Make a dev build
```sh
npm run dev
```
## Make a dev build with zip file
```sh
npm run dev:zip
```
## Make a prod build
```sh
npm run build
```
## Make a prod build with zip file
```sh
npm run build:zip
```
